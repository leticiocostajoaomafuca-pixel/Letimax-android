import React, {useEffect, useMemo, useRef, useState} from 'react';
import {Alert, ActivityIndicator, FlatList, KeyboardAvoidingView, Linking, Modal, Platform, Pressable, SafeAreaView, ScrollView, StatusBar, Switch, Text, TextInput, View} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Speech from 'expo-speech';
import * as LocalAuthentication from 'expo-local-authentication';
import * as Clipboard from 'expo-clipboard';
import * as Notifications from 'expo-notifications';
import * as WebBrowser from 'expo-web-browser';
import {CameraView, useCameraPermissions} from 'expo-camera';
import {useSpeechRecognitionEvent, ExpoSpeechRecognitionModule} from 'expo-speech-recognition';

const GOLD='#C9A84C';
const MODULES=[
['Chat','Conversar com a LétimaX e usar comandos de voz.','chat'],
['Dashboard','Resumo de receitas, metas e estado das integrações.','dashboard'],
['Produtos','Criar, editar, aprovar e acompanhar produtos.','products'],
['Mercado','Registar pesquisas de mercado, nichos e concorrentes.','market'],
['Marketing','Criar campanhas, copy e funis de venda.','marketing'],
['Metas','Definir metas e acompanhar o progresso.','goals'],
['Motor de Receita','Oportunidades, pontuação e aprovação humana.','revenue'],
['Sistema de Raqueamento','Estratégias excepcionais sujeitas a aprovação.','raqueamento'],
['Activos','Biblioteca de activos e valor estimado.','assets'],
['Novos Negócios','Oportunidades legais e planos de implementação.','business'],
['Cursos','Cursos, módulos, aulas e guiões.','courses'],
['Webinars','Webinars, guiões e sequências de emails.','webinars'],
['Afiliados Externos','Produtos de afiliados e campanhas.','external-affiliates'],
['Afiliados Próprios','Afiliados, links, comissões e desempenho.','own-affiliates'],
['Lançamentos','Planeamento de pré-lançamento, lançamento e pós-lançamento.','launches'],
['Email Marketing','Listas, segmentos e sequências de email.','email'],
['Analytics','Métricas, conversões, CAC e LTV.','analytics'],
['Reputação','Testemunhos, sentimento e alertas.','reputation'],
['Suporte','Tickets, respostas em rascunho e acompanhamento.','support'],
['Onboarding','Etapas de integração de clientes.','onboarding'],
['Referências','Indicações, links e recompensas.','referrals'],
['Páginas','Páginas de captura, vendas e obrigado.','pages'],
['Vídeos','Guiões, miniaturas e legendas.','videos'],
['Sites','Sites, estado, SEO e publicação aprovada.','sites'],
['Apresentações','Apresentações e propostas.','presentations'],
['Automação Inteligente','Fluxos, estados e histórico de automação.','automation'],
['Oportunidades','Oportunidades ad-hoc e decisão.','opportunities'],
['Investimentos','Monitorização de preços; sem compra ou venda.','investments'],
['Empresa','Plano empresarial e projecções.','company'],
['Finanças','Receitas, despesas e orçamento.','finance'],
['Contactos','Clientes, parceiros e fornecedores.','contacts'],
['Saúde','Lembretes de pausas, água e registo opcional.','health'],
['Passwords','Cofre local protegido por autenticação do dispositivo.','passwords'],
['Documentos','Contratos, termos e políticas em rascunho.','documents'],
['Configurações','Tema, voz, servidor, IA, autonomia e integrações.','settings'],
['Logs','Registos de actividade e segurança.','logs'],
['Actualização','Versão instalada e verificação manual.','updates'],
['Biometria','Autenticação do dispositivo e permissões.','biometrics'],
['Notificações','Preferências e histórico de notificações.','notifications'],
['Ajuda e Segurança','Limites, privacidade e operações que exigem aprovação.','security'],
['Exportar Dados','Exportar cópia JSON dos dados locais.','export'],
['Primeiro Uso','Configuração inicial e ligações necessárias.','first-run'],
['Sobre','Informação da aplicação.','about']
];
const DEFAULTS={theme:'system',voice:true,serverUrl:'',provider:'anthropic',autonomy:1,ownerName:'Letício',morningSummary:'08:00',dailyApiLimit:'0',tokenLimit:'8000'};
const palette=(dark)=>({bg:dark?'#0D0D0D':'#FFFFFF',card:dark?'#1B1B1B':'#F5F5F5',text:dark?'#FFFFFF':'#1A1A1A',muted:dark?'#AAAAAA':'#666666',line:dark?'#333333':'#E5E5E5'});
const money=v=>Number(v||0).toLocaleString('pt-MZ',{maximumFractionDigits:2});
const safeParse=(s,f)=>{try{return JSON.parse(s)||f}catch{return f}};
function Button({title,onPress,secondary=false,disabled=false}){return <Pressable disabled={disabled} onPress={onPress} style={{backgroundColor:secondary?'transparent':GOLD,borderColor:GOLD,borderWidth:1,borderRadius:12,padding:12,marginVertical:5,opacity:disabled ? 0.5 : 1}}><Text style={{color:secondary?GOLD:'#161616',fontWeight:'700',textAlign:'center'}}>{title}</Text></Pressable>}
function Field({label,value,onChangeText,placeholder,multiline=false,secureTextEntry=false,keyboardType}){return <View style={{marginVertical:6}}><Text style={{fontWeight:'600',marginBottom:5}}>{label}</Text><TextInput value={String(value??'')} onChangeText={onChangeText} placeholder={placeholder||label} placeholderTextColor="#888" multiline={multiline} secureTextEntry={secureTextEntry} keyboardType={keyboardType} style={{borderWidth:1,borderColor:'#9996',borderRadius:10,padding:11,minHeight:multiline?88:44,textAlignVertical:multiline?'top':'center'}}/></View>}
export default function App(){
 const [store,setStore]=useState({}); const [settings,setSettings]=useState(DEFAULTS); const [ready,setReady]=useState(false);
 const [active,setActive]=useState('chat'); const [drawer,setDrawer]=useState(false); const [dark,setDark]=useState(false);
 const [messages,setMessages]=useState([{id:'welcome',role:'assistant',text:'Bem-vindo, Senhor Letício à LétimaX. Qual é a tarefa de hoje?'}]);
 const [input,setInput]=useState(''); const [list,setList]=useState([]); const [modal,setModal]=useState(false); const [record,setRecord]=useState({title:'',description:'',status:'Rascunho',value:''});
 const [busy,setBusy]=useState(false); const [cameraPermission,requestCameraPermission]=useCameraPermissions();
 const [transcript,setTranscript]=useState(''); const [isListening,setIsListening]=useState(false);
 const theme=useMemo(()=>palette(dark),[dark]);
 const scroll=useRef(null);
 useEffect(()=>{(async()=>{const raw=await AsyncStorage.getItem('letimax_v1');const saved=safeParse(raw,{});setStore(saved.store||{});setSettings({...DEFAULTS,...saved.settings});setMessages(saved.messages||messages);setReady(true)})()},[]);
 useEffect(()=>{if(ready)AsyncStorage.setItem('letimax_v1',JSON.stringify({store,settings,messages})).catch(()=>{})},[store,settings,messages,ready]);
 useEffect(()=>{const d=settings.theme==='dark'||(settings.theme==='system'&&Platform.OS==='android'&&false);setDark(d)},[settings.theme]);
 useSpeechRecognitionEvent('start',()=>setIsListening(true));
 useSpeechRecognitionEvent('end',()=>setIsListening(false));
 useSpeechRecognitionEvent('result',e=>{const t=e.results?.[0]?.transcript||'';setTranscript(t);setInput(t)});
 useSpeechRecognitionEvent('error',e=>{setIsListening(false);Alert.alert('Reconhecimento de voz',e.message||'Não foi possível reconhecer a voz.')});
 const items=store[active]||[];
 const updateList=(arr)=>setStore(s=>({...s,[active]:arr}));
 const speak=(text)=>{if(settings.voice)Speech.speak(text,{language:'pt-PT',rate:0.96,pitch:0.9})};
 const addMessage=(role,text)=>setMessages(m=>[...m,{id:Date.now().toString()+Math.random(),role,text}]);
 async function startVoice(){try{const p=await ExpoSpeechRecognitionModule.requestPermissionsAsync();if(!p.granted){Alert.alert('Permissão necessária','Autoriza o microfone e o reconhecimento de voz nas definições do Android.');return}ExpoSpeechRecognitionModule.start({lang:'pt-PT', interimResults:true,continuous:false})}catch(e){Alert.alert('Voz indisponível','Instalação/compilação nativa necessária para o reconhecimento de voz. Podes escrever enquanto isso.')}} 
 function stopVoice(){try{ExpoSpeechRecognitionModule.stop()}catch{} setIsListening(false)}
 async function authenticate(){const r=await LocalAuthentication.authenticateAsync({promptMessage:'Confirmar identidade para continuar',fallbackLabel:'PIN do dispositivo'});return !!r.success}
 function navigate(key){setActive(key);setDrawer(false);setModal(false)}
 function parseCommand(raw){
  const s=raw.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
  if(s.includes('modo escuro')){setSettings(x=>({...x,theme:'dark'}));return 'Modo escuro activado.'}
  if(s.includes('modo claro')){setSettings(x=>({...x,theme:'light'}));return 'Modo claro activado.'}
  if(s.includes('parar de falar')||s.includes('silencio')){Speech.stop();return 'Parei a resposta de voz.'}
  if(s.includes('abrir dashboard')||s.includes('mostrar dashboard')){navigate('dashboard');return 'Dashboard aberto.'}
  if(s.includes('abrir produtos')||s.includes('mostrar produtos')){navigate('products');return 'Produtos aberto.'}
  if(s.includes('abrir mercado')){navigate('market');return 'Mercado aberto.'}
  if(s.includes('abrir marketing')){navigate('marketing');return 'Marketing aberto.'}
  if(s.includes('abrir metas')){navigate('goals');return 'Metas abertas.'}
  if(s.includes('abrir configuracoes')){navigate('settings');return 'Configurações abertas.'}
  if(s.includes('ligar lanterna')||s.includes('desligar lanterna')){return 'O controlo da lanterna requer módulo Android nativo. Esta versão não altera o hardware.'}
  if(s.includes('wifi')||s.includes('wi-fi')||s.includes('bluetooth')){Linking.openSettings().catch(()=>{});return 'Abri as definições do Android. Confirma manualmente a alteração.'}
  if(s.includes('ligar para ')){const name=raw.slice(s.indexOf('ligar para ')+11).trim();return 'Para segurança, abre o marcador e confirma o contacto antes de ligar: '+name}
  if(s.includes('atende a chamada')||s.includes('rejeita a chamada')||s.includes('responde ao sms')||s.includes('le o sms'))return 'O Android restringe estas operações a aplicações predefinidas e permissões especiais. Esta versão não atende chamadas nem lê/envia SMS automaticamente.';
  if(s.includes('modo autonomo')){const m=s.match(/(\d+)\s*horas?/);const hours=Math.min(8,Math.max(1,Number(m?.[1]||1)));setSettings(x=>({...x,autonomy:3,autonomyUntil:Date.now()+hours*3600000}));return `Modo autónomo nível 3 solicitado por ${hours} hora(s). Operações financeiras, publicações e acções críticas continuam a exigir aprovação.`}
  if(s.includes('ajuda')||s.includes('comandos'))return 'Podes dizer: abrir dashboard, abrir produtos, abrir mercado, abrir marketing, abrir metas, abrir configurações, modo escuro, modo claro ou parar de falar.';
  return null;
 }
 async function send(text=input){
  const q=text.trim();if(!q)return;setInput('');addMessage('user',q);const command=parseCommand(q);
  if(command){addMessage('assistant',command);speak(command);return}
  const url=(settings.serverUrl||'').replace(/\/$/,'');
  if(!url){const msg='Ainda não há servidor configurado. Abre Configurações e adiciona o endereço HTTPS do backend. Posso guardar os teus dados e rascunhos localmente enquanto isso.';addMessage('assistant',msg);speak(msg);return}
  setBusy(true);
  try{const res=await fetch(url+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:q,provider:settings.provider,conversation:messages.slice(-12)})});if(!res.ok)throw new Error('Servidor respondeu '+res.status);const data=await res.json();const answer=data.response||data.answer||'O servidor não devolveu texto.';if(/sk-[A-Za-z0-9]{15,}|AIza[A-Za-z0-9_-]{20,}|ANTHROPIC_API_KEY/i.test(answer))throw new Error('Resposta bloqueada: possível exposição de segredo.');addMessage('assistant',answer);speak(answer)}catch(e){const msg='Não consegui contactar o servidor: '+e.message+'. Os serviços de IA precisam de backend e credenciais configuradas no servidor, nunca dentro da aplicação.';addMessage('assistant',msg);speak(msg)}finally{setBusy(false)}
 }
 async function saveRecord(){if(!record.title.trim()){Alert.alert('Campo obrigatório','Indica um nome/título.');return}const row={...record,id:Date.now().toString(),createdAt:new Date().toISOString()};updateList([row,...items]);setRecord({title:'',description:'',status:'Rascunho',value:''});setModal(false)}
 async function approve(row){const ok=await authenticate();if(!ok)return;updateList(items.map(x=>x.id===row.id?{...x,status:'Aprovado'}:x));Alert.alert('Aprovado','Aprovação registada localmente. Isto não publica nem movimenta dinheiro.')}
 async function remove(row){Alert.alert('Eliminar','Eliminar este registo?', [{text:'Cancelar',style:'cancel'},{text:'Eliminar',style:'destructive',onPress:()=>updateList(items.filter(x=>x.id!==row.id))}])}
 async function exportData(){const payload=JSON.stringify({store,settings,messages},null,2);await Clipboard.setStringAsync(payload);Alert.alert('Dados copiados','A cópia JSON foi colocada na área de transferência.')}
 function screenTitle(){return MODULES.find(x=>x[2]===active)?.[0]||'LétimaX'}
 function addAction(){setRecord({title:'',description:'',status:'Rascunho',value:''});setModal(true)}
 function Chat(){return <><ScrollView ref={scroll} contentContainerStyle={{padding:14}}>{messages.map(m=><View key={m.id} style={{alignSelf:m.role==='user'?'flex-end':'flex-start',backgroundColor:m.role==='user'?'#EAD9A8':theme.card,borderRadius:14,padding:12,marginVertical:5,maxWidth:'90%'}}><Text style={{color:'#171717'}}>{m.text}</Text></View>)}{busy&&<ActivityIndicator color={GOLD}/>}</ScrollView><View style={{padding:10,borderTopWidth:1,borderColor:theme.line}}><TextInput value={input} onChangeText={setInput} placeholder="Escreve ou usa o microfone..." placeholderTextColor={theme.muted} multiline style={{color:theme.text,backgroundColor:theme.card,borderRadius:12,padding:10,maxHeight:110}}/><View style={{flexDirection:'row',gap:8,marginTop:7}}><View style={{flex:1}}><Button title={isListening?'A ouvir… tocar para parar':'🎙 Falar'} secondary onPress={isListening?stopVoice:startVoice}/></View><View style={{flex:1}}><Button title="Enviar" onPress={()=>send()}/></View></View></View></>}
 function Dashboard(){const products=store.products||[];const sales=store.finance||[];const revenue=sales.filter(x=>x.kind==='Receita').reduce((a,x)=>a+Number(x.value||0),0);return <ScrollView contentContainerStyle={{padding:14}}><Text style={{fontSize:18,fontWeight:'700',color:theme.text}}>Visão geral</Text><View style={{flexDirection:'row',flexWrap:'wrap'}}>{[['Produtos',products.length],['Registos financeiros',sales.length],['Receita registada',money(revenue)+' MT'],['Autonomia','Nível '+settings.autonomy]].map(([a,b])=><View key={a} style={{backgroundColor:theme.card,padding:15,borderRadius:12,width:'48%',margin:'1%'}}><Text style={{color:theme.muted}}>{a}</Text><Text style={{fontWeight:'800',fontSize:19,color:theme.text}}>{b}</Text></View>)}</View><Text style={{color:theme.muted,marginTop:12}}>Os indicadores são calculados a partir dos registos que adicionares. Vendas e integrações externas só aparecem depois de ligares os respectivos serviços.</Text><Button title="Adicionar receita ou despesa" onPress={()=>navigate('finance')}/></ScrollView>}
 function Settings(){return <ScrollView contentContainerStyle={{padding:14}}><Text style={{fontWeight:'800',fontSize:17,color:theme.text}}>Preferências</Text><Text style={{color:theme.muted}}>As chaves secretas devem permanecer no servidor. Não coloques chaves privadas nesta aplicação.</Text><Text style={{fontWeight:'700',marginTop:12,color:theme.text}}>Tema</Text>{['system','light','dark'].map(v=><Button key={v} title={v==='system'?'Automático':v==='light'?'Claro':'Escuro'} secondary={settings.theme!==v} onPress={()=>setSettings(x=>({...x,theme:v}))}/>)}<Text style={{fontWeight:'700',marginTop:10,color:theme.text}}>Servidor HTTPS</Text><Field label="URL do backend" value={settings.serverUrl} onChangeText={v=>setSettings(x=>({...x,serverUrl:v}))} placeholder="https://teu-servidor.example"/><Text style={{fontWeight:'700',marginTop:10,color:theme.text}}>Modelo de IA</Text>{['anthropic','openai','gemini'].map(v=><Button key={v} title={v} secondary={settings.provider!==v} onPress={()=>setSettings(x=>({...x,provider:v}))}/>)}<View style={{flexDirection:'row',justifyContent:'space-between',paddingVertical:12}}><Text style={{color:theme.text}}>Respostas por voz</Text><Switch value={settings.voice} onValueChange={v=>setSettings(x=>({...x,voice:v}))}/></View><Text style={{fontWeight:'700',color:theme.text}}>Autonomia</Text>{[1,2,3].map(v=><Button key={v} title={'Nível '+v} secondary={settings.autonomy!==v} onPress={()=>setSettings(x=>({...x,autonomy:v}))}/>)}<Text style={{color:theme.muted}}>Níveis de autonomia não autorizam pagamentos, levantamentos, compras, anúncios ou publicações críticas. Essas acções exigem aprovação explícita.</Text><Button title="Testar autenticação do dispositivo" onPress={async()=>Alert.alert('Autenticação',await authenticate()?'Autenticação confirmada.':'Autenticação não concluída.')}/><Button title="Abrir definições Android" secondary onPress={()=>Linking.openSettings()}/><Button title="Guardar cópia dos dados" onPress={exportData}/></ScrollView>}
 function Generic(){const label=screenTitle();return <View style={{flex:1,padding:14}}><Text style={{fontSize:18,fontWeight:'700',color:theme.text}}>{label}</Text><Text style={{color:theme.muted,marginVertical:8}}>Registos locais deste módulo. Adiciona e organiza os teus dados; integrações externas precisam de backend, credenciais e contratos API próprios.</Text><Button title={'＋ Novo registo em '+label} onPress={addAction}/><FlatList data={items} keyExtractor={x=>x.id} ListEmptyComponent={<Text style={{color:theme.muted,marginTop:20}}>Ainda não existem registos.</Text>} renderItem={({item})=><View style={{backgroundColor:theme.card,padding:13,borderRadius:12,marginVertical:6}}><Text style={{fontWeight:'700',fontSize:16,color:theme.text}}>{item.title}</Text>{item.description?<Text style={{color:theme.muted,marginTop:4}}>{item.description}</Text>:null}<Text style={{color:theme.muted,marginTop:5}}>Estado: {item.status||'Rascunho'} {item.value?(' · '+item.value):''}</Text><View style={{flexDirection:'row',gap:8,marginTop:8}}>{item.status==='Aguarda Aprovação'&&<View style={{flex:1}}><Button title="Aprovar" onPress={()=>approve(item)}/></View>}<View style={{flex:1}}><Button title="Eliminar" secondary onPress={()=>remove(item)}/></View></View></View>}/></View>}
 if(!ready)return <SafeAreaView style={{flex:1,alignItems:'center',justifyContent:'center'}}><ActivityIndicator color={GOLD}/><Text>A iniciar LétimaX…</Text></SafeAreaView>;
 const isChat=active==='chat',isDashboard=active==='dashboard',isSettings=active==='settings';
 return <SafeAreaView style={{flex:1,backgroundColor:theme.bg}}><StatusBar barStyle={dark?'light-content':'dark-content'} backgroundColor={theme.bg}/><View style={{height:58,flexDirection:'row',alignItems:'center',paddingHorizontal:14,borderBottomWidth:1,borderColor:theme.line}}><Pressable onPress={()=>setDrawer(true)} style={{padding:8}}><Text style={{fontSize:23,color:theme.text}}>☰</Text></Pressable><Text style={{fontSize:19,fontWeight:'800',color:GOLD,flex:1}}>LétimaX</Text><Text style={{color:theme.muted,fontSize:12}}>{screenTitle()}</Text></View>
 {isChat?<Chat/>:isDashboard?<Dashboard/>:isSettings?<Settings/>:<Generic/>}
 <View style={{height:62,borderTopWidth:1,borderColor:theme.line,flexDirection:'row',justifyContent:'space-around',alignItems:'center'}}>{[['chat','Chat'],['dashboard','Painel'],['products','Produtos'],['market','Mercado'],['marketing','Marketing']].map(([k,t])=><Pressable key={k} onPress={()=>navigate(k)} style={{alignItems:'center',padding:5}}><Text style={{fontSize:12,fontWeight:active===k?'800':'500',color:active===k?GOLD:theme.muted}}>{t}</Text></Pressable>)}</View>
 <Modal visible={drawer} animationType="slide" onRequestClose={()=>setDrawer(false)}><SafeAreaView style={{flex:1,backgroundColor:theme.bg,padding:14}}><View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}><Text style={{fontSize:22,fontWeight:'800',color:GOLD}}>LétimaX</Text><Button title="Fechar" secondary onPress={()=>setDrawer(false)}/></View><TextInput placeholder="Pesquisar módulo..." placeholderTextColor={theme.muted} onChangeText={setTranscript} style={{padding:10,borderWidth:1,borderColor:theme.line,borderRadius:10,color:theme.text,marginVertical:10}}/><FlatList data={MODULES.filter(m=>m[0].toLowerCase().includes(transcript.toLowerCase()))} keyExtractor={m=>m[2]} renderItem={({item})=><Pressable onPress={()=>navigate(item[2])} style={{padding:13,borderBottomWidth:1,borderColor:theme.line}}><Text style={{color:theme.text,fontWeight:active===item[2]?'800':'500'}}>{item[0]}</Text><Text style={{color:theme.muted,fontSize:12}}>{item[1]}</Text></Pressable>}/></SafeAreaView></Modal>
 <Modal visible={modal} transparent animationType="slide" onRequestClose={()=>setModal(false)}><KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={{flex:1,justifyContent:'flex-end',backgroundColor:'#0008'}}><View style={{backgroundColor:theme.bg,padding:18,borderTopLeftRadius:18,borderTopRightRadius:18}}><Text style={{fontWeight:'800',fontSize:18,color:theme.text}}>Novo registo — {screenTitle()}</Text><Field label="Título / Nome" value={record.title} onChangeText={v=>setRecord(x=>({...x,title:v}))}/><Field label="Descrição / Detalhes" value={record.description} onChangeText={v=>setRecord(x=>({...x,description:v}))} multiline/><Field label="Valor / preço (opcional)" value={record.value} onChangeText={v=>setRecord(x=>({...x,value:v}))}/><Text style={{color:theme.text,marginTop:5}}>Estado</Text>{['Rascunho','Aguarda Aprovação','Em execução','Publicado','Pausado','Resolvido'].map(v=><Button key={v} title={v} secondary={record.status!==v} onPress={()=>setRecord(x=>({...x,status:v}))}/>) }<Button title="Guardar registo" onPress={saveRecord}/><Button title="Cancelar" secondary onPress={()=>setModal(false)}/></View></KeyboardAvoidingView></Modal>
 </SafeAreaView>;
}
