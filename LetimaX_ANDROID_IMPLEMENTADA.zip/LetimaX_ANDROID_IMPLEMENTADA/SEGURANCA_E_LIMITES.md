# Segurança e limites

- Chaves secretas de serviços externos devem ficar exclusivamente no servidor.
- Acções externas críticas exigem aprovação explícita.
- A aplicação não faz pagamentos, levantamentos, compras ou ordens de trading.
- Chamadas/SMS automáticos, leitura de notificações de outras apps, controlo de Wi-Fi/Bluetooth, volume e serviço persistente exigem implementação Android nativa e permissões especiais. Não estão implementados nesta versão.
- Biometria usa o autenticador do Android; não cria uma assinatura facial/vocal própria.
- Os registos são locais e não usam SQLCipher nesta versão. Não armazenar passwords reais.
- A IA depende do endpoint `/api/chat` no servidor HTTPS. Nunca colocar chaves de API no APK.
