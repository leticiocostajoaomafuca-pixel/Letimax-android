# LétimaX Android — implementação da aplicação

## Conteúdo
- 42 módulos/ecrãs navegáveis, conforme a secção Android do documento.
- Chat com envio por texto, síntese de voz, reconhecimento de voz e comandos locais.
- Persistência local dos registos em AsyncStorage.
- Tema claro/escuro manual, configuração de backend, escolha de fornecedor, nível de autonomia.
- Autenticação biométrica do dispositivo antes de aprovações locais.
- Gestão local de registos, rascunhos e aprovação explícita.
- Exportação de dados JSON para a área de transferência.

## Instalação
Requer Node.js e ambiente Android/Expo:
1. Extrair o ZIP.
2. `npm install`
3. `npx expo install --fix`
4. `npx expo run:android` (requer Android SDK/PC) ou `npx expo start` e abrir com Expo Go quando as dependências forem compatíveis.

O pacote de reconhecimento de voz contém código nativo; para essa função, gerar uma build nativa com `npx expo prebuild` + `npx expo run:android` ou EAS Build. Expo Go pode não incluir o módulo.

## Importante — limites reais
Este projecto implementa a camada de aplicação e operações locais descritas acima. NÃO afirma que todos os serviços externos já estejam ligados.
- APIs Hotmart, Kiwify, Gumroad, Shopify, Mailchimp, Netlify, Zoom, Google Analytics, Meta, TikTok e Binance requerem backend, OAuth/credenciais e testes por fornecedor.
- Chamada/SMS automáticos, acesso a notificações de outras apps, ligar/desligar Wi-Fi/Bluetooth, controlar volume do sistema e serviço permanente requerem módulos Android nativos, permissões especiais, app predefinida e políticas Android. Não são prometidos por esta build Expo.
- Biometria usa a autenticação do Android; não treina nem guarda uma assinatura vocal/facial própria.
- A app não executa pagamentos, levantamentos, compras ou transacções. Binance é apenas para monitorização quando ligada no backend.
- Os dados locais desta versão não são encriptados por SQLCipher; não guardes passwords reais neste protótipo. O cofre de passwords é apenas um módulo de interface e deve ser ligado a armazenamento criptográfico nativo antes de uso real.
- As rotinas de IA dependem do endpoint `/api/chat` no servidor configurado. Nunca colocar chaves de API no APK.

## Verificações
O código foi gerado e organizado. Ainda precisa de instalação de dependências, compilação Android e testes num dispositivo real. Não há garantia de compilação sem ajustar versões conforme o ambiente.
