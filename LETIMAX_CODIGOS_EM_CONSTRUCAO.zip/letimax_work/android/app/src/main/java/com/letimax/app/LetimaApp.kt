package com.letimax.app

import android.app.Application
import androidx.room.Room
import com.letimax.app.data.LetimaDatabase
import com.letimax.app.data.LocalRecord
import com.letimax.app.domain.Brand
import com.letimax.app.net.LetimaApi
import com.letimax.app.prefs.AppPrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LetimaApp : Application() {
    lateinit var db: LetimaDatabase
        private set
    lateinit var prefs: AppPrefs
        private set
    lateinit var api: LetimaApi
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = AppPrefs(this)
        db = Room.databaseBuilder(this, LetimaDatabase::class.java, "letimax.db")
            .addMigrations(LetimaDatabase.MIGRATION_1_2)
            .build()
        api = LetimaApi({ prefs.serverUrl }, { prefs.apiToken })
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                Brand.roomTables.forEach { table ->
                    if (db.dao().records(table).isEmpty()) {
                        db.dao().insertRecord(LocalRecord(tableName = table, payload = "{}"))
                    }
                }
            }
        }
    }

    companion object {
        lateinit var instance: LetimaApp
            private set
    }
}
