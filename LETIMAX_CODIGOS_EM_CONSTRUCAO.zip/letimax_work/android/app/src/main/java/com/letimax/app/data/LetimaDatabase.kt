package com.letimax.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.Index
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "local_records", indices = [Index(value = ["tableName"])])
data class LocalRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tableName: String,
    val payload: String,
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "conversas", indices = [Index(value = ["createdAt"])])
data class ConversasEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val createdAt: String,
)

@Entity(tableName = "passwords", indices = [Index(value = ["platform"])])
data class PasswordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val platform: String,
    val email: String,
    val secretCipher: String,
    val notes: String,
)

@Entity(tableName = "configuracoes")
data class ConfigEntity(
    @PrimaryKey val key: String,
    val value: String,
)

@Entity(tableName = "dashboard_cache")
data class DashboardCacheEntity(
    @PrimaryKey val id: Int = 1,
    val json: String,
    val updatedAt: Long,
)

@Entity(tableName = "perfil_biometrico")
data class BiometricEntity(
    @PrimaryKey val id: Int = 1,
    val voiceCipher: String,
    val faceCipher: String,
    val enrolled: Boolean,
)

@Entity(tableName = "tentativas_acesso")
data class AccessAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val success: Boolean,
    val detail: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "seguranca_log", indices = [Index(value = ["createdAt"])])
data class SecurityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val detail: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "logs_erros")
data class TaskLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val reason: String,
    val attempts: Int,
    val status: String,
)

@Entity(tableName = "offline_queue", indices = [Index(value = ["createdAt"])])
data class OfflineTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val path: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Dao
interface LetimaDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConfig(row: ConfigEntity)

    @Query("SELECT value FROM configuracoes WHERE key = :key LIMIT 1")
    suspend fun getConfig(key: String): String?

    @Query("SELECT * FROM configuracoes")
    suspend fun allConfig(): List<ConfigEntity>

    @Insert
    suspend fun insertConversation(row: ConversasEntity)

    @Query("SELECT * FROM conversas ORDER BY id DESC LIMIT 80")
    suspend fun conversations(): List<ConversasEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBiometric(row: BiometricEntity)

    @Query("SELECT * FROM perfil_biometrico WHERE id = 1")
    suspend fun biometric(): BiometricEntity?

    @Insert
    suspend fun insertAttempt(row: AccessAttemptEntity)

    @Insert
    suspend fun insertSecurity(row: SecurityLogEntity)

    @Query("SELECT * FROM seguranca_log ORDER BY id DESC LIMIT 100")
    suspend fun securityLogs(): List<SecurityLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDashboard(row: DashboardCacheEntity)

    @Query("SELECT * FROM dashboard_cache WHERE id = 1")
    suspend fun dashboard(): DashboardCacheEntity?

    @Insert
    suspend fun insertPassword(row: PasswordEntity)

    @Query("SELECT * FROM passwords")
    suspend fun passwords(): List<PasswordEntity>

    @Insert
    suspend fun insertRecord(row: LocalRecord)

    @Query("SELECT * FROM local_records WHERE tableName = :table ORDER BY id DESC")
    suspend fun records(table: String): List<LocalRecord>

    @Insert
    suspend fun insertTask(row: TaskLogEntity)

    @Query("SELECT * FROM logs_erros ORDER BY id DESC LIMIT 100")
    suspend fun tasks(): List<TaskLogEntity>

    @Query("UPDATE logs_erros SET status = :status, attempts = attempts + 1 WHERE id = :id")
    suspend fun bumpTask(id: Long, status: String)

    @Insert
    suspend fun enqueue(row: OfflineTaskEntity)

    @Query("SELECT * FROM offline_queue")
    suspend fun queue(): List<OfflineTaskEntity>

    @Query("DELETE FROM offline_queue WHERE id = :id")
    suspend fun dequeue(id: Long)
}

@Database(
    entities = [
        LocalRecord::class, ConversasEntity::class, PasswordEntity::class, ConfigEntity::class,
        DashboardCacheEntity::class, BiometricEntity::class, AccessAttemptEntity::class,
        SecurityLogEntity::class, TaskLogEntity::class, OfflineTaskEntity::class,
    ],
    version = 2,
    exportSchema = false,
)
abstract class LetimaDatabase : RoomDatabase() {
    companion object {
        /** Migração não destrutiva: preserva os dados da versão 1. */
        val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS index_local_records_tableName ON local_records(tableName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_conversas_createdAt ON conversas(createdAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_passwords_platform ON passwords(platform)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_seguranca_log_createdAt ON seguranca_log(createdAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_offline_queue_createdAt ON offline_queue(createdAt)")
            }
        }
    }

    abstract fun dao(): LetimaDao
}
