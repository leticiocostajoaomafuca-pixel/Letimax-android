package com.letimax.app.net

import com.letimax.app.domain.Security
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Cliente HTTP centralizado. Em produção exige HTTPS e envia token Bearer. */
class LetimaApi(
    private val baseUrlProvider: () -> String,
    private val tokenProvider: () -> String,
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .callTimeout(75, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun buildUrl(path: String): String {
        val base = baseUrlProvider().trim().trimEnd('/')
        require(base.startsWith("https://", ignoreCase = true)) {
            "Configure o endereço HTTPS do servidor nas Definições."
        }
        require(path.startsWith("/") && !path.startsWith("//")) { "Caminho da API inválido." }
        return "$base$path"
    }

    private fun request(path: String): Request.Builder {
        val builder = Request.Builder().url(buildUrl(path)).header("Accept", "application/json")
        tokenProvider().trim().takeIf { it.isNotEmpty() }?.let {
            builder.header("Authorization", "Bearer $it")
        }
        return builder
    }

    private fun decode(code: Int, raw: String): JSONObject {
        val safe = Security.redactSecrets(raw)
        val value = safe.trim()
        val result = when {
            value.isEmpty() -> JSONObject()
            value.startsWith("[") -> JSONObject().put("items", JSONArray(value))
            else -> runCatching { JSONObject(value) }
                .getOrElse { JSONObject().put("error", "Resposta inválida do servidor.") }
        }
        if (code !in 200..299) {
            throw IllegalStateException(result.optString("error").ifBlank { "Erro HTTP $code." })
        }
        return result
    }

    suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        client.newCall(request(path).get().build()).execute().use {
            decode(it.code, it.body?.string().orEmpty())
        }
    }

    suspend fun post(path: String, body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val req = request(path).post(body.toString().toRequestBody(jsonType)).build()
        client.newCall(req).execute().use { decode(it.code, it.body?.string().orEmpty()) }
    }

    suspend fun delete(path: String): JSONObject = withContext(Dispatchers.IO) {
        client.newCall(request(path).delete().build()).execute().use {
            decode(it.code, it.body?.string().orEmpty())
        }
    }
}
