const API = "/api";

export async function api(path, opts = {}) {
  const token = sessionStorage.getItem("letimax_api_token") || "";
  const headers = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(opts.headers || {}),
  };
  const res = await fetch(`${API}${path}`, {
    ...opts,
    headers,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || `HTTP ${res.status}`);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

export function saveApiToken(token) {
  const value = String(token || "").trim();
  if (value) sessionStorage.setItem("letimax_api_token", value);
  else sessionStorage.removeItem("letimax_api_token");
}
