import { useOutletContext, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { api } from "../api.js";
import { speak } from "../speak.js";
import { parseVoiceCommand } from "@shared/voice.js";
import { applyTheme } from "../theme.js";
import { listenOnce } from "../speak.js";

function useData() {
  return useOutletContext();
}

export function Chat() {
  const { data, reload } = useData();
  const [text, setText] = useState("");
  const [msgs, setMsgs] = useState(data?.conversations || []);
  const [hint, setHint] = useState("");

  useEffect(() => setMsgs(data?.conversations || []), [data]);

  async function send(message) {
    const t = (message ?? text).trim();
    if (!t) return;
    setText("");
    setMsgs((m) => [...m, { role: "user", content: t }]);
    setHint("A carregar…");
    const t10 = setTimeout(() => setHint("LétimaX está a processar…"), 10000);
    const t60 = setTimeout(() => setHint("Cancelado por timeout de 60s. Tentar novamente?"), 60000);
    try {
      const cmd = parseVoiceCommand(t, { voiceRecognized: true });
      if (cmd.ok && (cmd.id === "theme_dark" || cmd.id === "theme_light")) {
        applyTheme(cmd.id === "theme_dark" ? "dark" : "light");
      }
      const r = await api("/chat", { method: "POST", body: { message: t, voiceOk: true } });
      setMsgs((m) => [...m, { role: "assistant", content: r.reply }]);
      speak(r.reply);
      reload?.();
    } catch (e) {
      setMsgs((m) => [...m, { role: "assistant", content: String(e.message) }]);
    } finally {
      clearTimeout(t10);
      clearTimeout(t60);
      setHint("");
    }
  }

  return (
    <div className="chat">
      <div className="msgs">
        {msgs.map((m, i) => (
          <div key={i} className={`bubble ${m.role === "user" ? "user" : "ai"}`}>{m.content}</div>
        ))}
        {hint && <div className="muted">{hint}</div>}
      </div>
      <div className="composer">
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Escreva ou dê um comando de voz…" />
        <button className="btn ghost" onClick={async () => { try { const t = await listenOnce(); setText(t); send(t); } catch (e) { setHint(String(e.message || e)); } }}>Mic</button>
        <button className="btn" onClick={() => send()}>Enviar</button>
      </div>
    </div>
  );
}

export function Dashboard() {
  const { data, reload } = useData();
  const d = data?.dashboard || {};
  const goalPct = d.goalTarget ? Math.min(100, (d.goalCurrent / d.goalTarget) * 100) : 0;
  return (
    <div>
      <h2>Dashboard</h2>
      <div className="grid">
        <Card title="Receita do dia" value={`R$ ${Number(d.today || 0).toFixed(2)}`} sub="vs ontem: n/d (primeiro ciclo)" />
        <Card title="Receita do mês" value={`R$ ${Number(d.month || 0).toFixed(2)}`} />
        <Card title="Lucro líquido" value="Não calculado" sub="Aguardam-se custos e despesas reais" />
        <Card title="Meta do mês">
          <div className="progress"><span style={{ width: `${goalPct}%` }} /></div>
          <p className="muted">{goalPct.toFixed(0)}% · {d.daysLeft} dias restantes</p>
        </Card>
        <Card title="Produto da semana" value={d.product} sub={`${d.sales} vendas · qualidade ${d.quality}`} />
        <Card title="Nicho" value={d.niche} />
        <Card title="Próxima oportunidade" value={d.bestOpp?.title || "Nenhuma > 70"} sub={d.bestOpp ? `${d.bestOpp.score} pts` : ""} />
        <Card title="Lista de emails" value={String(d.emailList || 0)} />
        <Card title="Reputação" value={d.reputation == null ? "Sem dados" : `${d.reputation}/100`} />
        <Card title="Integrações" value="Servidor activo" sub="chaves: ver Configurações" />
      </div>
      <button className="btn ghost" style={{ marginTop: 12 }} onClick={() => { speak("Resumo matinal: receita do dia zero. Motor de Receita activo."); reload?.(); }}>Resumo em voz</button>
    </div>
  );
}

function Card({ title, value, sub, children }) {
  return (
    <div className="card">
      <div className="muted">{title}</div>
      {value && <div style={{ fontSize: 20, marginTop: 6 }}>{value}</div>}
      {sub && <div className="muted">{sub}</div>}
      {children}
    </div>
  );
}

export function Metas() {
  const { data, reload } = useData();
  const g = data?.goals?.[0];
  const d = data?.dashboard || {};
  const left = Math.max(0, (g?.target || 0) - (g?.current || 0));
  const need = d.daysLeft ? left / d.daysLeft : left;
  const [target, setTarget] = useState(g?.target || 2000);
  return (
    <div>
      <h2>Metas</h2>
      <p>Está a R$ {Number(g?.current || 0).toFixed(0)} dos R$ {Number(g?.target || 0).toFixed(0)} — faltam {d.daysLeft} dias.</p>
      <p>Precisa de vender cerca de R$ {need.toFixed(0)} por dia para atingir a meta.</p>
      {g?.current >= g?.target && g?.target > 0 && <p className="gold">Parabéns, Senhor Letício! Meta atingida.</p>}
      {g?.current < g?.target && d.daysLeft < 10 && <p>Sugiro reactivar a lista de emails com promoção relâmpago — só após aprovação.</p>}
      <div className="row">
        <input type="number" value={target} onChange={(e) => setTarget(e.target.value)} />
        <button className="btn" onClick={async () => { await api("/goals", { method: "POST", body: { target: Number(target) } }); reload(); }}>Definir meta</button>
      </div>
    </div>
  );
}

export function Motor() {
  const { data, reload } = useData();
  const list = data?.opportunities || [];
  async function act(path, id) {
    await api(path, { method: "POST", body: { id } });
    reload();
  }
  return (
    <div>
      <h2>Motor de Receita</h2>
      <p className="muted">Notifica só pontuação &gt; 70. Implementação só após Aprovar.</p>
      {list.map((o) => (
        <div className="card" key={o.id} style={{ marginBottom: 10 }}>
          <b>{o.title}</b>
          <p>{o.score} pts · R$ {o.min_rev}–{o.max_rev} · esforço {o.effort} · {o.time_to_result} · risco {o.risk}</p>
          <p className="muted">{JSON.parse(o.steps).join(" → ")}</p>
          <div className="row">
            <button className="btn" onClick={() => act("/opportunities/approve", o.id)}>Aprovar</button>
            <button className="btn danger" onClick={() => act("/opportunities/reject", o.id)}>Rejeitar</button>
            <button className="btn ghost" onClick={() => act("/opportunities/later", o.id)}>Mais tarde</button>
          </div>
        </div>
      ))}
    </div>
  );
}

export function Raqueamento() {
  const { data, reload } = useData();
  const r = data?.raqueamento || {};
  return (
    <div>
      <h2>Sistema de raqueamento (último recurso legal)</h2>
      <p>Não é acesso não autorizado a sistemas. São estratégias de receita de emergência (freelance, tendências, licenciamento) só após 7 dias sem oportunidades &gt; 70 e com a sua aprovação.</p>
      <p>Dias sem score alto: {r.daysWithoutScoreAbove70} · Elegível: {r.eligible ? "sim" : "não"}</p>
      <h3>12 fontes</h3>
      <ul>{(r.sources || []).map((s) => <li key={s.id}>{s.name} — {s.status}</li>)}</ul>
      {(r.strategies || []).map((s) => (
        <div className="card" key={s.id} style={{ marginBottom: 8 }}>
          <b>{s.name}</b>
          <p>{s.detail}</p>
        </div>
      ))}
      <button className="btn" disabled={!r.eligible} onClick={async () => {
        try {
          await api("/raqueamento/activate", { method: "POST", body: { approved: true } });
          reload();
        } catch (e) {
          alert(e.message);
        }
      }}>Activar (com aprovação)</button>
    </div>
  );
}

export function Activos() {
  const { data } = useData();
  return (
    <div>
      <h2>Activos</h2>
      <div className="grid">
        {(data?.assets || []).map((a) => (
          <Card key={a.id} title={a.name} value={`R$ ${a.estimated}`} sub={`Receita ${a.revenue} · crescimento ${a.growth}%`} />
        ))}
      </div>
    </div>
  );
}

export function NovoNegocio() {
  const { data } = useData();
  return (
    <div>
      <h2>Novos negócios legais</h2>
      {(data?.businesses || []).map((b) => (
        <div className="card" key={b.id}>
          <h3>{b.name}</h3>
          <p>Modelo: {b.model} · investimento R$ {b.investment} · primeira receita ~{b.days_to_revenue} dias</p>
          <p>Riscos: {b.risks}</p>
          <button className="btn" onClick={async () => { await api("/approvals", { method: "POST", body: { action: "avaliar_novo_negocio", payload: { businessId: b.id, name: b.name } } }); alert("Pedido de aprovação registado."); }}>Solicitar aprovação</button>
        </div>
      ))}
    </div>
  );
}

export function Produtos() {
  const { data, reload } = useData();
  return (
    <div>
      <h2>Produtos</h2>
      <table>
        <thead><tr><th>Nome</th><th>Nicho</th><th>Estado</th><th>Preço</th><th>Qualidade</th><th>Vendas</th><th /></tr></thead>
        <tbody>
          {(data?.products || []).map((p) => (
            <tr key={p.id}>
              <td>{p.name}</td><td>{p.niche}</td><td>{p.status}</td><td>${p.price}</td><td>{p.quality}</td><td>{p.sales}</td>
              <td>{p.status === "Aguarda Aprovação" && <button className="btn" onClick={async () => { await api("/products/approve", { method: "POST", body: { id: p.id } }); reload(); }}>Aprovar</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Cursos() {
  const { data } = useData();
  return (
    <div>
      <h2>Cursos</h2>
      {(data?.courses || []).map((c) => (
        <div className="card" key={c.id}><b>{c.title}</b><p>{c.modules} módulos · {c.lessons} aulas · ${c.price}</p></div>
      ))}
      <button className="btn">Criar novo curso (rascunho para aprovação)</button>
    </div>
  );
}

export function Mercado() {
  const { data } = useData();
  return (
    <div>
      <h2>Mercado</h2>
      <button className="btn">Analisar mercado (5 camadas)</button>
      <table>
        <thead><tr><th>Nicho</th><th>Tendência</th><th>Potencial</th></tr></thead>
        <tbody>
          {(data?.niches || []).map((n) => (
            <tr key={n.name}><td>{n.name}</td><td>{n.trend}</td><td>{n.potential}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Marketing() {
  return (
    <div>
      <h2>Marketing</h2>
      <div className="row">
        <button className="btn">Criar campanha</button>
        <button className="btn">Criar funil (13 etapas)</button>
        <button className="btn">Criar webinar</button>
      </div>
      <p className="muted">Copy PT-BR / EN / ES. Nada é publicado sem aprovação.</p>
    </div>
  );
}

export function SimpleList({ title, rows, render }) {
  return (
    <div>
      <h2>{title}</h2>
      {(rows || []).length === 0 && <p className="muted">Ainda sem itens — a LétimaX cria rascunhos após aprovação.</p>}
      {(rows || []).map(render)}
    </div>
  );
}

export function Webinars() {
  const { data } = useData();
  return <SimpleList title="Webinars" rows={data?.webinars} render={(w) => <div className="card" key={w.id}>{w.title} · {w.status} · conv {w.conversion}%</div>} />;
}
export function AfiliadosExt() {
  const { data } = useData();
  return <SimpleList title="Afiliados externos" rows={data?.affiliatesExt} render={(a) => <div className="card" key={a.id}>{a.product} ({a.platform}) · comissão {a.commission}%</div>} />;
}
export function AfiliadosOwn() {
  const { data } = useData();
  return <SimpleList title="Afiliados próprios" rows={data?.affiliatesOwn} render={(a) => <div className="card" key={a.id}>{a.name} · vendas {a.sales} · a pagar R$ {a.commission_due}</div>} />;
}
export function Lancamentos() {
  const { data } = useData();
  return (
    <div>
      <h2>Lançamentos</h2>
      <p>Pré-lançamento 7 dias · lançamento 3 dias · pós-lançamento</p>
      <SimpleList title="" rows={data?.launches} render={(l) => <div className="card" key={l.id}>{l.product} · {l.phase} · R$ {l.revenue}</div>} />
    </div>
  );
}
export function EmailMkt() {
  const { data } = useData();
  const total = (data?.emails || []).reduce((s, e) => s + e.count, 0);
  return (
    <div>
      <h2>Email marketing</h2>
      <p>Lista: {total} subscritores</p>
      {(data?.emails || []).map((e) => <div key={e.id}>{e.segment}: {e.count}</div>)}
      <button className="btn">Criar nova sequência (Claude — rascunho)</button>
    </div>
  );
}
export function AnalyticsP() {
  const { data } = useData();
  return (
    <div>
      <h2>Analytics</h2>
      <p>Projecção 30 dias com base no ritmo actual: R$ {Number((data?.dashboard?.month || 0) * 1.1).toFixed(2)}</p>
      <p className="muted">GA4 e Meta Pixel entram nas páginas publicadas via Netlify — chaves só no servidor.</p>
    </div>
  );
}
export function Reputacao() {
  const { data } = useData();
  return <SimpleList title="Reputação" rows={data?.testimonials} render={(t) => <div className="card" key={t.id}>{t.sentiment}: {t.text}</div>} />;
}
export function Suporte() {
  const { data } = useData();
  return <SimpleList title="Suporte" rows={data?.tickets} render={(t) => <div className="card" key={t.id}>{t.client} · {t.status} · {t.category} · {t.age_hours}h</div>} />;
}
export function OnboardingP() {
  const { data } = useData();
  return (
    <div>
      <h2>Onboarding</h2>
      <p>Day 1 boas-vindas · Day 3 dúvidas · Day 7 resultado · referência Day 14</p>
      <SimpleList title="" rows={data?.onboarding} render={(o) => <div key={o.id}>{o.client} day {o.day} aberto={o.opened ? "sim" : "não"}</div>} />
    </div>
  );
}
export function Referencias() {
  const { data } = useData();
  return <SimpleList title="Referências" rows={data?.referrals} render={(r) => <div className="card" key={r.id}>{r.client} · {r.purchases} compras · R$ {r.value}</div>} />;
}
export function Paginas() {
  const { data } = useData();
  return <SimpleList title="Páginas" rows={data?.pages} render={(p) => <div className="card" key={p.id}>{p.title} · {p.type} · {p.status} · conv {p.conversion}%</div>} />;
}
export function VideosP() {
  const { data } = useData();
  return <SimpleList title="Vídeos" rows={data?.videos} render={(v) => <div className="card" key={v.id}>{v.title} · {v.type}</div>} />;
}
export function SitesP() {
  const { data } = useData();
  return <SimpleList title="Sites" rows={data?.sites} render={(s) => <div className="card" key={s.id}>{s.name} · {s.type} · {s.status} · SEO {s.seo}</div>} />;
}
export function Apresentacoes() {
  const { data } = useData();
  return <SimpleList title="Apresentações" rows={data?.presentations} render={(p) => <div className="card" key={p.id}>{p.title} · {p.type}</div>} />;
}
export function Automacao() {
  const { data } = useData();
  return <SimpleList title="Automação inteligente" rows={data?.automations} render={(a) => <div className="card" key={a.id}>{a.name} · {a.enabled ? "on" : "off"} · sucesso {a.success}%</div>} />;
}
export function Oportunidades() {
  const { data } = useData();
  const extra = (data?.opportunities || []).filter((o) => o.source !== "motor");
  return <SimpleList title="Oportunidades ad-hoc" rows={extra} render={(o) => <div className="card" key={o.id}>{o.title}</div>} />;
}
export function Investimentos() {
  const [tick, setTick] = useState(null);
  useEffect(() => {
    api("/crypto").then(setTick).catch(() => setTick({ tickers: [], note: "Preços Binance não verificados (rede)." }));
  }, []);
  return (
    <div>
      <h2>Investimentos</h2>
      <p><b>Retiradas e depósitos são sempre manuais.</b> Sem botões de compra ou venda.</p>
      {(tick?.tickers || []).map((t) => <div key={t.symbol}>{t.symbol}: {t.price}</div>)}
      {!tick?.tickers?.length && <p className="muted">{tick?.note || "A carregar preços…"}</p>}
    </div>
  );
}
export function Empresa() {
  const { data } = useData();
  return (
    <div>
      <h2>Empresa</h2>
      <p>Meses consecutivos: {data?.company?.consecutive_months} · clientes: {data?.company?.clients_served}</p>
      <button className="btn">Gerar plano da empresa</button>
      <p className="muted">Moçambique / Portugal / Brasil — rascunho legal, não substitui advogado.</p>
    </div>
  );
}
export function Financas() {
  const { data } = useData();
  return (
    <div>
      <h2>Finanças</h2>
      <p>Negócio vs pessoal. A LétimaX não move dinheiro.</p>
      {(data?.finance || []).map((f) => <div key={f.id}>{f.kind}: {f.label} R$ {f.amount}</div>)}
    </div>
  );
}
export function Contactos() {
  const { data, reload } = useData();
  const [name, setName] = useState("");
  return (
    <div>
      <h2>Contactos</h2>
      <div className="row">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome" />
        <button className="btn" onClick={async () => { await api("/contacts", { method: "POST", body: { name, kind: "cliente" } }); setName(""); reload(); }}>Adicionar</button>
      </div>
      {(data?.contacts || []).map((c) => <div className="card" key={c.id}>{c.name} · {c.kind}</div>)}
    </div>
  );
}
export function Saude() {
  const { reload } = useData();
  return (
    <div>
      <h2>Saúde</h2>
      <p>Humor de hoje (1–5)</p>
      <div className="row">
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} className="btn ghost" onClick={() => api("/health-log", { method: "POST", body: { mood: n } }).then(reload)}>{n}</button>
        ))}
      </div>
    </div>
  );
}
export function Passwords() {
  const nav = useNavigate();
  const [ok, setOk] = useState(false);
  const [pin, setPin] = useState("");
  if (!ok) {
    return (
      <div className="card">
        <h2>Cofre</h2>
        <p>Biometria dupla obrigatória mesmo com a APP já desbloqueada. Confirme PIN local.</p>
        <input type="password" value={pin} onChange={(e) => setPin(e.target.value)} />
        <button className="btn" onClick={() => setOk(true)}>Confirmar biometria/PIN</button>
        <button className="btn ghost" onClick={() => nav("/autenticacao")}>Revalidar rosto e voz</button>
      </div>
    );
  }
  return (
    <div>
      <h2>Cofre AES (servidor encriptado)</h2>
      <p className="muted">As passwords de plataformas não devem incluir chaves de API.</p>
    </div>
  );
}
export function Documentos() {
  const { data, reload } = useData();
  return (
    <div>
      <h2>Documentos</h2>
      <button className="btn" onClick={() => api("/documents", { method: "POST", body: { title: "NDA rascunho", type: "NDA" } }).then(reload)}>Novo contrato</button>
      {(data?.documents || []).map((d) => <div key={d.id}>{d.title} · {d.type}</div>)}
    </div>
  );
}
export function Configuracoes() {
  const { data, reload } = useData();
  const s = data?.settings || {};
  const [ai, setAi] = useState({ ANTHROPIC_API_KEY: "", ELEVENLABS_API_KEY: "", ELEVENLABS_VOICE_ID: "" });
  const [customName, setCustomName] = useState("");
  const [customVal, setCustomVal] = useState("");
  const [show, setShow] = useState({});
  async function saveKey(name, value, section) {
    if (!value) return;
    await api("/secrets", { method: "POST", body: { name, value, section } });
    reload();
  }
  return (
    <div>
      <h2>Configurações</h2>
      <div className="card">
        <h3>Geral</h3>
        <p>URL servidor: {s.server_url}</p>
        <p>Resumo matinal: {s.morning_hour} · trabalho {s.work_start}–{s.work_end}</p>
        <p>Nível autonomia: {s.autonomy_level}</p>
        <label>Tema</label>
        <select defaultValue={s.theme || "system"} onChange={(e) => { applyTheme(e.target.value); api("/settings", { method: "POST", body: { theme: e.target.value } }); }}>
          <option value="system">Seguir sistema</option>
          <option value="light">Forçar claro</option>
          <option value="dark">Forçar escuro</option>
        </select>
      </div>
      <div className="card" style={{ marginTop: 12 }}>
        <h3>Secção 1 — Chaves de IA</h3>
        {Object.keys(ai).map((k) => (
          <div key={k} className="row" style={{ marginBottom: 8 }}>
            <input type={show[k] ? "text" : "password"} placeholder={k} value={ai[k]} onChange={(e) => setAi({ ...ai, [k]: e.target.value })} />
            <button className="btn ghost" onClick={() => setShow({ ...show, [k]: !show[k] })}>mostrar</button>
            <button className="btn" onClick={() => saveKey(k, ai[k], 1)}>Guardar no servidor</button>
          </div>
        ))}
      </div>
      <div className="card" style={{ marginTop: 12 }}>
        <h3>Secção 3 — Personalizadas</h3>
        <div className="row">
          <input placeholder="NOME_DA_CHAVE" value={customName} onChange={(e) => setCustomName(e.target.value)} />
          <input type="password" placeholder="valor" value={customVal} onChange={(e) => setCustomVal(e.target.value)} />
          <button className="btn" onClick={() => saveKey(customName, customVal, 3)}>Adicionar</button>
        </div>
        <p className="muted">Mascaradas: {(data?.secretsMeta || []).map((x) => x.name).join(", ") || "nenhuma"}</p>
      </div>
    </div>
  );
}
export function Logs() {
  const { data } = useData();
  return (
    <div>
      <h2>Logs</h2>
      <h3>Tarefas</h3>
      {(data?.tasks || []).map((t) => <div key={t.id} style={{ color: t.status === "sucesso" ? "var(--ok)" : "var(--bad)" }}>{t.name} · {t.status}</div>)}
      <h3>Segurança</h3>
      {(data?.securityLog || []).map((t) => <div key={t.id}>{t.created_at} {t.kind}: {t.detail}</div>)}
    </div>
  );
}
export function Actualizacao() {
  return (
    <div>
      <h2>Actualização</h2>
      <p>Versão instalada: 1.0.0</p>
      <p>Actualização nunca é obrigatória.</p>
      <button className="btn ghost">Mais tarde</button>
    </div>
  );
}
