import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";
import { openDb, seedIfEmpty, defaultDbPath } from "./db.js";
import {
  chatReply,
  dashboardSnapshot,
  getSetting,
  setSetting,
  approveOpportunity,
} from "./engine.js";
import { redactSecrets, maskSecret, requestsApiKeys } from "../shared/security.js";
import { lockoutForFailures, isLockActive } from "../shared/lockout.js";
import { raqueamentoEligible, daysSinceLastHighScore } from "../shared/raqueamento.js";
import { RAQUEAMENTO_STRATEGIES, OWNER } from "../shared/constants.js";
import { canPerform } from "../shared/autonomy.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function createServer({ dbPath = defaultDbPath(), port = 8787 } = {}) {
  if (process.env.NODE_ENV === "production" && !process.env.LETIMAX_API_TOKEN) {
    throw new Error("LETIMAX_API_TOKEN é obrigatório em produção.");
  }
  const db = openDb(dbPath);
  seedIfEmpty(db);

  const server = http.createServer(async (req, res) => {
    cors(res);
    if (req.method === "OPTIONS") {
      res.writeHead(204);
      res.end();
      return;
    }
    try {
      const url = new URL(req.url, "http://127.0.0.1");
      const body = await readBody(req);
      const isHealth = req.method === "GET" && url.pathname === "/api/health";
      const expectedToken = process.env.LETIMAX_API_TOKEN;
      let authenticatedOwner = false;
      if (!isHealth && expectedToken) {
        const supplied = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
        const a = Buffer.from(supplied);
        const b = Buffer.from(expectedToken);
        if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
          json(res, 401, { error: "não autorizado" });
          return;
        }
        authenticatedOwner = true;
      }
      const handled = await route(db, req.method, url, body, res, { authenticatedOwner });
      if (!handled) {
        json(res, 404, { error: "não encontrado" });
      }
    } catch (err) {
      json(res, 500, { error: "erro interno. Consulte os registos privados do servidor." });
    }
  });

  server.letimaxDb = db;
  server.letimaxListen = () =>
    new Promise((resolve, reject) => {
      const host = process.env.HOST || (process.env.NODE_ENV === "production" ? "0.0.0.0" : "127.0.0.1");
      server.once("error", reject);
      server.listen(port, host, () => {
        server.removeListener("error", reject);
        resolve(server);
      });
    });
  return server;
}

async function route(db, method, url, body, res, auth = {}) {
  const p = url.pathname;

  if (method === "GET" && p === "/api/health") {
    json(res, 200, { ok: true, name: "LétimaX", owner: OWNER.name });
    return true;
  }

  if (method === "GET" && p === "/api/dashboard") {
    json(res, 200, dashboardSnapshot(db));
    return true;
  }

  if (method === "GET" && p === "/api/bootstrap") {
    json(res, 200, {
      dashboard: dashboardSnapshot(db),
      settings: allSettings(db),
      products: db.prepare("SELECT * FROM products").all(),
      opportunities: db.prepare("SELECT * FROM opportunities ORDER BY score DESC").all(),
      niches: db.prepare("SELECT * FROM niches ORDER BY potential DESC").all(),
      sources: db.prepare("SELECT * FROM revenue_sources").all(),
      goals: db.prepare("SELECT * FROM goals").all(),
      emails: db.prepare("SELECT * FROM emails").all(),
      assets: db.prepare("SELECT * FROM assets").all(),
      pages: db.prepare("SELECT * FROM pages").all(),
      courses: db.prepare("SELECT * FROM courses").all(),
      webinars: db.prepare("SELECT * FROM webinars").all(),
      contacts: db.prepare("SELECT * FROM contacts").all(),
      tickets: db.prepare("SELECT * FROM tickets").all(),
      finance: db.prepare("SELECT * FROM finance").all(),
      health: db.prepare("SELECT * FROM health ORDER BY id DESC LIMIT 30").all(),
      documents: db.prepare("SELECT * FROM documents").all(),
      affiliatesExt: db.prepare("SELECT * FROM affiliates_ext").all(),
      affiliatesOwn: db.prepare("SELECT * FROM affiliates_own").all(),
      launches: db.prepare("SELECT * FROM launches").all(),
      testimonials: db.prepare("SELECT * FROM testimonials").all(),
      sites: db.prepare("SELECT * FROM sites").all(),
      videos: db.prepare("SELECT * FROM videos").all(),
      presentations: db.prepare("SELECT * FROM presentations").all(),
      automations: db.prepare("SELECT * FROM automations").all(),
      businesses: db.prepare("SELECT * FROM businesses").all(),
      onboarding: db.prepare("SELECT * FROM onboarding").all(),
      referrals: db.prepare("SELECT * FROM referrals").all(),
      crypto: db.prepare("SELECT * FROM crypto_watch").all(),
      company: Object.fromEntries(db.prepare("SELECT key, value FROM company").all().map((r) => [r.key, r.value])),
      conversations: db.prepare("SELECT * FROM conversations ORDER BY id DESC LIMIT 50").all().reverse(),
      tasks: db.prepare("SELECT * FROM tasks ORDER BY id DESC LIMIT 50").all(),
      securityLog: db.prepare("SELECT * FROM security_log ORDER BY id DESC LIMIT 50").all(),
      vaultMeta: db.prepare("SELECT id, platform, email FROM vault").all(),
      secretsMeta: db.prepare("SELECT name, section FROM secrets").all(),
      raqueamento: raqueamentoState(db),
    });
    return true;
  }

  if (method === "POST" && p === "/api/chat") {
    // Nunca confiar em body.owner: o cliente pode alterar esse campo.
    // Só uma requisição validada pelo token do servidor recebe privilégios de proprietário.
    const owner = auth.authenticatedOwner === true;
    const reply = chatReply(db, body.message, { owner, voiceOk: body.voiceOk !== false });
    const safe = redactSecrets(reply.reply);
    db.prepare("INSERT INTO conversations (role, content, created_at) VALUES (?,?,?)").run(
      "user",
      String(body.message || "").slice(0, 4000),
      new Date().toISOString()
    );
    db.prepare("INSERT INTO conversations (role, content, created_at) VALUES (?,?,?)").run(
      "assistant",
      safe,
      new Date().toISOString()
    );
    json(res, 200, { ...reply, reply: safe });
    return true;
  }

  if (method === "POST" && p === "/api/opportunities/approve") {
    json(res, 200, approveOpportunity(db, Number(body.id)));
    return true;
  }
  if (method === "POST" && p === "/api/opportunities/reject") {
    db.prepare("UPDATE opportunities SET status='rejeitada' WHERE id=?").run(Number(body.id));
    json(res, 200, { ok: true });
    return true;
  }
  if (method === "POST" && p === "/api/opportunities/later") {
    db.prepare("UPDATE opportunities SET status='adiada' WHERE id=?").run(Number(body.id));
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/products/approve") {
    db.prepare("UPDATE products SET status='Publicado' WHERE id=? AND status='Aguarda Aprovação'").run(
      Number(body.id)
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/settings") {
    for (const [k, v] of Object.entries(body || {})) {
      if (k === "niche" && getSetting(db, "niche") !== String(v)) {
        json(res, 400, { error: "Mudança de nicho só com aprovação explícita via /api/niche/approve" });
        return true;
      }
      setSetting(db, k, v);
    }
    json(res, 200, { ok: true, settings: allSettings(db) });
    return true;
  }

  if (method === "POST" && p === "/api/niche/approve") {
    setSetting(db, "niche", body.niche);
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/secrets") {
    if (process.env.NODE_ENV === "production" && auth.authenticatedOwner !== true) {
      json(res, 401, { error: "autenticação do proprietário obrigatória" }); return true;
    }
    if (requestsApiKeys(JSON.stringify(body))) {
      /* storing is allowed; revealing is not */
    }
    const name = String(body.name || "").trim();
    const value = String(body.value || "");
    if (!name || !value) {
      json(res, 400, { error: "nome e valor obrigatórios" });
      return true;
    }
    if (process.env.NODE_ENV === "test") {
      /* keep in db hashed */
    }
    const enc = encrypt(value);
    db.prepare(
      "INSERT INTO secrets(name,value,section,updated_at) VALUES(?,?,?,?) ON CONFLICT(name) DO UPDATE SET value=excluded.value, section=excluded.section, updated_at=excluded.updated_at"
    ).run(name, enc, Number(body.section || 3), new Date().toISOString());
    json(res, 200, { ok: true, name, masked: maskSecret(value) });
    return true;
  }

  if (method === "GET" && p === "/api/secrets") {
    if (process.env.NODE_ENV === "production" && auth.authenticatedOwner !== true) {
      json(res, 401, { error: "autenticação do proprietário obrigatória" }); return true;
    }
    const rows = db.prepare("SELECT name, section, value FROM secrets").all();
    json(
      res,
      200,
      rows.map((r) => ({
        name: r.name,
        section: r.section,
        masked: maskSecret(decrypt(r.value)),
      }))
    );
    return true;
  }

  if (method === "DELETE" && p.startsWith("/api/secrets/")) {
    if (process.env.NODE_ENV === "production" && auth.authenticatedOwner !== true) {
      json(res, 401, { error: "autenticação do proprietário obrigatória" }); return true;
    }
    const name = decodeURIComponent(p.slice("/api/secrets/".length));
    db.prepare("DELETE FROM secrets WHERE name=?").run(name);
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/finance/execute") {
    json(res, 403, {
      error: "A LétimaX nunca executa operações financeiras nem retira dinheiro.",
    });
    return true;
  }

  if (method === "POST" && p === "/api/raqueamento/activate") {
    const st = raqueamentoState(db);
    if (!st.eligible) {
      json(res, 400, st);
      return true;
    }
    if (!body.approved) {
      json(res, 400, { error: "Requer aprovação explícita do Senhor Letício.", prompt: st.prompt });
      return true;
    }
    setSetting(db, "raqueamento_active", "1");
    json(res, 200, { ok: true, strategies: RAQUEAMENTO_STRATEGIES });
    return true;
  }

  if (method === "GET" && p === "/api/raqueamento") {
    json(res, 200, raqueamentoState(db));
    return true;
  }

  if (method === "POST" && p === "/api/goals") {
    db.prepare("INSERT INTO goals (month, target, current) VALUES (?,?,?)").run(
      body.month || new Date().toISOString().slice(0, 7),
      Number(body.target),
      Number(body.current || 0)
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/health-log") {
    db.prepare("INSERT INTO health (mood, sleep_hours, created_at) VALUES (?,?,?)").run(
      body.mood ?? null,
      body.sleep_hours ?? null,
      new Date().toISOString()
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/contacts") {
    db.prepare("INSERT INTO contacts (name, email, kind, notes) VALUES (?,?,?,?)").run(
      body.name,
      body.email || "",
      body.kind || "cliente",
      body.notes || ""
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/vault") {
    json(res, 401, { error: "Cofre exige biometria dupla confirmada no cliente antes de enviar." });
    return true;
  }

  if (method === "POST" && p === "/api/vault/store") {
    if (!body.dualBiometric) {
      json(res, 401, { error: "Biometria dupla obrigatória." });
      return true;
    }
    db.prepare("INSERT INTO vault (platform, email, secret, notes) VALUES (?,?,?,?)").run(
      body.platform,
      body.email,
      encrypt(String(body.secret || "")),
      body.notes || ""
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "GET" && p === "/api/crypto") {
    json(res, 200, {
      note: "Retiradas e depósitos são sempre manuais.",
      watch: db.prepare("SELECT * FROM crypto_watch").all(),
      tickers: await fetchTickers(),
    });
    return true;
  }

  if (method === "POST" && p === "/api/lockout/fail") {
    const n = Number(getSetting(db, "fail_count") || 0) + 1;
    setSetting(db, "fail_count", String(n));
    const L = lockoutForFailures(n);
    if (L.permanent) setSetting(db, "lock_until", "permanent");
    else if (L.locked) setSetting(db, "lock_until", String(Date.now() + L.minutes * 60 * 1000));
    db.prepare("INSERT INTO security_log (kind, detail, created_at) VALUES (?,?,?)").run(
      "biometria_falhada",
      `tentativa ${n}`,
      new Date().toISOString()
    );
    json(res, 200, { failCount: n, ...L });
    return true;
  }

  if (method === "GET" && p === "/api/lockout") {
    const until = getSetting(db, "lock_until");
    json(res, 200, {
      failCount: Number(getSetting(db, "fail_count") || 0),
      locked: isLockActive(until),
      lockUntil: until,
    });
    return true;
  }

  if (method === "POST" && p === "/api/lockout/reset") {
    setSetting(db, "fail_count", "0");
    setSetting(db, "lock_until", "0");
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "GET" && p === "/api/autonomy/check") {
    json(res, 200, { allowed: canPerform(Number(url.searchParams.get("level") || 1), url.searchParams.get("action")) });
    return true;
  }

  if (method === "POST" && p === "/api/first-use/complete") {
    setSetting(db, "first_use_done", "1");
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/documents") {
    db.prepare("INSERT INTO documents (title, type, created_at) VALUES (?,?,?)").run(
      body.title || "Contrato",
      body.type || "NDA",
      new Date().toISOString()
    );
    json(res, 200, { ok: true, disclaimer: "Documento gerado como rascunho — não é aconselhamento jurídico." });
    return true;
  }

  // CRUD controlado para os módulos de gestão. A lista de tabelas e campos é fixa:
  // nunca aceitar nomes SQL arbitrários enviados pelo cliente.
  const dataSchemas = {
    products: ["name", "niche", "status", "price", "quality", "sales", "watermark"],
    pages: ["title", "type", "status", "conversion"],
    contacts: ["name", "email", "kind", "notes"],
    assets: ["name", "estimated", "revenue", "growth"],
    courses: ["title", "modules", "lessons", "price"],
    webinars: ["title", "status", "conversion"],
    videos: ["title", "type", "status"],
    presentations: ["title", "type"],
    businesses: ["name", "model", "investment", "days_to_revenue", "risks"],
    testimonials: ["product", "text", "sentiment"],
    launches: ["product", "phase", "revenue"],
    affiliates_ext: ["product", "platform", "commission", "conversion"],
    affiliates_own: ["name", "sales", "commission_due"],
    referrals: ["client", "purchases", "value"],
    tickets: ["client", "status", "category", "age_hours"],
  };
  const dataMatch = p.match(/^\/api\/data\/([a-z_]+)(?:\/(\d+))?$/);
  if (dataMatch) {
    const [, table, idText] = dataMatch;
    const fields = dataSchemas[table];
    if (!fields) { json(res, 404, { error: "módulo não disponível" }); return true; }
    if (method === "GET" && !idText) {
      json(res, 200, db.prepare(`SELECT * FROM ${table} ORDER BY id DESC LIMIT 500`).all());
      return true;
    }
    if (method === "POST" && !idText) {
      const keys = fields.filter((k) => Object.hasOwn(body, k));
      if (!keys.length) { json(res, 400, { error: "nenhum campo válido enviado" }); return true; }
      const placeholders = keys.map(() => "?").join(",");
      const result = db.prepare(`INSERT INTO ${table} (${keys.join(",")}) VALUES (${placeholders})`)
        .run(...keys.map((k) => body[k]));
      db.prepare("INSERT INTO audit_events(actor,action,entity,entity_id,details,created_at) VALUES(?,?,?,?,?,?)")
        .run("owner", "criar", table, String(result.lastInsertRowid), JSON.stringify({ fields: keys }), new Date().toISOString());
      json(res, 201, { ok: true, id: Number(result.lastInsertRowid) });
      return true;
    }
    if (method === "PUT" && idText) {
      const keys = fields.filter((k) => Object.hasOwn(body, k));
      if (!keys.length) { json(res, 400, { error: "nenhum campo válido enviado" }); return true; }
      const assignments = keys.map((k) => `${k}=?`).join(",");
      const result = db.prepare(`UPDATE ${table} SET ${assignments} WHERE id=?`).run(...keys.map((k) => body[k]), Number(idText));
      json(res, result.changes ? 200 : 404, { ok: result.changes > 0 });
      return true;
    }
    if (method === "DELETE" && idText) {
      const result = db.prepare(`DELETE FROM ${table} WHERE id=?`).run(Number(idText));
      json(res, result.changes ? 200 : 404, { ok: result.changes > 0 });
      return true;
    }
  }

  if (method === "GET" && p === "/api/integrations") {
    json(res, 200, db.prepare("SELECT id,provider,status,account_label,last_checked_at,last_error FROM integrations ORDER BY provider").all());
    return true;
  }
  if (method === "PUT" && p.startsWith("/api/integrations/")) {
    const provider = decodeURIComponent(p.slice("/api/integrations/".length));
    const status = String(body.status || "");
    const allowed = ["nao_configurada", "configurada", "activa", "erro", "desactivada"];
    if (!provider || !allowed.includes(status)) { json(res, 400, { error: "provedor ou estado inválido" }); return true; }
    db.prepare(`INSERT INTO integrations(provider,status,account_label,last_checked_at,last_error)
      VALUES(?,?,?,?,?) ON CONFLICT(provider) DO UPDATE SET status=excluded.status,
      account_label=excluded.account_label,last_checked_at=excluded.last_checked_at,last_error=excluded.last_error`)
      .run(provider, status, String(body.account_label || ""), new Date().toISOString(), String(body.last_error || ""));
    json(res, 200, { ok: true });
    return true;
  }
  if (method === "GET" && p === "/api/scheduled-jobs") {
    json(res, 200, db.prepare("SELECT * FROM scheduled_jobs ORDER BY id").all());
    return true;
  }
  if (method === "POST" && p === "/api/scheduled-jobs") {
    const jobKey = String(body.job_key || "").trim();
    const title = String(body.title || "").trim();
    const schedule = String(body.schedule || "").trim();
    if (!jobKey || !title || !schedule) { json(res, 400, { error: "job_key, title e schedule são obrigatórios" }); return true; }
    const result = db.prepare(`INSERT INTO scheduled_jobs(job_key,title,schedule,enabled,status)
      VALUES(?,?,?,0,'inactiva') ON CONFLICT(job_key) DO UPDATE SET title=excluded.title,schedule=excluded.schedule`)
      .run(jobKey, title, schedule);
    json(res, 201, { ok: true, id: Number(result.lastInsertRowid || 0) });
    return true;
  }
  if (method === "POST" && p.startsWith("/api/scheduled-jobs/") && p.endsWith("/toggle")) {
    const id = Number(p.split("/")[3]);
    const enabled = body.enabled === true ? 1 : 0;
    const result = db.prepare("UPDATE scheduled_jobs SET enabled=?,status=? WHERE id=?")
      .run(enabled, enabled ? "activa" : "inactiva", id);
    json(res, result.changes ? 200 : 404, { ok: result.changes > 0, enabled: !!enabled });
    return true;
  }
  if (method === "POST" && p === "/api/funnels") {
    const name = String(body.name || "").trim();
    if (!name) { json(res, 400, { error: "nome do funil obrigatório" }); return true; }
    const now = new Date().toISOString();
    const result = db.prepare("INSERT INTO funnels(name,status,product_id,created_at,updated_at) VALUES(?,'rascunho',?,?,?)")
      .run(name, body.product_id ? Number(body.product_id) : null, now, now);
    json(res, 201, { ok: true, id: Number(result.lastInsertRowid) });
    return true;
  }
  if (method === "POST" && p.startsWith("/api/funnels/") && p.endsWith("/steps")) {
    const funnelId = Number(p.split("/")[3]);
    const funnel = db.prepare("SELECT id FROM funnels WHERE id=?").get(funnelId);
    if (!funnel) { json(res, 404, { error: "funil não encontrado" }); return true; }
    const title = String(body.title || "").trim();
    const type = String(body.step_type || "").trim();
    if (!title || !type) { json(res, 400, { error: "título e tipo da etapa obrigatórios" }); return true; }
    const order = Number(body.step_order || db.prepare("SELECT COALESCE(MAX(step_order),0)+1 AS n FROM funnel_steps WHERE funnel_id=?").get(funnelId).n);
    const result = db.prepare("INSERT INTO funnel_steps(funnel_id,step_order,step_type,title,content,status) VALUES(?,?,?,?,?,'rascunho')")
      .run(funnelId, order, type, title, String(body.content || ""));
    json(res, 201, { ok: true, id: Number(result.lastInsertRowid) });
    return true;
  }
  if (method === "GET" && p.startsWith("/api/funnels/")) {
    const id = Number(p.split("/")[3]);
    json(res, 200, { funnel: db.prepare("SELECT * FROM funnels WHERE id=?").get(id), steps: db.prepare("SELECT * FROM funnel_steps WHERE funnel_id=? ORDER BY step_order").all(id) });
    return true;
  }

  if (method === "POST" && p === "/api/approvals") {
    const action = String(body.action || "").trim();
    if (!action) { json(res, 400, { error: "acção obrigatória" }); return true; }
    const result = db.prepare("INSERT INTO approvals(action,payload,status,requested_at) VALUES(?,?, 'pendente',?)")
      .run(action, JSON.stringify(body.payload || {}), new Date().toISOString());
    json(res, 201, { ok: true, id: Number(result.lastInsertRowid), status: "pendente" });
    return true;
  }
  if (method === "GET" && p === "/api/approvals") {
    json(res, 200, db.prepare("SELECT * FROM approvals ORDER BY id DESC LIMIT 200").all());
    return true;
  }
  if (method === "POST" && p.startsWith("/api/approvals/") && p.endsWith("/decide")) {
    const id = Number(p.split("/")[3]);
    const decision = body.decision === "aprovar" ? "aprovada" : body.decision === "rejeitar" ? "rejeitada" : "";
    if (!decision || !Number.isInteger(id)) { json(res, 400, { error: "decisão ou identificador inválido" }); return true; }
    const result = db.prepare("UPDATE approvals SET status=?, decided_at=?, decision_note=? WHERE id=? AND status='pendente'")
      .run(decision, new Date().toISOString(), String(body.note || "").slice(0, 500), id);
    json(res, result.changes ? 200 : 404, { ok: result.changes > 0, status: decision });
    return true;
  }

  if (method === "GET" && (p === "/" || p.startsWith("/assets") || p.endsWith(".js") || p.endsWith(".css") || p.endsWith(".html") || p.endsWith(".svg") || p.endsWith(".ico"))) {
    return serveStatic(res, p);
  }

  return false;
}

function raqueamentoState(db) {
  const last = Number(getSetting(db, "last_high_score_at") || 0);
  const days = daysSinceLastHighScore(last);
  const el = raqueamentoEligible({
    daysWithoutScoreAbove70: days,
    ownerApproved: getSetting(db, "raqueamento_active") === "1",
  });
  return {
    ...el,
    daysWithoutScoreAbove70: days,
    active: getSetting(db, "raqueamento_active") === "1",
    strategies: RAQUEAMENTO_STRATEGIES,
    sources: db.prepare("SELECT * FROM revenue_sources").all(),
  };
}

function allSettings(db) {
  const rows = db.prepare("SELECT key, value FROM settings").all();
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
}

const secretKey = () => {
  const configured = process.env.SERVER_SECRET;
  if (process.env.NODE_ENV === "production" && (!configured || configured.length < 32)) {
    throw new Error("SERVER_SECRET com pelo menos 32 caracteres é obrigatório em produção.");
  }
  // Em desenvolvimento, usar uma chave explícita. Nunca reutilizar uma chave pública conhecida.
  const material = configured || process.env.LETIMAX_DEV_SECRET;
  if (!material) throw new Error("Configure SERVER_SECRET (ou LETIMAX_DEV_SECRET apenas em desenvolvimento).");
  return crypto.createHash("sha256").update(material).digest();
};

function encrypt(plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", secretKey(), iv);
  const enc = Buffer.concat([c.update(String(plain), "utf8"), c.final()]);
  const tag = c.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString("base64");
}

function decrypt(payload) {
  try {
    const buf = Buffer.from(payload, "base64");
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const enc = buf.subarray(28);
    const d = crypto.createDecipheriv("aes-256-gcm", secretKey(), iv);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString("utf8");
  } catch {
    return "";
  }
}

async function fetchTickers() {
  try {
    const r = await fetch("https://api.binance.com/api/v3/ticker/price?symbols=%5B%22BTCUSDT%22,%22ETHUSDT%22%5D");
    if (!r.ok) return [];
    return await r.json();
  } catch {
    return [];
  }
}

function cors(res) {
  const allowed = String(process.env.LETIMAX_ALLOWED_ORIGINS || "http://localhost:5173,http://127.0.0.1:5173")
    .split(",").map((v) => v.trim()).filter(Boolean);
  // Em produção, só reflectir origens explicitamente autorizadas.
  const origin = String(res.req?.headers?.origin || "");
  if (origin && (process.env.NODE_ENV !== "production" || allowed.includes(origin))) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
}

function json(res, code, data) {
  const raw = redactSecrets(JSON.stringify(data));
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" });
  res.end(raw);
}

function readBody(req) {
  return new Promise((resolve) => {
    if (req.method === "GET" || req.method === "HEAD") return resolve({});
    let d = "";
    req.on("data", (c) => {
      d += c;
      if (d.length > 1e6) req.destroy();
    });
    req.on("end", () => {
      if (!d) return resolve({});
      try {
        resolve(JSON.parse(d));
      } catch {
        resolve({});
      }
    });
  });
}

function serveStatic(res, p) {
  const dist = path.join(__dirname, "..", "web", "dist");
  if (!fs.existsSync(dist)) return false;
  let file = p === "/" ? "index.html" : p.replace(/^\/+/, "");
  const full = path.join(dist, file);
  if (!full.startsWith(dist)) return false;
  if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) {
    const index = path.join(dist, "index.html");
    if (fs.existsSync(index)) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(fs.readFileSync(index));
      return true;
    }
    return false;
  }
  const ext = path.extname(full);
  const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".json": "application/json" };
  res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream" });
  res.end(fs.readFileSync(full));
  return true;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const port = Number(process.env.PORT || 8787);
  const server = createServer({ port });
  server.letimaxListen().then(() => {
    console.log(`LétimaX API em http://127.0.0.1:${port}`);
  });
}
