# Etapa 05 — Persistência local e migração Room

## Correcções
- A base Room passou da versão 1 para a versão 2.
- Foi criada a migração `MIGRATION_1_2`, que acrescenta índices sem apagar as tabelas nem os registos existentes.
- Foram acrescentados índices para consultas por tabela, data de conversa, plataforma e datas de registos de segurança/fila offline.
- Foi removido `fallbackToDestructiveMigration()`, que podia apagar os dados locais quando faltasse uma migração.

## Limites desta etapa
- A migração foi revista ao nível do código, mas ainda não foi executada num dispositivo/emulador.
- Ainda não existe uma estratégia completa de cópias de segurança/restauro nem uma política de retenção/eliminação de dados.
- O campo `secretCipher` da tabela `passwords` deve receber apenas conteúdo cifrado; esta etapa não implementa ainda o fluxo completo de gestão de credenciais.
- A presença das entidades não prova que todos os 42 ecrãs persistem os seus dados.

## Validação pendente
Executar `./gradlew :app:kspDebugKotlin :app:testDebugUnitTest` e testar a actualização de uma instalação com base v1 para v2, confirmando que os registos anteriores permanecem disponíveis.
