# Estado técnico da entrega LÉTIMAX

## Base consolidada
A raiz deste pacote é a única cópia canónica do projecto. A cópia duplicada `letimax/` foi removida desta entrega para evitar compilar ou editar versões diferentes.

## Correcções integradas
- Etapas 1–2: wrapper Gradle POSIX e alinhamento de versões Gradle/AGP/Kotlin; compilação ainda não comprovada.
- Etapa 3: rotas de navegação e tratamento de erros do chat revistos; não significa que todos os módulos estejam funcionais.
- Etapa 4: autenticação por `BiometricPrompt` do Android; não existe reconhecimento próprio de identidade por ML Kit/TFLite.
- Etapa 5: Room v2 com migração não destrutiva 1→2 e índices.
- Etapa 6: cliente HTTP HTTPS, token Bearer, timeouts, tratamento HTTP, permissões mínimas e protecção de endpoints em produção.

## Testes
- `npm test`: 13 testes Node aprovados nesta revisão.
- APK: não gerado.
- Compilação Kotlin/Gradle: não executada; não existe Android SDK configurado (`ANDROID_HOME`/`ANDROID_SDK_ROOT`) neste ambiente e a distribuição Gradle ainda precisa de ser descarregada.
- Testes instrumentados/telemóvel físico: não executados.

## Requisitos oficiais ainda não concluídos
A especificação prevê 42 ecrãs, mais de 140 endpoints, 63 tabelas Room, 26 permissões, 14 plataformas e várias integrações, tarefas agendadas e automações. O código actual não comprova a implementação integral desses requisitos. É necessário mapear cada requisito, implementar módulos em falta e testar cada integração com contas/credenciais reais.

## Segurança
- As chaves dos fornecedores de IA devem permanecer no ambiente privado do servidor.
- Em produção, configurar `NODE_ENV=production` e `LETIMAX_API_TOKEN` forte. Não publicar o servidor sem essa configuração.
- A aplicação deixou de solicitar permissões de SMS e registo/chamada telefónica que não eram usadas.
- Operações financeiras, publicações e despesas continuam sujeitas a aprovação explícita; nenhuma integração financeira foi validada.

## Conclusão
Este pacote é uma base consolidada e corrigida, não uma aplicação certificada como completa nem um APK pronto para instalar. A validação Android permanece pendente.
