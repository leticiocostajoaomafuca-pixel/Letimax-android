# Correcção aplicada — autenticação do proprietário

- Removida a confiança no campo `body.owner` para decidir se o interlocutor é o proprietário.
- A autorização do chat passa a depender da validação do token Bearer no servidor.
- O CORS deixou de anunciar `*`; em produção reflecte apenas origens presentes em `LETIMAX_ALLOWED_ORIGINS`.
- Acrescentado teste contra tentativa de falsificar `owner: true` no JSON.

## Validação
`npm test`: 13/13 testes aprovados após a correcção.

## Limites que permanecem
Esta alteração não implementa ainda um fluxo completo de login com credenciais individuais, renovação/revogação de sessões, nem valida a compilação Android. O token Bearer é uma protecção mínima de servidor e deve ser guardado fora do APK. As funcionalidades externas ainda exigem integrações e credenciais próprias.
