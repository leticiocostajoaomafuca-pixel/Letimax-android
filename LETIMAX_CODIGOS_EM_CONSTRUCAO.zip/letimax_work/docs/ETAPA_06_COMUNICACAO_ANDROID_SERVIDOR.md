# Etapa 6 — Comunicação segura Android ↔ servidor

## Alterações aplicadas
- Cliente Android centralizado com GET, POST e DELETE.
- Timeouts de ligação/leitura/escrita e duração total; repetição apenas em falhas de ligação.
- Tratamento explícito de HTTP não-2xx e JSON inválido.
- URL do servidor deixou de ter um endereço de emulador como valor predefinido; exige HTTPS.
- Token Bearer guardado em preferências cifradas do Android e enviado nos pedidos.
- Backend exige `LETIMAX_API_TOKEN` em ambiente `production`; endpoint `/api/health` permanece público para verificação de disponibilidade.
- Comparação do token no servidor usa comparação de tempo constante.
- Backend escuta em loopback no desenvolvimento e em `0.0.0.0` por omissão em produção; `HOST` permite configurar.
- Manifesto Android deixou de pedir permissões de SMS, registo de chamadas e controlo de chamadas, que não eram necessárias para os fluxos implementados.
- Tráfego HTTP sem TLS foi desactivado na configuração Android.

## Configuração
1. Criar um token longo e aleatório no ambiente privado do servidor como `LETIMAX_API_TOKEN`.
2. Publicar o backend atrás de HTTPS e definir `NODE_ENV=production`, `PORT` e, se necessário, `HOST=0.0.0.0`.
3. Nas Definições da aplicação, inserir o URL HTTPS e o mesmo token.
4. Testar `/api/health` e depois os fluxos autenticados.

## Limitações
- O endpoint de saúde é público por desenho; os restantes endpoints exigem token apenas quando `LETIMAX_API_TOKEN` está configurado. Em produção, o arranque falha se a variável estiver ausente.
- O token é uma credencial de instalação simples, não um sistema completo de contas, sessões, rotação ou permissões por utilizador.
- Integrações externas e endpoints de plataformas ainda dependem de credenciais e implementação específica.
- Compilação Android e teste em dispositivo físico continuam pendentes por falta de Android SDK neste ambiente.
