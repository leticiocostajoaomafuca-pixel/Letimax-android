# LétimaX — alterações de construção

Esta entrega concentra-se em código e estrutura. Compilação de APK e testes foram expressamente adiados.

## Correcções e módulos acrescentados
- Removida a indicação `owner: true` do pedido de chat web. A autorização depende do token Bearer validado pelo servidor, nunca de um campo controlado pelo cliente.
- Cliente web passa a enviar o token de API guardado apenas na sessão do navegador (`sessionStorage`).
- CORS passa a declarar `PUT`, necessário para actualizações dos módulos de dados.
- Segredos deixam de usar uma chave pública fixa de desenvolvimento. `SERVER_SECRET` é obrigatório em produção e deve ter pelo menos 32 caracteres; em desenvolvimento deve ser configurado `LETIMAX_DEV_SECRET` ou `SERVER_SECRET`.
- Respostas de erro HTTP deixam de expor mensagens internas do servidor.
- Rotas de gestão de chaves exigem autenticação do proprietário em produção.
- Adicionado CRUD genérico com lista fixa de tabelas/campos para produtos, páginas, contactos, activos, cursos, webinars, vídeos, apresentações, negócios, testemunhos, lançamentos, afiliados, referências e tickets.
- Adicionado registo de pedidos de aprovação e decisão de aprovação/rejeição.
- Acrescentadas tabelas de base de dados para aprovações, integrações, tarefas agendadas, funis e etapas, campanhas de email, eventos analíticos, activos de produto, auditoria, sessões, dispositivos e consentimentos.
- Dashboard deixa de apresentar lucro líquido e reputação fictícios como valores reais.

## Configuração necessária no servidor
Definir `LETIMAX_API_TOKEN` e `SERVER_SECRET` como variáveis privadas do servidor. Não colocar estes valores no repositório nem no APK. O token deve ser configurado na sessão web através de `saveApiToken(token)`; não é uma palavra-passe biométrica nem substitui o processo de autenticação final da aplicação.

## Limites desta entrega
Não se declara concluída a implementação integral dos 42 ecrãs, 140+ endpoints, 63 tabelas Room, integrações comerciais, motor de IA real, tarefas agendadas, biometria facial/vocal anti-spoofing ou APK. Estes módulos continuam a exigir implementação específica. Não foram executados testes nem compilação, conforme pedido.
