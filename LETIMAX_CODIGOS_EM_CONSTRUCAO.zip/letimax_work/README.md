# LétimaX — base de desenvolvimento

Aplicação Android + servidor Node.js + interface web.

## Estrutura
- `android/`: aplicação Android nativa Kotlin/Compose.
- `server/`: API HTTP e persistência SQLite.
- `web/`: painel web React/Vite.
- `shared/`: regras de domínio partilhadas.
- `docs/`: especificação de construção e histórico de alterações.

## Configuração local do servidor
1. Instalar Node.js compatível com `node:sqlite` (Node 22.13+ recomendado).
2. Copiar `.env.example` para `.env` e definir `LETIMAX_DEV_SECRET` com uma chave aleatória longa.
3. Definir `LETIMAX_API_TOKEN` para activar autenticação Bearer.
4. Instalar dependências com `npm install`.
5. Executar `npm run dev`.

Em produção, configurar `LETIMAX_API_TOKEN` e `SERVER_SECRET` apenas no gestor de variáveis secretas do alojamento. Nunca colocar chaves de API no Android, interface web ou repositório.

A compilação e os testes foram deliberadamente adiados nesta entrega, conforme pedido. A implementação integral da especificação ainda está em desenvolvimento; consultar `docs/ESTADO_DA_CONSTRUCAO_2026-11-14.md`.
