# LétimaX

Assistente de negócio digital do Senhor Letício Costa João Mafuca.

## Requisitos

- Node.js 22+ (testado com 24)
- Git não é obrigatório para correr

## Arranque

```bash
cd %USERPROFILE%\Projects\letimax
npm install
npm test
npm run dev
```

- API: http://127.0.0.1:8787
- Web: http://127.0.0.1:5173

Chaves de API: copiar `.env.example` para o ambiente do **servidor** (Railway). Nunca no código.

## O que está verificado neste repositório

- Regras de pontuação, autonomia, bloqueio biométrico e raqueamento (testes Node)
- API HTTP (health, chat, secrets mascarados, recusa financeira)

## O que a versão web não substitui

- ML Kit / TensorFlow Lite / Android Keystore nativos: na web usa câmara + microfone + embeddings locais no IndexedDB
- Controlo real de chamadas, SMS, lanterna e Wi-Fi: requer APP Android com permissões
- Preços Binance: dependem de rede
