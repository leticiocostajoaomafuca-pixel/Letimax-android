package com.letimax.app.ui

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.letimax.app.LetimaApp
import com.letimax.app.data.Catalog
import com.letimax.app.device.DeviceCommands
import com.letimax.app.domain.ChatTimeout
import com.letimax.app.domain.CommandRouter
import com.letimax.app.domain.Security
import com.letimax.app.domain.VoiceParser
import com.letimax.app.ui.theme.Gold
import com.letimax.app.ui.theme.LetimaTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        voiceSink?.invoke(text)
    }
    private var voiceSink: ((String) -> Unit)? = null

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!LetimaApp.instance.prefs.sessionOk) {
            startActivity(Intent(this, AutenticacaoActivity::class.java))
            finish()
            return
        }
        tts = TextToSpeech(this) { tts?.language = Locale("pt", "PT") }
        val device = DeviceCommands(this)
        setContent {
            LetimaTheme {
                val nav = rememberNavController()
                val drawer = rememberDrawerState(DrawerValue.Closed)
                val scope = rememberCoroutineScope()
                var data by remember { mutableStateOf(Catalog.bootstrap()) }
                var hint by remember { mutableStateOf("") }
                val app = LetimaApp.instance

                fun reload() {
                    scope.launch {
                        runCatching {
                            val remote = app.api.get("/api/bootstrap")
                            data = Catalog.merge(remote)
                            app.db.dao().upsertDashboard(
                                com.letimax.app.data.DashboardCacheEntity(
                                    json = data.toString(),
                                    updatedAt = System.currentTimeMillis(),
                                ),
                            )
                        }.onFailure {
                            hint = "Offline — cache local"
                            val cached = app.db.dao().dashboard()?.json
                            data = Catalog.merge(if (cached.isNullOrBlank()) null else JSONObject(cached))
                        }
                    }
                }
                LaunchedEffect(Unit) { reload() }

                fun speak(t: String) {
                    tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "s")
                }

                fun listen(cb: (String) -> Unit) {
                    voiceSink = cb
                    speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
                    })
                }

                ModalNavigationDrawer(
                    drawerState = drawer,
                    drawerContent = {
                        ModalDrawerSheet {
                            Text("LétimaX", color = Gold, fontSize = 22.sp, modifier = Modifier.padding(16.dp))
                            LazyColumn {
                                items(Routes.drawer) { r ->
                                    NavigationDrawerItem(
                                        label = { Text(r.label) },
                                        selected = false,
                                        onClick = {
                                            nav.navigate(r.route)
                                            scope.launch { drawer.close() }
                                        },
                                    )
                                }
                            }
                        }
                    },
                ) {
                    val back = nav.currentBackStackEntryAsState().value?.destination?.route
                    Scaffold(
                        topBar = {
                            val d = data.optJSONObject("dashboard") ?: JSONObject()
                            TopAppBar(
                                title = {
                                    Text(
                                        "N${d.optInt("autonomy", 1)} · ${d.optString("server", "—")} · ${d.optString("niche", "")} · R$${d.optDouble("today", 0.0)}",
                                        fontSize = 13.sp,
                                    )
                                },
                                navigationIcon = {
                                    IconButton(onClick = { scope.launch { drawer.open() } }) {
                                        Icon(Icons.Default.Menu, null)
                                    }
                                },
                            )
                        },
                        bottomBar = {
                            NavigationBar {
                                Routes.bottom.forEach { r ->
                                    NavigationBarItem(
                                        selected = back == r.route,
                                        onClick = { nav.navigate(r.route) },
                                        label = { Text(r.label) },
                                        icon = { Text("●", color = if (back == r.route) Gold else Color.Gray) },
                                        colors = NavigationBarItemDefaults.colors(indicatorColor = Gold.copy(alpha = 0.2f)),
                                    )
                                }
                            }
                        },
                    ) { pad ->
                        NavHost(nav, startDestination = "chat", modifier = Modifier.padding(pad)) {
                            Routes.all.forEach { spec ->
                                composable(spec.route) {
                                    FeatureScreen(
                                        spec = spec,
                                        data = data,
                                        hint = hint,
                                        onHint = { hint = it },
                                        onReload = { reload() },
                                        onSpeak = { speak(it) },
                                        onListen = { listen(it) },
                                        onCommand = { text ->
                                            val cmd = VoiceParser.parse(text, true)
                                            when (cmd.id) {
                                                "theme_dark" -> {
                                                    app.prefs.themeMode = "dark"
                                                    recreate()
                                                }
                                                "theme_light" -> {
                                                    app.prefs.themeMode = "light"
                                                    recreate()
                                                }
                                                else -> {
                                                    val out = device.execute(cmd)
                                                    if (cmd.ok) speak(out)
                                                    if (Security.isFinancialCommand(text)) speak("Confirmas? Diz sim para confirmar.")
                                                    CommandRouter.spokenReply(cmd, data)?.let { speak(it) }
                                                }
                                            }
                                            scope.launch {
                                                hint = "A carregar…"
                                                val ticker = launch {
                                                    delay(ChatTimeout.LOADING_MS)
                                                    hint = "A carregar…"
                                                    delay(ChatTimeout.PROCESSING_MS - ChatTimeout.LOADING_MS)
                                                    hint = "LétimaX está a processar..."
                                                }
                                                val r = withTimeoutOrNull(ChatTimeout.CANCEL_MS) {
                                                    app.api.post(
                                                        "/api/chat",
                                                        JSONObject().put("message", text).put("owner", true).put("voiceOk", true),
                                                    )
                                                }
                                                ticker.cancel()
                                                if (r == null) {
                                                    hint = "Pedido cancelado. Quer tentar novamente?"
                                                } else {
                                                    hint = ""
                                                    speak(r.optString("reply"))
                                                    reload()
                                                }
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

data class RouteSpec(val route: String, val label: String, val kind: String)

object Routes {
    val bottom = listOf(
        RouteSpec("chat", "Chat", "chat"),
        RouteSpec("dashboard", "Dashboard", "dashboard"),
        RouteSpec("produtos", "Produtos", "list"),
        RouteSpec("mercado", "Mercado", "list"),
        RouteSpec("marketing", "Marketing", "list"),
    )
    val drawer = listOf(
        RouteSpec("motor", "Motor de Receita", "ops"),
        RouteSpec("metas", "Metas", "list"),
        RouteSpec("afiliados_ext", "Afiliados Externos", "list"),
        RouteSpec("afiliados_own", "Afiliados Próprios", "list"),
        RouteSpec("lancamentos", "Lançamentos", "list"),
        RouteSpec("webinars", "Webinars", "list"),
        RouteSpec("email", "Email Marketing", "list"),
        RouteSpec("analytics", "Analytics", "list"),
        RouteSpec("reputacao", "Reputação", "list"),
        RouteSpec("suporte", "Suporte", "list"),
        RouteSpec("onboarding", "Onboarding", "list"),
        RouteSpec("referencias", "Referências", "list"),
        RouteSpec("paginas", "Páginas", "list"),
        RouteSpec("videos", "Vídeos", "list"),
        RouteSpec("cursos", "Cursos", "list"),
        RouteSpec("sites", "Sites", "list"),
        RouteSpec("apresentacoes", "Apresentações", "list"),
        RouteSpec("automacao", "Automação Inteligente", "list"),
        RouteSpec("oportunidades", "Oportunidades", "ops"),
        RouteSpec("investimentos", "Investimentos", "crypto"),
        RouteSpec("empresa", "Empresa", "list"),
        RouteSpec("financas", "Finanças", "list"),
        RouteSpec("contactos", "Contactos", "list"),
        RouteSpec("saude", "Saúde", "list"),
        RouteSpec("passwords", "Passwords", "vault"),
        RouteSpec("documentos", "Documentos", "list"),
        RouteSpec("activos", "Activos", "list"),
        RouteSpec("negocio", "Novo Negócio", "list"),
        RouteSpec("raqueamento", "Raqueamento", "raq"),
        RouteSpec("config", "Configurações", "config"),
        RouteSpec("logs", "Logs", "logs"),
        RouteSpec("update", "Actualização", "list"),
    )
    val all = bottom + drawer
}
