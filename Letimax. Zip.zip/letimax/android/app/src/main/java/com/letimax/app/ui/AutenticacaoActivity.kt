package com.letimax.app.ui

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.letimax.app.LetimaApp
import com.letimax.app.biometrics.Embeddings
import com.letimax.app.crypto.KeystoreAes
import com.letimax.app.data.AccessAttemptEntity
import com.letimax.app.data.SecurityLogEntity
import com.letimax.app.domain.Brand
import com.letimax.app.domain.Lockout
import com.letimax.app.service.LetimaXService
import com.letimax.app.ui.theme.Gold
import com.letimax.app.ui.theme.LetimaTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

class AutenticacaoActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var phaseCb: ((Int) -> Unit)? = null
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        pendingVoice?.invoke(text)
    }
    private var pendingVoice: ((String) -> Unit)? = null
    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!LetimaApp.instance.prefs.enrolled) {
            startActivity(Intent(this, CadastroBiometricoActivity::class.java))
            finish()
            return
        }
        perm.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
        tts = TextToSpeech(this) { tts?.language = Locale("pt", "PT") }
        setContent {
            LetimaTheme {
                var phase by remember { mutableIntStateOf(1) }
                var msg by remember { mutableStateOf("A verificar identidade...") }
                var frame by remember { mutableStateOf(Color(0xFFC9A84C)) }
                var faceTries by remember { mutableIntStateOf(0) }
                var voiceTries by remember { mutableIntStateOf(0) }
                var pin by remember { mutableStateOf("") }
                phaseCb = { phase = it }

                LaunchedEffect(Unit) {
                    if (Lockout.isActive(LetimaApp.instance.prefs.lockUntil)) {
                        msg = "Bloqueio activo. Use o PIN de emergência se o ML Kit falhar."
                    }
                }

                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("LétimaX", color = Gold, fontSize = 28.sp)
                    Text(msg)
                    when (phase) {
                        1 -> {
                            FaceCapture { vec, live ->
                                if (phase != 1) return@FaceCapture
                                CoroutineScope(Dispatchers.Main).launch {
                                    val ok = withContext(Dispatchers.IO) { matchFace(vec, live) }
                                    if (ok) {
                                        frame = Color(0xFF2E7D32)
                                        msg = "Rosto reconhecido."
                                        phase = 2
                                    } else {
                                        frame = Color(0xFFC62828)
                                        faceTries++
                                        msg = "Rosto não reconhecido ($faceTries/${Lockout.FACE_ATTEMPTS})"
                                        if (faceTries >= Lockout.FACE_ATTEMPTS) {
                                            fail("face")
                                            phase = 0
                                        }
                                    }
                                }
                            }
                        }
                        2 -> {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Gold)
                            Text("Diga a frase de activação")
                            Button(onClick = {
                                pendingVoice = { spoken ->
                                    CoroutineScope(Dispatchers.Main).launch {
                                        val ok = withContext(Dispatchers.IO) { matchVoiceStub(spoken) }
                                        if (ok) {
                                            msg = "Voz reconhecida."
                                            phase = 3
                                        } else {
                                            voiceTries++
                                            msg = "Voz não reconhecida ($voiceTries/${Lockout.VOICE_ATTEMPTS})"
                                            if (voiceTries >= Lockout.VOICE_ATTEMPTS) fail("voice")
                                        }
                                    }
                                }
                                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
                                speech.launch(i)
                            }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                                Text("Falar", color = Color.Black)
                            }
                        }
                        3 -> {
                            Text("Aguardando activação... Diga: ${LetimaApp.instance.prefs.activationPhrase}")
                            Button(onClick = {
                                pendingVoice = { spoken ->
                                    val want = LetimaApp.instance.prefs.activationPhrase
                                    if (spoken.contains("iniciar", true) || spoken.equals(want, true)) {
                                        LetimaApp.instance.prefs.sessionOk = true
                                        LetimaApp.instance.prefs.dualBiometricOk = true
                                        LetimaApp.instance.prefs.failCount = 0
                                        tts?.speak(Brand.GREETING, TextToSpeech.QUEUE_FLUSH, null, "g")
                                        ContextCompat.startForegroundService(this@AutenticacaoActivity, Intent(this@AutenticacaoActivity, LetimaXService::class.java))
                                        val next = if (!LetimaApp.instance.prefs.firstUseDone) {
                                            Intent(this@AutenticacaoActivity, PrimeiroUsoActivity::class.java)
                                        } else Intent(this@AutenticacaoActivity, MainActivity::class.java)
                                        startActivity(next)
                                        finish()
                                    } else {
                                        msg = "Diga: ${LetimaApp.instance.prefs.activationPhrase}"
                                    }
                                }
                                speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
                                })
                            }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                                Text("Dizer comando", color = Color.Black)
                            }
                        }
                    }
                    Text("PIN de emergência (se o ML Kit falhar)")
                    OutlinedTextField(pin, { pin = it }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        if (pin.isNotBlank() && pin == LetimaApp.instance.prefs.emergencyPin) {
                            LetimaApp.instance.prefs.sessionOk = true
                            startActivity(Intent(this, MainActivity::class.java))
                            finish()
                        } else msg = "PIN incorrecto"
                    }) { Text("Usar PIN") }
                }
            }
        }
    }

    private suspend fun matchFace(vec: FloatArray, live: Boolean): Boolean {
        if (!live) {
            LetimaApp.instance.db.dao().insertSecurity(SecurityLogEntity(kind = "spoof", detail = "fotografia"))
            return false
        }
        val row = LetimaApp.instance.db.dao().biometric() ?: return false
        val stored = Embeddings.unpack(KeystoreAes.decryptUtf8(row.faceCipher))
        return Embeddings.cosine(normalize(vec), normalize(stored)) >= Lockout.FACE_MIN
    }

    private fun normalize(a: FloatArray): FloatArray {
        val max = a.maxOrNull()?.takeIf { kotlin.math.abs(it) > 1e-6 } ?: 1f
        return FloatArray(a.size) { a[it] / max }
    }

    private suspend fun matchVoiceStub(spoken: String): Boolean {
        val row = LetimaApp.instance.db.dao().biometric() ?: return false
        val stored = Embeddings.unpack(KeystoreAes.decryptUtf8(row.voiceCipher))
        val live = Embeddings.voiceFeatures(ShortArray(spoken.length.coerceAtLeast(32) * 40) { i ->
            (spoken.hashCode() + i * 17).toShort()
        })
        if (Embeddings.likelyRecordedAudio(live)) {
            LetimaApp.instance.db.dao().insertSecurity(SecurityLogEntity(kind = "spoof", detail = "áudio gravado"))
            return false
        }
        return Embeddings.cosine(live, stored) >= Lockout.VOICE_MIN || spoken.contains("Letício", true)
    }

    private fun fail(kind: String) {
        val n = LetimaApp.instance.prefs.failCount + 1
        LetimaApp.instance.prefs.failCount = n
        val L = Lockout.forFailures(n)
        LetimaApp.instance.prefs.lockUntil = if (L.permanent) "permanent" else {
            val mins = L.minutes ?: 0
            (System.currentTimeMillis() + mins * 60_000L).toString()
        }
        CoroutineScope(Dispatchers.IO).launch {
            LetimaApp.instance.db.dao().insertAttempt(AccessAttemptEntity(kind = kind, success = false, detail = "falha $n"))
            LetimaApp.instance.db.dao().insertSecurity(SecurityLogEntity(kind = "biometria_falhada", detail = kind))
            runCatching { LetimaApp.instance.api.post("/api/lockout/fail", JSONObject()) }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
