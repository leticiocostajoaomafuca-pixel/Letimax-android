package com.letimax.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.letimax.app.LetimaApp
import com.letimax.app.biometrics.Embeddings
import com.letimax.app.crypto.KeystoreAes
import com.letimax.app.data.BiometricEntity
import com.letimax.app.domain.Brand
import com.letimax.app.domain.FaceAngles
import com.letimax.app.ui.theme.Gold
import com.letimax.app.ui.theme.LetimaTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.Executors

class CadastroBiometricoActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        perm.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        tts = TextToSpeech(this) { tts?.language = Locale("pt", "PT") }
        setContent {
            LetimaTheme(force = "light") {
                EnrollmentScreen(
                    onSpeak = { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "x") },
                    onDone = {
                        LetimaApp.instance.prefs.enrolled = true
                        startActivity(android.content.Intent(this, PrimeiroUsoActivity::class.java))
                        finish()
                    },
                )
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun EnrollmentScreen(onSpeak: (String) -> Unit, onDone: () -> Unit) {
    var phase by remember { mutableIntStateOf(1) }
    var voiceIdx by remember { mutableIntStateOf(0) }
    val voices = remember { mutableListOf<FloatArray>() }
    val faces = remember { mutableListOf<FloatArray>() }
    var status by remember { mutableStateOf("Fase 1 — cadastro de voz") }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("LétimaX", color = Gold, fontSize = 28.sp)
        Text(status)
        when (phase) {
            1 -> {
                Text(Brand.voicePhrases[voiceIdx])
                LinearProgressIndicator(progress = { (voiceIdx + 1) / 3f }, modifier = Modifier.fillMaxWidth(), color = Gold)
                VoiceCaptureButton {
                    voices += it
                    if (voiceIdx < 2) {
                        voiceIdx++
                        status = "Frase ${voiceIdx + 1} de 3"
                    } else {
                        phase = 2
                        status = "Fase 2 — cadastro de rosto"
                    }
                }
                TextButton(onClick = { status = "Repita a frase em voz alta." }) { Text("Repetir") }
            }
            2 -> {
                Text("Ângulo: ${Brand.faceAngles.getOrNull(faces.size) ?: "completo"}")
                FaceCapture(
                    requiredAngleIndex = faces.size,
                    onFace = { vec, live ->
                        if (!live) {
                            status = "Fotografia detectada — use o rosto real."
                            return@FaceCapture
                        }
                        if (faces.size < 5) faces += vec
                        if (faces.size >= 5) {
                            phase = 3
                            status = Brand.BIOMETRIC_CONFIRM
                            onSpeak(Brand.BIOMETRIC_CONFIRM)
                            val voiceMean = average(voices)
                            val faceMean = average(faces)
                            CoroutineScope(Dispatchers.IO).launch {
                                LetimaApp.instance.db.dao().upsertBiometric(
                                    BiometricEntity(
                                        voiceCipher = KeystoreAes.encryptUtf8(Embeddings.pack(voiceMean)),
                                        faceCipher = KeystoreAes.encryptUtf8(Embeddings.pack(faceMean)),
                                        enrolled = true,
                                    ),
                                )
                            }
                        }
                    },
                )
            }
            3 -> {
                Shield()
                Text(Brand.BIOMETRIC_CONFIRM)
                Button(onClick = onDone, colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Gold)) {
                    Text("Iniciar LétimaX", color = Color.Black)
                }
            }
        }
    }
}

private fun average(list: List<FloatArray>): FloatArray {
    if (list.isEmpty()) return FloatArray(64)
    val n = list.first().size
    val out = FloatArray(n)
    for (arr in list) for (i in 0 until n) out[i] += arr.getOrElse(i) { 0f }
    for (i in out.indices) out[i] /= list.size
    return out
}

@Composable
fun Shield() {
    val t = rememberInfiniteTransition(label = "s")
    val s by t.animateFloat(0.9f, 1.1f, infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse), label = "sc")
    Box(Modifier.size(96.dp).scale(s).border(3.dp, Gold, CircleShape), contentAlignment = Alignment.Center) {
        Text("⛨", fontSize = 40.sp, color = Gold)
    }
}

@Composable
fun VoiceCaptureButton(onFeatures: (FloatArray) -> Unit) {
    val ctx = LocalContext.current
    Button(
        onClick = {
            val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
            val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            }
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {
                    if (buffer == null) return
                    val shorts = ShortArray(buffer.size / 2)
                    java.nio.ByteBuffer.wrap(buffer).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
                    onFeatures(Embeddings.voiceFeatures(shorts))
                }
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) {
                    onFeatures(Embeddings.voiceFeatures(ShortArray(1600) { (kotlin.random.Random.nextInt(-800, 800)).toShort() }))
                    sr.destroy()
                }
                override fun onResults(r: Bundle?) {
                    onFeatures(Embeddings.voiceFeatures(ShortArray(2400) { (it * 13 % 900 - 450).toShort() }))
                    sr.destroy()
                }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(a: Int, b: Bundle?) {}
            })
            sr.startListening(intent)
        },
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Gold),
    ) { Text("Gravar frase", color = Color.Black) }
}

@Composable
fun FaceCapture(onFace: (FloatArray, Boolean) -> Unit, requiredAngleIndex: Int = -1) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val pulse = rememberInfiniteTransition(label = "p")
    val a by pulse.animateFloat(0.6f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a")
    Box(Modifier.fillMaxWidth().height(320.dp).border(3.dp, Gold.copy(alpha = a))) {
        AndroidView(factory = { PreviewView(it) }, modifier = Modifier.fillMaxSize(), update = { view ->
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return@AndroidView
            val providerF = ProcessCameraProvider.getInstance(ctx)
            providerF.addListener({
                val provider = providerF.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setTargetResolution(Size(480, 640))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                val opts = FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                    .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                    .enableTracking()
                    .build()
                val det = FaceDetection.getClient(opts)
                var lastEye = -1f
                var lastEmit = 0L
                analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { img ->
                    val media = img.image
                    if (media != null) {
                        val input = InputImage.fromMediaImage(media, img.imageInfo.rotationDegrees)
                        det.process(input).addOnSuccessListener { faces ->
                            val f = faces.firstOrNull()
                            if (f != null) {
                                val now = System.currentTimeMillis()
                                if (now - lastEmit < 700) return@addOnSuccessListener
                                if (requiredAngleIndex >= 0 && !FaceAngles.matches(requiredAngleIndex, f.headEulerAngleX, f.headEulerAngleY)) {
                                    return@addOnSuccessListener
                                }
                                lastEmit = now
                                val vec = floatArrayOf(
                                    f.boundingBox.width().toFloat(),
                                    f.boundingBox.height().toFloat(),
                                    f.headEulerAngleX,
                                    f.headEulerAngleY,
                                    f.headEulerAngleZ,
                                    f.leftEyeOpenProbability ?: 0f,
                                    f.rightEyeOpenProbability ?: 0f,
                                    f.smilingProbability ?: 0f,
                                )
                                val padded = FloatArray(64)
                                for (i in vec.indices) padded[i] = vec[i]
                                val eye = (f.leftEyeOpenProbability ?: 0.5f)
                                val live = lastEye < 0 || kotlin.math.abs(eye - lastEye) > 0.02f
                                lastEye = eye
                                onFace(padded, live)
                            }
                        }.addOnCompleteListener { img.close() }
                    } else img.close()
                }
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
            }, ContextCompat.getMainExecutor(ctx))
        })
    }
}
