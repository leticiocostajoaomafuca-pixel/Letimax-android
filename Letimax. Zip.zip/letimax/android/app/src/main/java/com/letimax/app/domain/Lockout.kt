package com.letimax.app.domain

data class LockoutResult(
    val locked: Boolean,
    val minutes: Int?,
    val permanent: Boolean,
    val emailAlert: Boolean,
)

object Lockout {
    const val FACE_MIN = 0.92
    const val VOICE_MIN = 0.88
    const val FACE_ATTEMPTS = 3
    const val VOICE_ATTEMPTS = 2

    fun forFailures(count: Int): LockoutResult {
        val n = count
        return when {
            n >= 12 -> LockoutResult(true, null, true, true)
            n >= 9 -> LockoutResult(true, 24 * 60, false, true)
            n >= 6 -> LockoutResult(true, 30, false, false)
            n >= 3 -> LockoutResult(true, 5, false, false)
            else -> LockoutResult(false, 0, false, false)
        }
    }

    fun isActive(lockUntil: String?, now: Long = System.currentTimeMillis()): Boolean {
        if (lockUntil == "permanent") return true
        if (lockUntil.isNullOrBlank() || lockUntil == "0") return false
        return lockUntil.toLongOrNull()?.let { it > now } ?: false
    }
}
