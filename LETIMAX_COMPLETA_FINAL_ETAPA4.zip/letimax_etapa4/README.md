# LÉTIMAX — projecto integrado de desenvolvimento

Esta é a base integrada seleccionada a partir do arquivo principal `Letimax. Zip.zip`: aplicação Android nativa (Kotlin/Jetpack Compose), backend Node.js, módulos partilhados, interface web auxiliar e testes. Os ZIPs menores foram analisados como versões alternativas; não foram misturados como aplicações paralelas.

## Requisitos
- Node.js 22 ou superior.
- Android Studio com Android SDK 36 e JDK 17 para compilar a aplicação Android.
- Chaves de serviços externos configuradas apenas no servidor, usando `.env.example` como referência.

## Backend e testes
```bash
npm ci
npm test
npm run dev:api
```

A API local usa `http://127.0.0.1:8787`. Para interface web auxiliar, executar `npm run dev:web` após instalar dependências.

## Android
Abrir a pasta `android/` no Android Studio, instalar as plataformas e ferramentas indicadas pelo Gradle e sincronizar o projecto. O APK ainda não está incluído: não foi possível executar uma compilação Android neste ambiente, que não dispõe de Android SDK configurado.

## Estado de validação
Consultar `docs/ESTADO_DA_ENTREGA.md`. Testes Node: 13/13 aprovados após duas correcções de integração/teste. A compilação web continua por validar devido à dependência nativa Rollup ausente no ambiente. A aplicação Android não foi compilada nem testada num dispositivo.

## Segurança e limites
Não colocar segredos no cliente Android nem no repositório. Não executar pagamentos, levantamentos, despesas publicitárias ou outras operações financeiras sem aprovação explícita. Funcionalidades que envolvam SMS, chamadas, notificações ou dados pessoais exigem consentimento explícito, permissões Android adequadas e revisão legal; não devem ser usadas para aceder a dados de terceiros.
