import { test } from "node:test";
import assert from "node:assert/strict";
import { embeddingFromImageData, faceScore } from "../web/src/auth/biometric.js";

test("embedding facial local distingue padrões", () => {
  const dark = new Uint8ClampedArray(160 * 160 * 4);
  const light = new Uint8ClampedArray(160 * 160 * 4);
  for (let i = 0; i < light.length; i += 4) {
    light[i] = light[i + 1] = light[i + 2] = 240;
    light[i + 3] = 255;
    dark[i + 3] = 255;
  }
  const a = embeddingFromImageData(dark);
  const b = embeddingFromImageData(light);
  assert.equal(a.length, 32);
  assert.ok(faceScore(a, a) > 0.99);
  assert.ok(faceScore(a, b) < 0.5);
});
