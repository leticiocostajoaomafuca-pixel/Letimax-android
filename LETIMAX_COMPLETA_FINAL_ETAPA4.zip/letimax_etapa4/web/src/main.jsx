import { StrictMode, useCallback, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import "./styles.css";
import { initTheme } from "./theme.js";
import { api } from "./api.js";
import { loadProfile, sessionOk } from "./auth/biometric.js";
import { Autenticacao, Cadastro, PrimeiroUso } from "./pages/Auth.jsx";
import { Shell } from "./pages/Shell.jsx";
import * as S from "./pages/Screens.jsx";

initTheme();

function Guard({ children }) {
  const [state, setState] = useState("load");
  useEffect(() => {
    (async () => {
      const p = await loadProfile();
      if (!p) setState("cadastro");
      else if (!sessionOk()) setState("auth");
      else setState("ok");
    })();
  }, []);
  if (state === "load") return <div className="center">LétimaX…</div>;
  if (state === "cadastro") return <Navigate to="/cadastro-biometrico" replace />;
  if (state === "auth") return <Navigate to="/autenticacao" replace />;
  return children;
}

function App() {
  const [data, setData] = useState(null);
  const reload = useCallback(() => {
    api("/bootstrap").then(setData).catch(() => setData((d) => d || { dashboard: {}, settings: {} }));
  }, []);
  useEffect(() => {
    reload();
    const t = setInterval(reload, 30000);
    return () => clearInterval(t);
  }, [reload]);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/cadastro-biometrico" element={<Cadastro />} />
        <Route path="/autenticacao" element={<Autenticacao />} />
        <Route path="/primeiro-uso" element={<PrimeiroUso />} />
        <Route
          path="/"
          element={
            <Guard>
              <Shell data={data} reload={reload} />
            </Guard>
          }
        >
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="chat" element={<S.Chat />} />
          <Route path="dashboard" element={<S.Dashboard />} />
          <Route path="metas" element={<S.Metas />} />
          <Route path="motor-receita" element={<S.Motor />} />
          <Route path="raqueamento" element={<S.Raqueamento />} />
          <Route path="activos" element={<S.Activos />} />
          <Route path="novo-negocio" element={<S.NovoNegocio />} />
          <Route path="produtos" element={<S.Produtos />} />
          <Route path="cursos" element={<S.Cursos />} />
          <Route path="mercado" element={<S.Mercado />} />
          <Route path="marketing" element={<S.Marketing />} />
          <Route path="webinars" element={<S.Webinars />} />
          <Route path="afiliados-externos" element={<S.AfiliadosExt />} />
          <Route path="afiliados-proprios" element={<S.AfiliadosOwn />} />
          <Route path="lancamentos" element={<S.Lancamentos />} />
          <Route path="email-marketing" element={<S.EmailMkt />} />
          <Route path="analytics" element={<S.AnalyticsP />} />
          <Route path="reputacao" element={<S.Reputacao />} />
          <Route path="suporte" element={<S.Suporte />} />
          <Route path="onboarding" element={<S.OnboardingP />} />
          <Route path="referencias" element={<S.Referencias />} />
          <Route path="paginas" element={<S.Paginas />} />
          <Route path="videos" element={<S.VideosP />} />
          <Route path="sites" element={<S.SitesP />} />
          <Route path="apresentacoes" element={<S.Apresentacoes />} />
          <Route path="automacao" element={<S.Automacao />} />
          <Route path="oportunidades" element={<S.Oportunidades />} />
          <Route path="investimentos" element={<S.Investimentos />} />
          <Route path="empresa" element={<S.Empresa />} />
          <Route path="financas" element={<S.Financas />} />
          <Route path="contactos" element={<S.Contactos />} />
          <Route path="saude" element={<S.Saude />} />
          <Route path="passwords" element={<S.Passwords />} />
          <Route path="documentos" element={<S.Documentos />} />
          <Route path="configuracoes" element={<S.Configuracoes />} />
          <Route path="logs" element={<S.Logs />} />
          <Route path="actualizacao" element={<S.Actualizacao />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App />
  </StrictMode>
);
