import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { BOTTOM_NAV, SIDE_MENU } from "@shared/constants.js";
import { applyTheme, cycleThemeFromCommand } from "../theme.js";

export function Shell({ data, reload }) {
  const nav = useNavigate();
  const d = data?.dashboard || {};

  return (
    <div className="shell">
      <aside className="side">
        <div className="logo" style={{ padding: "4px 10px 16px" }}>LétimaX</div>
        {SIDE_MENU.map((m) => (
          <NavLink key={m.path} to={m.path} className={({ isActive }) => (isActive ? "active" : "")}>
            {m.label}
          </NavLink>
        ))}
      </aside>
      <section className="main">
        <div className="topbar">
          <div className="kpi">Autonomia <b>Nível {d.autonomy}</b></div>
          <div className="kpi">Servidor <span className="dot ok" /> {d.server}</div>
          <div className="kpi">Nicho <b>{d.niche}</b></div>
          <div className="kpi">Hoje <b>R$ {Number(d.today || 0).toFixed(2)}</b></div>
          <div className="kpi">
            Meta {d.goalTarget ? Math.round((d.goalCurrent / d.goalTarget) * 100) : 0}%
          </div>
          <button className="btn ghost" onClick={() => { applyTheme(cycleThemeFromCommand("dark")); }}>Tema</button>
          <button className="btn ghost" onClick={() => reload?.()}>Actualizar</button>
          <button className="btn ghost" onClick={() => nav("/configuracoes")}>Definições</button>
        </div>
        <Outlet context={{ data, reload }} />
      </section>
      <nav className="bottom">
        {BOTTOM_NAV.map((b) => (
          <NavLink key={b.id} to={b.path} className={({ isActive }) => (isActive ? "active" : "")}>
            {b.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
