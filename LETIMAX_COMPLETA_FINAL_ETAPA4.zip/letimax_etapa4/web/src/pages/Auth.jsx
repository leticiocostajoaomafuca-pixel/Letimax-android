import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  THRESHOLDS,
  captureFaceEmbed,
  captureVoiceEmbed,
  saveProfile,
  loadProfile,
  avgEmbed,
  faceScore,
  voiceScore,
  sessionSet,
} from "../auth/biometric.js";
import { api } from "../api.js";
import { speak, OWNER } from "../speak.js";

export function Cadastro() {
  const nav = useNavigate();
  const [phase, setPhase] = useState(1);
  const [voiceIdx, setVoiceIdx] = useState(0);
  const [voiceEmbeds, setVoiceEmbeds] = useState([]);
  const [faceMap, setFaceMap] = useState({});
  const [msg, setMsg] = useState("");
  const [pin, setPin] = useState("");
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  useEffect(() => {
    (async () => {
      const existing = await loadProfile();
      if (existing) nav("/autenticacao", { replace: true });
    })();
  }, [nav]);

  async function recVoice() {
    setMsg("A gravar…");
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const emb = await captureVoiceEmbed(stream, 2000);
    stream.getTracks().forEach((t) => t.stop());
    const next = [...voiceEmbeds, emb];
    setVoiceEmbeds(next);
    setMsg("Frase aceite.");
    if (voiceIdx + 1 < THRESHOLDS.VOICE_ENROLL_PHRASES.length) setVoiceIdx(voiceIdx + 1);
    else setPhase(2);
  }

  async function startCam() {
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
    streamRef.current = stream;
    if (videoRef.current) videoRef.current.srcObject = stream;
  }

  async function captureAngle(angle) {
    if (!videoRef.current) return;
    const emb = await captureFaceEmbed(videoRef.current);
    setFaceMap({ ...faceMap, [angle]: emb });
  }

  async function finish() {
    if (Object.keys(faceMap).length < 5) {
      setMsg("Capture os 5 ângulos.");
      return;
    }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    await saveProfile({
      voice: avgEmbed(voiceEmbeds),
      face: avgEmbed(Object.values(faceMap)),
      pin,
      createdAt: Date.now(),
      deviceOnly: true,
    });
    setPhase(3);
    speak(OWNER.biometricConfirm);
  }

  if (phase === 3) {
    return (
      <div className="center">
        <div className="card" style={{ textAlign: "center", maxWidth: 420 }}>
          <div className="logo" style={{ fontSize: 42 }}>◆</div>
          <h2 className="logo">LétimaX</h2>
          <p>{OWNER.biometricConfirm}</p>
          <button className="btn" onClick={() => nav("/autenticacao")}>Iniciar LétimaX</button>
        </div>
      </div>
    );
  }

  return (
    <div className="center">
      <div className="card" style={{ maxWidth: 480, width: "100%" }}>
        <h2 className="logo">LétimaX</h2>
        <p className="muted">Cadastro biométrico — os dados ficam só neste dispositivo.</p>
        {phase === 1 && (
          <>
            <h3>Fase 1 — Voz ({voiceIdx + 1}/3)</h3>
            <p>{THRESHOLDS.VOICE_ENROLL_PHRASES[voiceIdx]}</p>
            <div className="progress"><span style={{ width: `${((voiceIdx) / 3) * 100}%` }} /></div>
            <div className="row" style={{ marginTop: 12 }}>
              <button className="btn" onClick={recVoice}>Gravar frase</button>
              <button className="btn ghost" onClick={() => setMsg("Repita a frase.")}>Repetir</button>
            </div>
          </>
        )}
        {phase === 2 && (
          <>
            <h3>Fase 2 — Rosto</h3>
            <div className="frame"><video ref={videoRef} autoPlay playsInline muted /></div>
            <div className="row" style={{ marginTop: 8 }}>
              <button className="btn ghost" onClick={startCam}>Activar câmara</button>
              {THRESHOLDS.FACE_ANGLES.map((a) => (
                <button key={a} className="btn" onClick={() => captureAngle(a)}>
                  {a}{faceMap[a] ? " ✓" : ""}
                </button>
              ))}
            </div>
            <label className="muted">PIN de emergência (fallback)</label>
            <input type="password" value={pin} onChange={(e) => setPin(e.target.value)} placeholder="PIN" />
            <button className="btn" style={{ marginTop: 12 }} onClick={finish}>Confirmar perfil</button>
          </>
        )}
        {msg && <p className="muted">{msg}</p>}
      </div>
    </div>
  );
}

export function Autenticacao() {
  const nav = useNavigate();
  const [phase, setPhase] = useState(1);
  const [status, setStatus] = useState("A verificar identidade…");
  const [ok, setOk] = useState(null);
  const [pin, setPin] = useState("");
  const [locked, setLocked] = useState(null);
  const videoRef = useRef(null);

  useEffect(() => {
    (async () => {
      const p = await loadProfile();
      if (!p) {
        nav("/cadastro-biometrico", { replace: true });
        return;
      }
      const L = await api("/lockout").catch(() => ({ locked: false }));
      if (L.locked) setLocked(L);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch {
        setStatus("Câmara indisponível — use o PIN de emergência.");
      }
    })();
  }, [nav]);

  async function fail() {
    const r = await api("/lockout/fail", { method: "POST" });
    setLocked(r);
    setOk(false);
    setStatus("Não reconhecido.");
  }

  async function checkFace() {
    const profile = await loadProfile();
    const video = videoRef.current;
    if (!video?.srcObject) {
      setStatus("Active a câmara ou use PIN.");
      return;
    }
    const live = await captureFaceEmbed(video);
    const score = faceScore(live, profile.face);
    if (score >= THRESHOLDS.FACE_MIN) {
      setOk(true);
      setStatus("Rosto reconhecido.");
      video.srcObject.getTracks().forEach((t) => t.stop());
      setPhase(2);
    } else {
      await fail();
    }
  }

  async function checkVoice() {
    const profile = await loadProfile();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const live = await captureVoiceEmbed(stream, 2000);
      stream.getTracks().forEach((t) => t.stop());
      const score = voiceScore(live, profile.voice);
      if (score >= THRESHOLDS.VOICE_MIN) {
        setOk(true);
        setStatus("Voz reconhecida. Diga: LétimaX, iniciar");
        setPhase(3);
      } else await fail();
    } catch {
      setStatus("Microfone indisponível — use PIN.");
    }
  }

  async function activate() {
    sessionSet(true);
    await api("/lockout/reset", { method: "POST" }).catch(() => {});
    speak(OWNER.greeting);
    const boot = await api("/bootstrap");
    if (boot.settings.first_use_done !== "1") nav("/primeiro-uso");
    else nav("/dashboard");
  }

  async function usePin() {
    const profile = await loadProfile();
    if (profile?.pin && pin === profile.pin) {
      await activate();
    } else {
      setStatus("PIN incorrecto.");
      await fail();
    }
  }

  if (locked?.permanent) {
    return <div className="center"><div className="card"><h2>Bloqueio permanente</h2><p>Alerta por email registado. Contacte o Senhor Letício.</p></div></div>;
  }

  return (
    <div className="center">
      <div className="card" style={{ maxWidth: 480, width: "100%", textAlign: "center" }}>
        <h2 className="logo">LétimaX</h2>
        {phase === 1 && (
          <>
            <div className="frame" style={{ margin: "0 auto" }}>
              <video ref={videoRef} autoPlay playsInline muted />
            </div>
            <p style={{ color: ok === false ? "var(--bad)" : ok ? "var(--ok)" : "inherit" }}>{status}</p>
            <button className="btn" onClick={checkFace}>Verificar rosto</button>
          </>
        )}
        {phase === 2 && (
          <>
            <p>Diga a frase de activação — barra de análise de voz</p>
            <div className="progress"><span style={{ width: "60%" }} /></div>
            <button className="btn" onClick={checkVoice}>Verificar voz</button>
          </>
        )}
        {phase === 3 && (
          <>
            <p className="logo">Aguardando activação… Diga: LétimaX, iniciar</p>
            <button className="btn" onClick={activate}>LétimaX, iniciar</button>
          </>
        )}
        <div style={{ marginTop: 16 }}>
          <p className="muted">PIN de emergência se o reconhecimento falhar</p>
          <input type="password" value={pin} onChange={(e) => setPin(e.target.value)} />
          <button className="btn ghost" onClick={usePin}>Entrar com PIN</button>
        </div>
      </div>
    </div>
  );
}

export function PrimeiroUso() {
  const nav = useNavigate();
  const [key, setKey] = useState("");
  const [msg, setMsg] = useState("");

  async function save() {
    if (key.trim()) {
      await api("/secrets", { method: "POST", body: { name: "ANTHROPIC_API_KEY", value: key.trim(), section: 1 } });
    }
    await api("/first-use/complete", { method: "POST" });
    setMsg("Configuração inicial concluída.");
    nav("/dashboard");
  }

  return (
    <div className="center">
      <div className="card" style={{ maxWidth: 520 }}>
        <h2>Primeiro uso</h2>
        <p>Antes de começar, adicione a chave do Claude para que a LétimaX possa responder. A chave vai só para o servidor via HTTPS — nunca fica no telemóvel.</p>
        <p><a className="gold" href="https://www.anthropic.com" target="_blank" rel="noreferrer">anthropic.com</a></p>
        <input type="password" placeholder="Colar ANTHROPIC_API_KEY" value={key} onChange={(e) => setKey(e.target.value)} />
        <div className="row" style={{ marginTop: 12 }}>
          <button className="btn" onClick={save}>Guardar e continuar</button>
          <button className="btn ghost" onClick={() => { api("/first-use/complete", { method: "POST" }); nav("/configuracoes"); }}>Ir para Configurações Completas</button>
        </div>
        {msg && <p>{msg}</p>}
      </div>
    </div>
  );
}
