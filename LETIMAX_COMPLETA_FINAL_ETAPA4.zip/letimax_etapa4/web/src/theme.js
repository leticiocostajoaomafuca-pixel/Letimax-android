const KEY = "letimax-theme";

export function preferredTheme(setting = "system") {
  if (setting === "light" || setting === "dark") return setting;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function applyTheme(mode) {
  const resolved = preferredTheme(mode);
  document.documentElement.setAttribute("data-theme", resolved);
  localStorage.setItem(KEY, mode);
  return resolved;
}

export function loadThemeSetting() {
  return localStorage.getItem(KEY) || "system";
}

export function cycleThemeFromCommand(which) {
  const mode = which === "dark" ? "dark" : "light";
  localStorage.setItem(KEY, mode);
  return mode;
}

export function initTheme() {
  applyTheme(loadThemeSetting());
  window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
    if (loadThemeSetting() === "system") applyTheme("system");
  });
}
