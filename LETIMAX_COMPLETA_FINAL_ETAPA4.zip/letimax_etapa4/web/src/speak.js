import { OWNER } from "@shared/constants.js";

export function speak(text) {
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "pt-PT";
    u.pitch = 0.9;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  } catch {
    /* Web Speech pode não existir */
  }
}

export function listenOnce() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return Promise.reject(new Error("Reconhecimento de voz indisponível neste browser."));
  return new Promise((resolve, reject) => {
    const rec = new SR();
    rec.lang = "pt-PT";
    rec.onresult = (e) => resolve(e.results[0][0].transcript);
    rec.onerror = (e) => reject(e.error);
    rec.start();
  });
}

export { OWNER };
