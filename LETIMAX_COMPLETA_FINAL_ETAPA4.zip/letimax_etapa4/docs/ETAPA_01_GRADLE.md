# Etapa 1 — Script de compilação Android

## Alteração
- Criado `android/gradlew`, script POSIX executável.
- O script usa o `gradle-wrapper.jar` e `gradle-wrapper.properties` já existentes.
- O script verifica a presença de Java e encaminha os argumentos ao `GradleWrapperMain`.

## Verificações
- `gradle-wrapper.jar` contém `org/gradle/wrapper/GradleWrapperMain.class`.
- `android/gradlew` tem permissão de execução.
- `android/gradlew --version` foi executado; o wrapper iniciou correctamente, mas não conseguiu descarregar Gradle 8.9 porque o ambiente não resolve `services.gradle.org` (`UnknownHostException`).
- `node --test tests/*.test.js`: 13 testes aprovados, 0 falhas.

## Estado
O problema da ausência do script POSIX foi corrigido. A distribuição Gradle 8.9 ainda não foi descarregada, pelo que a compilação Android não foi executada. Também falta configurar/validar o Android SDK neste ambiente. Não declarar APK compilado.
