# Etapa 4 — Autenticação e segurança

## Alterações aplicadas

- Removida a autenticação facial baseada em medidas geométricas do ML Kit. Detecção de rosto não identifica uma pessoa.
- Removido o reconhecimento vocal simulado, incluindo a aceitação por conter o nome do utilizador.
- Cadastro e autenticação passam a utilizar `BiometricPrompt` com `BIOMETRIC_STRONG`, validado pelo Android.
- A aplicação apenas recebe o resultado de sucesso/insucesso do sistema; não recebe nem guarda imagens faciais ou impressões digitais.
- O cadastro só marca `enrolled=true` depois de uma autenticação do sistema bem-sucedida.
- Removido o PIN de emergência da interface de autenticação. O campo antigo de preferências não concede acesso e não é usado como credencial.
- Removidas da interface as referências que apresentavam o comando de voz como prova de identidade.

## Limitações e requisitos

- O dispositivo tem de ter uma biometria forte configurada e suportada pelo Android. Se não existir, a aplicação bloqueia a configuração/autenticação e informa o utilizador; não aceita texto ou voz como substituto.
- A aplicação não implementa reconhecimento facial próprio nem verificação de locutor. A biometria é a do sistema operativo.
- A API Android controla os limites de tentativas e bloqueios da biometria do sistema.
- A compilação Android e o teste num dispositivo físico ainda precisam de ser executados num ambiente com Android SDK e Gradle disponíveis.

## Verificação

- `npm test`: 13 testes passaram.
- ZIP: integridade verificada após a actualização.
- APK: ainda não gerado nem validado.
