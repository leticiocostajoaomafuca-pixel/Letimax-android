# Etapa 3 — Navegação e tratamento do chat

## Verificações
- A actividade principal usa Navigation Compose com rotas centrais e menu lateral.
- As rotas registadas em `Routes.all` são a união das rotas inferiores e laterais.
- As rotas possuem um ecrã de destino, com fallback para listas genéricas quando não existe painel especializado.

## Correcções aplicadas
- O envio de mensagem já não dispara uma recarga imediata e redundante antes de o pedido ao servidor terminar.
- O pedido `/api/chat` passou a tratar falhas de rede sem deixar a excepção escapar da coroutine da interface.
- O estado da interface distingue timeout de falha de comunicação e só apresenta a resposta quando o servidor responde.

## Limitações ainda por validar
- A compilação Kotlin/Compose não foi executada: este ambiente não tem Android SDK e não conseguiu descarregar a distribuição Gradle.
- Não foi possível executar testes instrumentados num dispositivo Android.
- A existência de rotas no menu não significa que todos os módulos estejam funcionais ou ligados a serviços reais.
