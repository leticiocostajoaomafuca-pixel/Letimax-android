# Etapa 02 — Compatibilidade Gradle e Android

- AGP actualizado de 8.7.3 para 8.10.0 para alinhar com `compileSdk = 36`.
- Gradle Wrapper actualizado de 8.9 para 8.11.1, compatível com AGP 8.10.
- Kotlin Android e Compose mantidos em 2.0.21; KSP mantido em 2.0.21-1.0.28 para manter a correspondência com Kotlin.
- Os 13 testes Node.js passaram após a alteração.
- A compilação Android ainda não foi confirmada. O Wrapper precisa de descarregar Gradle e as dependências; a tentativa anterior foi bloqueada por falha de DNS/rede. Não há APK validado nesta etapa.
