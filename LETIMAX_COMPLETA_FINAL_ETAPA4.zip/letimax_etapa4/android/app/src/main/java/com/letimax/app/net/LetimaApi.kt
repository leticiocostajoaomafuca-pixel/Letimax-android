package com.letimax.app.net

import com.letimax.app.domain.Security
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class LetimaApi(private val baseUrlProvider: () -> String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun url(path: String): String {
        val base = baseUrlProvider().trimEnd('/')
        return "$base$path"
    }

    suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url(path)).get().build()
        client.newCall(req).execute().use { res ->
            val body = res.body?.string().orEmpty()
            val safe = Security.redactSecrets(body)
            if (safe.isBlank()) JSONObject()
            else if (safe.trimStart().startsWith("[")) JSONObject().put("items", JSONArray(safe))
            else JSONObject(safe)
        }
    }

    suspend fun post(path: String, body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(url(path))
            .post(body.toString().toRequestBody(jsonType))
            .build()
        client.newCall(req).execute().use { res ->
            val text = Security.redactSecrets(res.body?.string().orEmpty())
            if (text.isBlank()) JSONObject().put("ok", res.isSuccessful).put("http", res.code)
            else runCatching { JSONObject(text) }.getOrElse {
                JSONObject().put("ok", res.isSuccessful).put("raw", text).put("http", res.code)
            }
        }
    }

    suspend fun delete(path: String): JSONObject = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url(path)).delete().build()
        client.newCall(req).execute().use { res ->
            JSONObject(Security.redactSecrets(res.body?.string().orEmpty().ifBlank { """{"ok":true}""" }))
        }
    }
}
