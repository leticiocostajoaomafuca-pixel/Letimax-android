package com.letimax.app.domain

object FaceAngles {
    fun matches(index: Int, eulerX: Float, eulerY: Float): Boolean {
        return when (index) {
            0 -> kotlin.math.abs(eulerY) < 12f && kotlin.math.abs(eulerX) < 12f
            1 -> eulerY > 15f
            2 -> eulerY < -15f
            3 -> eulerX > 12f
            4 -> eulerX < -12f
            else -> false
        }
    }
}
