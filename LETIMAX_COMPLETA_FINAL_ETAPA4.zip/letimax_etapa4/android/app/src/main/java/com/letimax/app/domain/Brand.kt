package com.letimax.app.domain

object Brand {
    const val NAME = "LétimaX"
    const val OWNER = "Letício Costa João Mafuca"
    const val GREETING = "Bem-vindo, Senhor Letício. Estou pronto. Hoje vamos fazer ainda mais dinheiro."
    const val BIOMETRIC_CONFIRM = "Perfil biométrico criado. A LétimaX reconhece-o agora, Senhor Letício."
    const val GOLD = 0xFFC9A84C
    const val LIGHT_BG = 0xFFFFFFFF
    const val LIGHT_TEXT = 0xFF1A1A1A
    const val DARK_BG = 0xFF0D0D0D
    const val DARK_TEXT = 0xFFFFFFFF
    const val INTERACTIVE = 0xFF2D2D2D

    val voicePhrases = listOf(
        "Eu sou o Senhor Letício e a LétimaX obedece apenas à minha voz.",
        "Hoje vamos construir activos que geram dinheiro sem trabalho diário.",
        "LétimaX, reconhece a minha voz e protege as chaves e o meu negócio.",
    )
    val faceAngles = listOf("frente", "direita", "esquerda", "cima", "baixo")
    val niches = listOf(
        "Marketing Digital com IA", "Emagrecimento e Saúde", "Relacionamentos", "Finanças Pessoais",
        "Desenvolvimento Pessoal", "Inglês Rápido", "Concursos Públicos", "Redes Sociais",
        "Negócio Online do Zero", "Ansiedade e Saúde Mental", "Cripto para Iniciantes",
        "Culinária Saudável", "Moda e Beleza", "Educação Infantil", "Viagens Digitais",
    )
    val revenueSources = listOf(
        "Produtos Digitais Próprios", "Afiliados Externos", "Programa de Afiliados Próprio",
        "Mentorias e Consultorias", "Membership Recorrente", "Conteúdo Orgânico Monetizado",
        "Email Marketing", "Lançamentos e Webinars", "Parcerias Estratégicas",
        "Licenciamento de Conteúdo", "Sistema de Referências", "Investimentos Passivos (só monitorização)",
    )
    val aiKeys = listOf(
        "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY",
        "STABILITY_API_KEY", "ELEVENLABS_API_KEY", "ELEVENLABS_VOICE_ID",
    )
    val platformKeys = listOf(
        "HOTMART_CLIENT_ID", "HOTMART_CLIENT_SECRET", "KIWIFY_API_KEY", "GUMROAD_ACCESS_TOKEN",
        "SHOPIFY_API_KEY", "SHOPIFY_API_SECRET", "BINANCE_API_KEY", "BINANCE_SECRET_KEY",
        "MAILCHIMP_API_KEY", "NETLIFY_API_KEY", "GMAIL_OAUTH_TOKEN", "GOOGLE_ANALYTICS_ID", "META_PIXEL_ID",
    )
    val roomTables = listOf(
        "conversas", "contexto_ia", "rascunhos_produtos", "logs_erros", "financas_pessoais",
        "contactos", "passwords", "configuracoes", "dashboard_cache", "saude", "humor_produtividade",
        "contratos", "regras_autonomia", "diario_decisoes", "empresa_dados", "empresa_plano",
        "nichos_monitorizados", "historico_nichos", "respostas_pre_aprovadas", "fontes_receita",
        "afiliados_externos", "afiliados_proprios", "historico_receita", "oportunidades_mercado",
        "testemunhos", "reputacao_alertas", "sentimento_analise", "email_marketing", "email_segmentos",
        "lancamentos", "webinars", "analytics", "carrinho_abandonado", "concorrencia", "seguranca_log",
        "sistema_dispositivo", "paginas_criadas", "sites_criados", "videos_guioes", "cursos_videos",
        "conteudo_marketing", "automacao_aprendizagem", "automacao_cascata", "automacao_pontuacao",
        "conteudo_agendado", "apresentacoes_criadas", "oportunidades_detectadas", "chaves_personalizadas",
        "perfil_biometrico", "tentativas_acesso", "motor_receita_oportunidades", "versoes_app", "metas",
        "tickets_suporte", "onboarding_clientes", "referencias_indicacoes", "direitos_digitais",
        "ab_tests", "precificacao_dinamica", "politicas_privacidade", "primeiro_uso", "sistema_raqueamento",
        "activos", "novos_negocios", "comandos_voz_log", "segredos_ricos", "construcao_activos",
    )
}
