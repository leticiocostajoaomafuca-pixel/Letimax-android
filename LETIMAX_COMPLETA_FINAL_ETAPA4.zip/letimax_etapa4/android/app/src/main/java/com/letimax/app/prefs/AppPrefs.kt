package com.letimax.app.prefs

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class AppPrefs(context: Context) {
    private val master = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()
    private val sp = EncryptedSharedPreferences.create(
        context,
        "letimax_prefs",
        master,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    var serverUrl: String
        get() = sp.getString("server", "http://10.0.2.2:8787") ?: "http://10.0.2.2:8787"
        set(v) { sp.edit().putString("server", v).apply() }

    var themeMode: String
        get() = sp.getString("theme", "system") ?: "system"
        set(v) { sp.edit().putString("theme", v).apply() }

    var enrolled: Boolean
        get() = sp.getBoolean("enrolled", false)
        set(v) { sp.edit().putBoolean("enrolled", v).apply() }

    var firstUseDone: Boolean
        get() = sp.getBoolean("first_use", false)
        set(v) { sp.edit().putBoolean("first_use", v).apply() }

    var sessionOk: Boolean
        get() = sp.getBoolean("session", false)
        set(v) { sp.edit().putBoolean("session", v).apply() }

    var failCount: Int
        get() = sp.getInt("fail", 0)
        set(v) { sp.edit().putInt("fail", v).apply() }

    var lockUntil: String
        get() = sp.getString("lock", "0") ?: "0"
        set(v) { sp.edit().putString("lock", v).apply() }

    var activationPhrase: String
        get() = sp.getString("activation", "LétimaX, iniciar") ?: "LétimaX, iniciar"
        set(v) { sp.edit().putString("activation", v).apply() }

    var emergencyPin: String
        get() = sp.getString("pin", "") ?: ""
        set(v) { sp.edit().putString("pin", v).apply() }

    var dualBiometricOk: Boolean
        get() = sp.getBoolean("dual_ok", false)
        set(v) { sp.edit().putBoolean("dual_ok", v).apply() }

    var morningHour: String
        get() = sp.getString("morning", "08:00") ?: "08:00"
        set(v) { sp.edit().putString("morning", v).apply() }

    var workStart: String
        get() = sp.getString("work_start", "08:00") ?: "08:00"
        set(v) { sp.edit().putString("work_start", v).apply() }

    var workEnd: String
        get() = sp.getString("work_end", "22:00") ?: "22:00"
        set(v) { sp.edit().putString("work_end", v).apply() }

    var autonomyLevel: Int
        get() = sp.getInt("autonomy", 1)
        set(v) { sp.edit().putInt("autonomy", v).apply() }

    var tokenLimit: Int
        get() = sp.getInt("tokens", 8000)
        set(v) { sp.edit().putInt("tokens", v).apply() }

    var apiDailyLimit: String
        get() = sp.getString("api_limit", "0") ?: "0"
        set(v) { sp.edit().putString("api_limit", v).apply() }

    var busyMessage: String
        get() = sp.getString("busy", "O Senhor Letício está ocupado neste momento. Pode deixar recado ou ele retorna em breve.")
            ?: "O Senhor Letício está ocupado neste momento. Pode deixar recado ou ele retorna em breve."
        set(v) { sp.edit().putString("busy", v).apply() }

    var foregroundEnabled: Boolean
        get() = sp.getBoolean("fg", true)
        set(v) { sp.edit().putBoolean("fg", v).apply() }

    var currentNiche: String
        get() = sp.getString("niche", "Marketing Digital com IA") ?: "Marketing Digital com IA"
        set(v) { sp.edit().putString("niche", v).apply() }

    var monthlyGoal: String
        get() = sp.getString("goal", "2000") ?: "2000"
        set(v) { sp.edit().putString("goal", v).apply() }

    var affiliatePct: String
        get() = sp.getString("aff", "50") ?: "50"
        set(v) { sp.edit().putString("aff", v).apply() }

    var cookieDays: String
        get() = sp.getString("cookie", "30") ?: "30"
        set(v) { sp.edit().putString("cookie", v).apply() }
}
