package com.letimax.app.domain

import org.json.JSONObject

object CommandRouter {
    fun spokenReply(cmd: VoiceCommand, data: JSONObject): String? {
        if (!cmd.ok) return cmd.spoken
        val d = data.optJSONObject("dashboard") ?: JSONObject()
        val ops = data.optJSONArray("opportunities")
        val top = ops?.optJSONObject(0)
        return when (cmd.id) {
            "sales" -> "Vendas de hoje R$${d.optDouble("today")}. Mês R$${d.optDouble("month")}."
            "earned_today" -> "Hoje ganhou R$${d.optDouble("today")}."
            "next_opportunity" ->
                "Próxima oportunidade: ${top?.optString("title") ?: "nenhuma acima de 70"} com pontuação ${top?.optInt("score") ?: 0}."
            "day_summary" ->
                "Resumo: nicho ${d.optString("niche")}, receita do dia R$${d.optDouble("today")}, meta ${d.optDouble("goalCurrent")} de ${d.optDouble("goalTarget")}."
            "autonomy_full" -> "Modo autónomo total pedido por ${cmd.args.firstOrNull() ?: "?"} horas. Confirme no ecrã."
            "autonomy_off", "autonomy_normal" -> "A voltar ao modo normal, nível 1."
            "raqueamento" -> "O raqueamento só activa com a sua aprovação após 7 dias sem oportunidades viáveis."
            "company_plan" -> "A gerar o plano da empresa só com 3 meses de vendas ou este comando confirmado."
            else -> null
        }
    }
}
