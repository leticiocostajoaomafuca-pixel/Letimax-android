package com.letimax.app.device

import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.letimax.app.domain.VoiceCommand
import com.letimax.app.domain.VoiceParser

class DeviceCommands(private val context: Context) {
    fun execute(cmd: VoiceCommand): String {
        if (!cmd.ok || cmd.id == null) return cmd.spoken ?: "Comando desconhecido."
        return when (cmd.id) {
            "torch_on" -> torch(true)
            "torch_off" -> torch(false)
            "vol_up" -> volume(+1)
            "vol_down" -> volume(-1)
            "vol_max" -> volume(99)
            "silent" -> silent()
            "bt_on" -> openPanel("bluetooth")
            "bt_off" -> openPanel("bluetooth")
            "wifi_on", "wifi_off" -> openPanel("wifi")
            "pause_music" -> media(KeyEvent.KEYCODE_MEDIA_PAUSE)
            "resume_music" -> media(KeyEvent.KEYCODE_MEDIA_PLAY)
            "next_track" -> media(KeyEvent.KEYCODE_MEDIA_NEXT)
            "prev_track" -> media(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "bright_up" -> brightness(true)
            "bright_down" -> brightness(false)
            "screen_off" -> "Para desligar o ecrã use o botão físico — o sistema Android bloqueia sleep sem Device Owner."
            "busy_call" -> VoiceParser.busyCallMessage()
            "call_contact" -> dial(cmd.args.firstOrNull().orEmpty())
            "reply_last_sms" -> sendSms(null, cmd.args.firstOrNull().orEmpty())
            else -> "Comando ${cmd.id} registado. Execução no dispositivo quando as permissões estiverem activas."
        }
    }

    private fun torch(on: Boolean): String {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull() ?: return "Sem câmara para lanterna."
        cm.setTorchMode(id, on)
        return if (on) "Lanterna ligada." else "Lanterna desligada."
    }

    private fun volume(delta: Int): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (delta == 99) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
            return "Volume máximo."
        }
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (delta > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI,
        )
        return "Volume ajustado."
    }

    private fun silent(): String {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !nm.isNotificationPolicyAccessGranted) {
            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Autorize o acesso ao modo Não incomodar."
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.ringerMode = AudioManager.RINGER_MODE_SILENT
        return "Modo silencioso."
    }

    private fun openPanel(kind: String): String {
        val intent = when (kind) {
            "wifi" -> Intent(Settings.Panel.ACTION_WIFI)
            else -> Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
        if (kind == "bluetooth") {
            BluetoothAdapter.getDefaultAdapter()
            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return "Painel do sistema aberto — o Android 10+ já não permite ligar Wi-Fi/Bluetooth em silêncio."
    }

    private fun media(code: Int): String {
        val event = KeyEvent(KeyEvent.ACTION_DOWN, code)
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(event)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Comando de média enviado."
    }

    private fun brightness(up: Boolean): String {
        val uri = android.provider.Settings.System.getUriFor(android.provider.Settings.System.SCREEN_BRIGHTNESS)
        if (!Settings.System.canWrite(context)) {
            context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Autorize alterar definições do sistema para o brilho."
        }
        val cur = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        val next = (cur + if (up) 40 else -40).coerceIn(10, 255)
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, next)
        context.contentResolver.notifyChange(uri, null)
        return "Brilho ajustado."
    }

    private fun dial(name: String): String {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$name")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "A abrir o marcador para $name."
    }

    private fun sendSms(number: String?, text: String): String {
        if (text.isBlank()) return "Mensagem vazia."
        if (number.isNullOrBlank()) return "Número em falta — use o último SMS no histórico do sistema."
        SmsManager.getDefault().sendTextMessage(number, null, text, null, null)
        return "SMS enviado."
    }
}
