package com.letimax.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.letimax.app.LetimaApp
import com.letimax.app.data.Catalog
import com.letimax.app.ui.theme.Gold
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun DedicatedListPane(spec: RouteSpec, data: JSONObject, onReload: () -> Unit) {
    when (spec.route) {
        "cursos" -> CoursePane(data, onReload)
        "webinars" -> WebinarPane(data, onReload)
        "afiliados_ext" -> AffiliateExtPane(data)
        "afiliados_own" -> AffiliateOwnPane(data)
        "lancamentos" -> LaunchPane(data)
        "email" -> EmailPane(data, onReload)
        "analytics" -> AnalyticsPane(data)
        "reputacao" -> ReputationPane(data)
        "suporte" -> SupportPane(data)
        "onboarding" -> OnboardingPane(data)
        "referencias" -> ReferralPane(data)
        "paginas" -> PagesPane(data, onReload)
        "videos" -> VideosPane(data, onReload)
        "sites" -> SitesPane(data, onReload)
        "apresentacoes" -> PresentationsPane(data, onReload)
        "automacao" -> AutomationPane(data)
        "contactos" -> ContactsPane(data)
        "documentos" -> DocumentsPane(data, onReload)
        "activos" -> AssetsPane(data)
        "negocio" -> BusinessPane(data, onReload)
        else -> FallbackRows(spec.label, emptyList(), onReload)
    }
}

@Composable
private fun CoursePane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Cursos", fontSize = 22.sp, color = Gold)
        GoldAction("Criar novo curso") { postAction("/api/courses/create", onReload) }
        Catalog.jsonList(data.optJSONArray("courses")).forEach { c ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(c.optString("name"), fontSize = 16.sp)
                    Text("Módulos ${c.optInt("modules")} · aulas ${c.optInt("lessons")} · ${c.optString("duration")}")
                    Text("Preço ${c.optString("price")} · qualidade ${c.optInt("quality")}/100")
                    Text("Conclusão ${c.optString("completion", "—")} · reembolso ${c.optString("refund", "—")}")
                }
            }
        }
    }
}

@Composable
private fun WebinarPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Webinars", fontSize = 22.sp, color = Gold)
        GoldAction("Criar webinar") { postAction("/api/webinars/create", onReload) }
        Catalog.jsonList(data.optJSONArray("webinars")).forEach {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(it.optString("name"))
                    Text("Estado ${it.optString("status")} · conversão ${it.optString("conversion")}")
                    Text("5 emails de convite + 3 de follow-up. Integração Zoom/WebinarKit.")
                }
            }
        }
    }
}

@Composable
private fun AffiliateExtPane(data: JSONObject) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Afiliados externos", fontSize = 22.sp, color = Gold)
        Catalog.jsonList(data.optJSONArray("affiliatesExt")).forEach {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(it.optString("name"))
                    Text("Comissão ${it.optString("commission")} · conversão ${it.optString("conversion", "—")}")
                }
            }
        }
    }
}

@Composable
private fun AffiliateOwnPane(data: JSONObject) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Programa de afiliados próprio", fontSize = 22.sp, color = Gold)
        Text("Comissão padrão 50%. Link único por afiliado e produto.")
        Catalog.jsonList(data.optJSONArray("affiliatesOwn")).forEach {
            Text("${it.optString("name")} · ${it.optString("commission")} · cookie ${it.optInt("cookieDays")} dias")
        }
    }
}

@Composable
private fun LaunchPane(data: JSONObject) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Lançamentos", fontSize = 22.sp, color = Gold)
        Text("Pré-lançamento 7 dias · lançamento 3 dias · pós-lançamento.")
        Catalog.jsonList(data.optJSONArray("launches")).forEach {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(it.optString("name"))
                    Text("Fase: ${it.optString("phase")}")
                    LinearProgressIndicator(progress = { 0.3f }, modifier = Modifier.fillMaxWidth(), color = Gold)
                }
            }
        }
    }
}

@Composable
private fun EmailPane(data: JSONObject, onReload: () -> Unit) {
    val d = data.optJSONObject("dashboard") ?: JSONObject()
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Email marketing", fontSize = 22.sp, color = Gold)
        Text("Lista ${d.optInt("emailList")} · crescimento diário ${d.optInt("emailGrowth")}")
        Text("Segmentos: activos, não compradores, inactivos 30d, VIP.")
        GoldAction("Criar nova sequência") { postAction("/api/email/sequence", onReload) }
        Catalog.jsonList(data.optJSONArray("emails")).forEach {
            Text("${it.optString("name")} · abertura ${it.optString("open")} · clique ${it.optString("click")}")
        }
    }
}

@Composable
private fun AnalyticsPane(data: JSONObject) {
    val a = data.optJSONObject("analytics") ?: JSONObject()
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Analytics", fontSize = 22.sp, color = Gold)
        Text("LTV R$${a.optDouble("ltv")} · CAC R$${a.optDouble("cac")}")
        Text("Projecção 30 dias R$${a.optDouble("projection30")}")
        Text("GA4 e Meta Pixel nas páginas publicadas. Sem compra/venda automática.")
    }
}

@Composable
private fun ReputationPane(data: JSONObject) {
    val d = data.optJSONObject("dashboard") ?: JSONObject()
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Reputação", fontSize = 22.sp, color = Gold)
        Text("Score geral ${d.optInt("reputation")}/100")
        val rows = Catalog.jsonList(data.optJSONArray("testimonials"))
        if (rows.isEmpty()) Text("Ainda sem testemunhos. Pedido automático 7 dias após compra.")
        rows.forEach { Text(it.optString("text", it.toString())) }
    }
}

@Composable
private fun SupportPane(data: JSONObject) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Suporte", fontSize = 22.sp, color = Gold)
        Text("Estados: Novo, Em resposta, Resolvido, Reembolso solicitado, Reembolso processado.")
        val rows = Catalog.jsonList(data.optJSONArray("tickets"))
        if (rows.isEmpty()) Text("Sem tickets. Alerta se um ticket passar 24h sem resposta.")
        rows.forEach { Text("${it.optString("name", it.optString("id"))} · ${it.optString("status")}") }
    }
}

@Composable
private fun OnboardingPane(data: JSONObject) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Onboarding", fontSize = 22.sp, color = Gold)
        Text("Day 1 boas-vindas · Day 3 dúvidas · Day 7 resultado.")
        Catalog.jsonList(data.optJSONArray("onboarding")).ifEmpty {
            listOf(JSONObject().put("name", "Sequência padrão activa após cada compra"))
        }.forEach { Text(it.optString("name", it.toString())) }
    }
}

@Composable
private fun ReferralPane(data: JSONObject) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Referências", fontSize = 22.sp, color = Gold)
        Text("Link único após compra. Email de indicação no dia 14.")
        Catalog.jsonList(data.optJSONArray("referrals")).forEach { Text(it.toString()) }
    }
}

@Composable
private fun PagesPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Páginas", fontSize = 22.sp, color = Gold)
        GoldAction("Criar nova página") { postAction("/api/pages/create", onReload) }
        Catalog.jsonList(data.optJSONArray("pages")).forEach {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${it.optString("name")} · ${it.optString("type")}")
                    Text("Estado ${it.optString("status")} · A/B test quando houver tráfego.")
                    GoldAction("Optimizar") { postAction("/api/pages/optimize", onReload) }
                }
            }
        }
    }
}

@Composable
private fun VideosPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Vídeos", fontSize = 22.sp, color = Gold)
        GoldAction("Criar guião") { postAction("/api/videos/script", onReload) }
        Catalog.jsonList(data.optJSONArray("videos")).forEach {
            Text("${it.optString("name")} · ${it.optString("type")} · miniatura Stability · narração ElevenLabs")
        }
    }
}

@Composable
private fun SitesPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Sites", fontSize = 22.sp, color = Gold)
        GoldAction("Criar novo site") { postAction("/api/sites/create", onReload) }
        Catalog.jsonList(data.optJSONArray("sites")).forEach {
            Text("${it.optString("name")} · ${it.optString("status")}")
        }
    }
}

@Composable
private fun PresentationsPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Apresentações", fontSize = 22.sp, color = Gold)
        GoldAction("Criar apresentação") { postAction("/api/presentations/create", onReload) }
        Catalog.jsonList(data.optJSONArray("presentations")).forEach {
            Text("${it.optString("name")} · ${it.optString("type")} · download .pptx no servidor")
        }
    }
}

@Composable
private fun AutomationPane(data: JSONObject) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Automação inteligente", fontSize = 22.sp, color = Gold)
        Catalog.jsonList(data.optJSONArray("automations")).forEach {
            var on by remember { mutableStateOf(it.optBoolean("enabled", true)) }
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(it.optString("name"))
                        Text("Sucesso ${it.optString("success")}")
                    }
                    Switch(on, { on = it })
                }
            }
        }
    }
}

@Composable
private fun ContactsPane(data: JSONObject) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Contactos", fontSize = 22.sp, color = Gold)
        val rows = Catalog.jsonList(data.optJSONArray("contacts"))
        if (rows.isEmpty()) Text("Sem contactos ainda. Classes: cliente, parceiro, afiliado, fornecedor, influenciador.")
        rows.forEach { Text("${it.optString("name")} · ${it.optString("kind")}") }
    }
}

@Composable
private fun DocumentsPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Documentos", fontSize = 22.sp, color = Gold)
        GoldAction("Novo contrato") { postAction("/api/documents/create", onReload) }
        Catalog.jsonList(data.optJSONArray("documents")).forEach { Text("${it.optString("name")} · ${it.optString("type")}") }
        Text("Política LGPD/RGPD gerada por produto publicado.")
    }
}

@Composable
private fun AssetsPane(data: JSONObject) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Activos", fontSize = 22.sp, color = Gold)
        Catalog.jsonList(data.optJSONArray("assets")).forEach {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(it.optString("name"))
                    Text("Valor estimado R$${it.optDouble("value")} · receita R$${it.optDouble("revenue")}")
                }
            }
        }
    }
}

@Composable
private fun BusinessPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Novos negócios legais", fontSize = 22.sp, color = Gold)
        Catalog.jsonList(data.optJSONArray("businesses")).forEach {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(it.optString("name"))
                    Text("Investimento ${it.optString("investment")} · 1.ª receita ${it.optString("timeToRevenue")}")
                    GoldAction("Aprovar") { postAction("/api/business/approve", onReload) }
                }
            }
        }
    }
}

@Composable
private fun FallbackRows(title: String, rows: List<JSONObject>, onReload: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(title, fontSize = 22.sp, color = Gold)
        LazyColumn { items(rows) { Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(it.toString(), Modifier.padding(12.dp)) } } }
        Button(onClick = onReload) { Text("Actualizar") }
    }
}

@Composable
private fun GoldAction(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Gold)) {
        Text(label, color = Color.Black)
    }
}

private fun postAction(path: String, onReload: () -> Unit) {
    CoroutineScope(Dispatchers.IO).launch {
        runCatching { LetimaApp.instance.api.post(path, JSONObject()) }
        onReload()
    }
}
