package com.letimax.app.ui

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.letimax.app.LetimaApp
import com.letimax.app.domain.Brand
import com.letimax.app.service.LetimaXService
import com.letimax.app.ui.theme.Gold
import com.letimax.app.ui.theme.LetimaTheme
import java.util.Locale

class AutenticacaoActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!LetimaApp.instance.prefs.enrolled) {
            startActivity(Intent(this, CadastroBiometricoActivity::class.java))
            finish()
            return
        }
        tts = TextToSpeech(this) { tts?.language = Locale("pt", "PT") }
        setContent {
            LetimaTheme {
                var message by remember { mutableStateOf("Confirme a sua identidade através da biometria protegida pelo Android.") }
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("LétimaX", color = Gold, fontSize = 28.sp)
                    Text(message)
                    Button(onClick = {
                        val status = BiometricManager.from(this@AutenticacaoActivity)
                            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
                            message = "Não existe biometria forte configurada ou disponível neste dispositivo. Configure-a nas definições do Android."
                        } else {
                            authenticate(
                                onSuccess = {
                                    LetimaApp.instance.prefs.sessionOk = true
                                    LetimaApp.instance.prefs.failCount = 0
                                    LetimaApp.instance.prefs.lockUntil = "0"
                                    tts?.speak(Brand.GREETING, TextToSpeech.QUEUE_FLUSH, null, "greeting")
                                    ContextCompat.startForegroundService(
                                        this@AutenticacaoActivity,
                                        Intent(this@AutenticacaoActivity, LetimaXService::class.java),
                                    )
                                    val next = if (!LetimaApp.instance.prefs.firstUseDone)
                                        Intent(this@AutenticacaoActivity, PrimeiroUsoActivity::class.java)
                                    else Intent(this@AutenticacaoActivity, MainActivity::class.java)
                                    startActivity(next)
                                    finish()
                                },
                                onError = { message = it },
                            )
                        }
                    }) { Text("Autenticar com biometria") }
                }
            }
        }
    }

    private fun authenticate(onSuccess: () -> Unit, onError: (String) -> Unit) {
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onSuccess()
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = onError(errString.toString())
                override fun onAuthenticationFailed() = onError("Biometria não reconhecida. Tente novamente.")
            },
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Autenticação LétimaX")
            .setSubtitle("Use a biometria registada no Android")
            .setDescription("A LétimaX não recolhe nem armazena a impressão digital ou o rosto.")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Cancelar")
            .build()
        prompt.authenticate(info)
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
