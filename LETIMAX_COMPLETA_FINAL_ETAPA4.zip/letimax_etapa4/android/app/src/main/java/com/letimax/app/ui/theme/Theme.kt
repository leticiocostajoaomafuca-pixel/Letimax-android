package com.letimax.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.letimax.app.LetimaApp

val Gold = Color(0xFFC9A84C)
val LightBg = Color(0xFFFFFFFF)
val LightText = Color(0xFF1A1A1A)
val DarkBg = Color(0xFF0D0D0D)
val Interactive = Color(0xFF2D2D2D)

@Composable
fun LetimaTheme(force: String? = null, content: @Composable () -> Unit) {
    val pref = force ?: runCatching { LetimaApp.instance.prefs.themeMode }.getOrDefault("system")
    val dark = when (pref) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val colors = if (dark) {
        darkColorScheme(
            primary = Gold,
            onPrimary = Color.Black,
            background = DarkBg,
            onBackground = Color.White,
            surface = DarkBg,
            onSurface = Color.White,
            secondary = Interactive,
        )
    } else {
        lightColorScheme(
            primary = Gold,
            onPrimary = Color.Black,
            background = LightBg,
            onBackground = LightText,
            surface = LightBg,
            onSurface = LightText,
            secondary = Interactive,
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}
