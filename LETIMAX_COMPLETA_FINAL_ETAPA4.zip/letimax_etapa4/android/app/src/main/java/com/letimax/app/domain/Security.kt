package com.letimax.app.domain

object Security {
    private val apiKeyPatterns = listOf(
        Regex("""\bsk-[A-Za-z0-9]{10,}\b"""),
        Regex("""\bsk-ant-[A-Za-z0-9\-_]{10,}\b"""),
        Regex("""\bxai-[A-Za-z0-9]{10,}\b"""),
        Regex("""\bAIza[A-Za-z0-9\-_]{20,}\b"""),
        Regex("""\bAKIA[A-Z0-9]{16}\b"""),
        Regex("""\bghp_[A-Za-z0-9]{20,}\b"""),
        Regex("""\bBearer\s+[A-Za-z0-9\-._~+/]+=*""", RegexOption.IGNORE_CASE),
    )
    private val keyRequest = Regex(
        """(chave(s)?\s+de\s+api|api\s*key|anthropic_api_key|openai_api_key|secret[_\s]?key)""",
        RegexOption.IGNORE_CASE,
    )

    fun requestsApiKeys(text: String?) = keyRequest.containsMatchIn(text.orEmpty())

    fun redactSecrets(text: String?): String {
        var out = text.orEmpty()
        for (re in apiKeyPatterns) out = re.replace(out, "[BLOQUEADO]")
        return out
    }

    fun maskSecret(value: String?): String {
        val v = value.orEmpty()
        if (v.isEmpty()) return ""
        if (v.length <= 4) return "••••"
        return "••••" + v.takeLast(4)
    }

    fun isFinancialCommand(text: String?) = Regex(
        """(retirar|retira|levantar|pagar anúncio|comprar cripto|vender cripto|transferir dinheiro|autorizar pagamento)""",
        RegexOption.IGNORE_CASE,
    ).containsMatchIn(text.orEmpty())

    fun unknownSpeakerReply() =
        "Não reconheço esta voz. Só o Senhor Letício pode dar comandos à LétimaX."

    fun refuseNonOwner() =
        "Recusado. A LétimaX obedece única e exclusivamente ao Senhor Letício. Este comando foi registado e o Senhor Letício será notificado."
}
