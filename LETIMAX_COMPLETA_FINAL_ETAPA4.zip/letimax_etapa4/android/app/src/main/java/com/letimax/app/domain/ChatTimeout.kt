package com.letimax.app.domain

object ChatTimeout {
    const val LOADING_MS = 10_000L
    const val PROCESSING_MS = 30_000L
    const val CANCEL_MS = 60_000L

    fun hintForElapsed(elapsedMs: Long): String = when {
        elapsedMs >= CANCEL_MS -> "Pedido cancelado. Quer tentar novamente?"
        elapsedMs >= PROCESSING_MS -> "LétimaX está a processar..."
        elapsedMs >= LOADING_MS -> "A carregar…"
        else -> ""
    }
}
