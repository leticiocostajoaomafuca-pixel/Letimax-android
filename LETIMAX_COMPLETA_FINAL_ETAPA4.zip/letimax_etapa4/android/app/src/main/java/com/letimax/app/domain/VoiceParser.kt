package com.letimax.app.domain

data class VoiceCommand(
    val ok: Boolean,
    val id: String? = null,
    val kind: String? = null,
    val args: List<String> = emptyList(),
    val needsConfirm: Boolean = false,
    val reason: String? = null,
    val spoken: String? = null,
)

object VoiceParser {
    private data class Spec(val id: String, val re: Regex, val kind: String)

    private val commands = listOf(
        Spec("answer_call", Regex("""létimax,\s*atende a chamada""", RegexOption.IGNORE_CASE), "calls"),
        Spec("reject_call", Regex("""létimax,\s*rejeita a chamada""", RegexOption.IGNORE_CASE), "calls"),
        Spec("busy_call", Regex("""létimax,\s*diz que estou ocupado""", RegexOption.IGNORE_CASE), "calls"),
        Spec("call_contact", Regex("""létimax,\s*liga para (.+)""", RegexOption.IGNORE_CASE), "calls"),
        Spec("read_sms", Regex("""létimax,\s*lê o sms do (.+)""", RegexOption.IGNORE_CASE), "messages"),
        Spec("reply_sms", Regex("""létimax,\s*responde ao sms do (.+?) dizendo (.+)""", RegexOption.IGNORE_CASE), "messages"),
        Spec("read_last_sms", Regex("""létimax,\s*lê o último sms""", RegexOption.IGNORE_CASE), "messages"),
        Spec("reply_last_sms", Regex("""létimax,\s*responde ao último sms dizendo (.+)""", RegexOption.IGNORE_CASE), "messages"),
        Spec("torch_on", Regex("""létimax,\s*liga a lanterna""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("torch_off", Regex("""létimax,\s*desliga a lanterna""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("vol_up", Regex("""létimax,\s*sobe o volume""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("vol_down", Regex("""létimax,\s*desce o volume""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("silent", Regex("""létimax,\s*silencia""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("vol_max", Regex("""létimax,\s*volume máximo""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("bt_on", Regex("""létimax,\s*liga o bluetooth""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("bt_off", Regex("""létimax,\s*desliga o bluetooth""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("wifi_on", Regex("""létimax,\s*liga o wifi""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("wifi_off", Regex("""létimax,\s*desliga o wifi""", RegexOption.IGNORE_CASE), "hardware"),
        Spec("pause_music", Regex("""létimax,\s*pausa a música""", RegexOption.IGNORE_CASE), "media"),
        Spec("resume_music", Regex("""létimax,\s*continua a música""", RegexOption.IGNORE_CASE), "media"),
        Spec("next_track", Regex("""létimax,\s*próxima música""", RegexOption.IGNORE_CASE), "media"),
        Spec("prev_track", Regex("""létimax,\s*música anterior""", RegexOption.IGNORE_CASE), "media"),
        Spec("theme_dark", Regex("""létimax,\s*modo escuro""", RegexOption.IGNORE_CASE), "theme"),
        Spec("theme_light", Regex("""létimax,\s*modo claro""", RegexOption.IGNORE_CASE), "theme"),
        Spec("screen_off", Regex("""létimax,\s*desliga o ecrã""", RegexOption.IGNORE_CASE), "theme"),
        Spec("bright_up", Regex("""létimax,\s*aumenta o brilho""", RegexOption.IGNORE_CASE), "theme"),
        Spec("bright_down", Regex("""létimax,\s*diminui o brilho""", RegexOption.IGNORE_CASE), "theme"),
        Spec("autonomy_full", Regex("""létimax,\s*modo autónomo total por (\d+)\s*horas?""", RegexOption.IGNORE_CASE), "autonomy"),
        Spec("autonomy_off", Regex("""létimax,\s*desactiva o modo autónomo""", RegexOption.IGNORE_CASE), "autonomy"),
        Spec("autonomy_normal", Regex("""létimax,\s*modo normal""", RegexOption.IGNORE_CASE), "autonomy"),
        Spec("start", Regex("""létimax,\s*iniciar""", RegexOption.IGNORE_CASE), "autonomy"),
        Spec("sales", Regex("""létimax,\s*como estão as vendas""", RegexOption.IGNORE_CASE), "business"),
        Spec("next_opportunity", Regex("""létimax,\s*qual a próxima oportunidade""", RegexOption.IGNORE_CASE), "business"),
        Spec("earned_today", Regex("""létimax,\s*quanto ganhei hoje""", RegexOption.IGNORE_CASE), "business"),
        Spec("day_summary", Regex("""létimax,\s*faz o resumo do dia""", RegexOption.IGNORE_CASE), "business"),
        Spec("raqueamento", Regex("""létimax,\s*activa o raqueamento""", RegexOption.IGNORE_CASE), "business"),
        Spec("company_plan", Regex("""létimax,\s*faz o plano da empresa""", RegexOption.IGNORE_CASE), "business"),
    )

    fun parse(utterance: String?, voiceRecognized: Boolean): VoiceCommand {
        val text = utterance.orEmpty().trim()
        if (!voiceRecognized) {
            return VoiceCommand(ok = false, reason = "voice_not_recognized", spoken = Security.unknownSpeakerReply())
        }
        for (cmd in commands) {
            val m = cmd.re.find(text) ?: continue
            return VoiceCommand(
                ok = true,
                id = cmd.id,
                kind = cmd.kind,
                args = m.groupValues.drop(1),
                needsConfirm = cmd.id == "raqueamento" || cmd.kind == "calls",
            )
        }
        return VoiceCommand(ok = false, reason = "unknown_command")
    }

    fun busyCallMessage() =
        "O Senhor Letício está ocupado neste momento. Pode deixar recado ou ele retorna em breve."
}
