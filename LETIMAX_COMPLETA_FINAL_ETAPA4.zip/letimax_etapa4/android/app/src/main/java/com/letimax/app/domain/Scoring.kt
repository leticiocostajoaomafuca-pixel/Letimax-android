package com.letimax.app.domain

data class OpportunityScore(val score: Int, val notify: Boolean)

object Scoring {
    fun score(
        returnPotential: Int = 50,
        ease: Int = 50,
        speed: Int = 50,
        history: Int = 50,
    ): OpportunityScore {
        fun clamp(n: Int) = n.coerceIn(0, 100)
        val s = Math.round(
            clamp(returnPotential) * 0.4 +
                clamp(ease) * 0.2 +
                clamp(speed) * 0.25 +
                clamp(history) * 0.15
        )
        return OpportunityScore(s, s > 70)
    }

    fun shouldNotify(score: Int) = score > 70

    fun rank(list: List<Int>): List<Int> = list.sortedDescending()
}
