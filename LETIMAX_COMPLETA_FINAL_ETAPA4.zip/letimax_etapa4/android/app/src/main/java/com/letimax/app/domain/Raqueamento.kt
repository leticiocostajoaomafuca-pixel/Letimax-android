package com.letimax.app.domain

data class RaqueamentoState(
    val eligible: Boolean,
    val canActivate: Boolean,
    val reason: String? = null,
    val prompt: String? = null,
)

object Raqueamento {
    fun eligible(daysWithoutScoreAbove70: Int, ownerApproved: Boolean): RaqueamentoState {
        if (daysWithoutScoreAbove70 < 7) {
            return RaqueamentoState(
                eligible = false,
                canActivate = false,
                reason = "O raqueamento só é proposto após 7 dias consecutivos sem oportunidades acima de 70.",
            )
        }
        return RaqueamentoState(
            eligible = true,
            canActivate = ownerApproved,
            prompt = "As fontes normais estão em baixo há 7 dias. Activar modo de raqueamento?",
        )
    }

    fun daysSinceLastHighScore(lastHighScoreAt: Long?, now: Long = System.currentTimeMillis()): Int {
        if (lastHighScoreAt == null || lastHighScoreAt == 0L) return 999
        return ((now - lastHighScoreAt) / (24 * 60 * 60 * 1000L)).toInt()
    }
}
