package com.letimax.app.crypto

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object KeystoreAes {
    private const val ALIAS = "letimax_aes256"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return gen.generateKey()
    }

    fun encrypt(plain: ByteArray): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = cipher.iv
        val enc = cipher.doFinal(plain)
        val all = ByteArray(iv.size + enc.size)
        System.arraycopy(iv, 0, all, 0, iv.size)
        System.arraycopy(enc, 0, all, iv.size, enc.size)
        return Base64.encodeToString(all, Base64.NO_WRAP)
    }

    fun decrypt(payload: String): ByteArray {
        val all = Base64.decode(payload, Base64.NO_WRAP)
        val iv = all.copyOfRange(0, 12)
        val enc = all.copyOfRange(12, all.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return cipher.doFinal(enc)
    }

    fun encryptUtf8(text: String) = encrypt(text.toByteArray(Charsets.UTF_8))
    fun decryptUtf8(payload: String) = String(decrypt(payload), Charsets.UTF_8)
}
