package com.letimax.app.biometrics

import kotlin.math.sqrt

object Embeddings {
    fun cosine(a: FloatArray, b: FloatArray): Float {
        if (a.isEmpty() || b.isEmpty() || a.size != b.size) return 0f
        var dot = 0.0
        var na = 0.0
        var nb = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        val den = sqrt(na) * sqrt(nb)
        if (den == 0.0) return 0f
        return (dot / den).toFloat()
    }

    fun voiceFeatures(pcm16: ShortArray): FloatArray {
        val bins = FloatArray(64)
        if (pcm16.isEmpty()) return bins
        val step = (pcm16.size / 32).coerceAtLeast(1)
        var zc = 0
        var energy = 0.0
        var prev = 0
        for (i in pcm16.indices) {
            val v = pcm16[i].toInt()
            energy += v * v
            if (i > 0 && ((prev >= 0 && v < 0) || (prev < 0 && v >= 0))) zc++
            prev = v
            val bin = (i * 32 / pcm16.size).coerceIn(0, 31)
            bins[bin] += kotlin.math.abs(v.toFloat())
        }
        val meanEnergy = (energy / pcm16.size).toFloat()
        val variance = pcm16.fold(0.0) { acc, s ->
            val d = s - meanEnergy
            acc + d * d
        } / pcm16.size
        bins[32] = (zc.toFloat() / pcm16.size)
        bins[33] = meanEnergy / Short.MAX_VALUE
        bins[34] = kotlin.math.sqrt(variance).toFloat() / Short.MAX_VALUE
        bins[35] = if (variance > 1e6) 1f else 0.2f
        val max = bins.maxOrNull()?.takeIf { it > 0f } ?: 1f
        for (i in bins.indices) bins[i] /= max
        return bins
    }

    fun likelyRecordedAudio(features: FloatArray): Boolean {
        val varianceNorm = features.getOrElse(34) { 0f }
        return varianceNorm < 0.08f
    }

    fun pack(a: FloatArray) = a.joinToString(",")
    fun unpack(s: String) = s.split(",").mapNotNull { it.toFloatOrNull() }.toFloatArray()
}
