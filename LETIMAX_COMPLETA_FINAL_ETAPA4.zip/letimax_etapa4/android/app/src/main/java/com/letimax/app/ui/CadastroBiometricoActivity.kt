package com.letimax.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.letimax.app.LetimaApp
import com.letimax.app.ui.theme.Gold
import com.letimax.app.ui.theme.LetimaTheme

class CadastroBiometricoActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LetimaTheme(force = "light") {
                var message by remember {
                    mutableStateOf("A LétimaX utilizará a biometria segura já configurada no Android. Os dados biométricos permanecem no dispositivo e não são copiados para a aplicação.")
                }
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("Configurar autenticação", color = Gold, fontSize = 25.sp)
                    Text(message)
                    Button(onClick = {
                        val status = BiometricManager.from(this@CadastroBiometricoActivity)
                            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
                            message = "Configure primeiro uma biometria forte nas definições de segurança do Android e volte a esta página."
                        } else {
                            val prompt = BiometricPrompt(
                                this@CadastroBiometricoActivity,
                                ContextCompat.getMainExecutor(this@CadastroBiometricoActivity),
                                object : BiometricPrompt.AuthenticationCallback() {
                                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                                        // Only mark enrollment after Android confirms a successful system biometric.
                                        LetimaApp.instance.prefs.enrolled = true
                                        LetimaApp.instance.prefs.sessionOk = true
                                        startActivity(Intent(this@CadastroBiometricoActivity, PrimeiroUsoActivity::class.java))
                                        finish()
                                    }
                                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                                        message = "Não foi possível concluir a autenticação: $errString"
                                    }
                                    override fun onAuthenticationFailed() {
                                        message = "Biometria não reconhecida. Tente novamente."
                                    }
                                },
                            )
                            val info = BiometricPrompt.PromptInfo.Builder()
                                .setTitle("Registar acesso à LétimaX")
                                .setSubtitle("Confirme com a biometria do Android")
                                .setDescription("A aplicação recebe apenas a confirmação do Android, nunca a imagem facial ou impressão digital.")
                                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                                .setNegativeButtonText("Cancelar")
                                .build()
                            prompt.authenticate(info)
                        }
                    }) { Text("Verificar e activar biometria") }
                }
            }
        }
    }
}
