package com.letimax.app.ui

import androidx.compose.runtime.Composable
import org.json.JSONObject

@Composable
fun FeatureScreen(
    spec: RouteSpec,
    data: JSONObject,
    hint: String,
    onHint: (String) -> Unit,
    onReload: () -> Unit,
    onSpeak: (String) -> Unit,
    onListen: ((String) -> Unit) -> Unit,
    onCommand: (String) -> Unit,
) {
    ScreenByRoute(spec, data, hint, onHint, onReload, onSpeak, onListen, onCommand)
}
