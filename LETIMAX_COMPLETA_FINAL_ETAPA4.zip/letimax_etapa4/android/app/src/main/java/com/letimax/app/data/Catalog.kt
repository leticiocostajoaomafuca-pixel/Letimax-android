package com.letimax.app.data

import com.letimax.app.domain.Brand
import com.letimax.app.domain.Scoring
import org.json.JSONArray
import org.json.JSONObject

object Catalog {
    fun bootstrap(): JSONObject {
        val product = JSONObject()
            .put("id", 1)
            .put("name", "Como Criar um Negócio Digital com IA em 30 Dias")
            .put("niche", Brand.niches.first())
            .put("status", "Rascunho")
            .put("price", "27 USD")
            .put("score", 82)
            .put("sales", 0)
            .put("conversion", "0%")
            .put("profit", "0")
            .put("watermark", true)
            .put("uniqueLink", true)
        val oppScore = Scoring.score(92, 80, 88, 70)
        val opp = JSONObject()
            .put("id", 1)
            .put("title", "Reactivar lista com promoção relâmpago 48h")
            .put("score", oppScore.score)
            .put("min", 180)
            .put("max", 740)
            .put("effort", "baixo")
            .put("horizon", "imediato")
            .put("risk", "baixo")
            .put("type", "email_flash")
        val sources = JSONArray()
        Brand.revenueSources.forEach { sources.put(JSONObject().put("name", it).put("status", "monitorizado")) }
        val niches = JSONArray()
        Brand.niches.forEachIndexed { i, n ->
            niches.put(
                JSONObject().put("name", n).put("trend", if (i == 0) "subindo" else "estável")
                    .put("profit", 80 - i),
            )
        }
        return JSONObject()
            .put(
                "dashboard",
                JSONObject()
                    .put("autonomy", 1)
                    .put("server", "local")
                    .put("niche", Brand.niches.first())
                    .put("today", 0.0)
                    .put("yesterday", 0.0)
                    .put("month", 0.0)
                    .put("lastMonth", 0.0)
                    .put("net", 0.0)
                    .put("goalTarget", 2000.0)
                    .put("goalCurrent", 0.0)
                    .put("goalDaysLeft", 25)
                    .put("product", product.optString("name"))
                    .put("emailList", 0)
                    .put("emailGrowth", 0)
                    .put("reputation", 80)
                    .put("members", 0)
                    .put("mrr", 0.0)
                    .put("pendingRewards", 0)
                    .put("companyProgress", 5),
            )
            .put("conversations", JSONArray().put(JSONObject().put("role", "assistant").put("content", Brand.GREETING)))
            .put("products", JSONArray().put(product))
            .put("courses", JSONArray().put(JSONObject().put("name", "Negócio Digital com IA").put("modules", 6).put("lessons", 24).put("duration", "4h").put("price", "197 USD").put("quality", 78)))
            .put("niches", niches)
            .put("competitors", JSONArray().put(JSONObject().put("name", "Produtor A").put("price", "47 USD").put("weakness", "sem acompanhamento")))
            .put("webinars", JSONArray().put(JSONObject().put("name", "Webinar 30 Dias").put("status", "rascunho").put("conversion", "—")))
            .put("affiliatesExt", JSONArray().put(JSONObject().put("name", "Hotmart — produto em análise").put("commission", "50%")))
            .put("affiliatesOwn", JSONArray().put(JSONObject().put("name", "Programa próprio").put("commission", "50%").put("cookieDays", 30)))
            .put("launches", JSONArray().put(JSONObject().put("name", "Lançamento 30 Dias").put("phase", "pré-lançamento")))
            .put("emails", JSONArray().put(JSONObject().put("name", "Onboarding Day 1/3/7").put("open", "—").put("click", "—")))
            .put("analytics", JSONObject().put("ltv", 0).put("cac", 0).put("projection30", 0))
            .put("testimonials", JSONArray())
            .put("tickets", JSONArray())
            .put("onboarding", JSONArray())
            .put("referrals", JSONArray())
            .put("pages", JSONArray().put(JSONObject().put("name", "Página de vendas — 30 Dias").put("type", "vendas").put("status", "rascunho")))
            .put("videos", JSONArray().put(JSONObject().put("name", "VSL 30 Dias").put("type", "VSL")))
            .put("sites", JSONArray().put(JSONObject().put("name", "Site institucional").put("status", "Em construção")))
            .put("presentations", JSONArray().put(JSONObject().put("name", "Relatório mensal").put("type", "relatório")))
            .put("automations", JSONArray().put(JSONObject().put("name", "Nova compra → onboarding").put("success", "100%").put("enabled", true)))
            .put("opportunities", JSONArray().put(opp))
            .put("crypto", JSONArray().put(JSONObject().put("symbol", "BTC").put("note", "só monitorização")))
            .put("company", JSONObject().put("months", 0).put("clients", 0).put("published", 0))
            .put("finance", JSONObject().put("business", 0).put("personal", 0).put("apiCost", 0))
            .put("contacts", JSONArray())
            .put("health", JSONObject().put("mood", 4).put("sleep", 0))
            .put("documents", JSONArray().put(JSONObject().put("name", "Política de privacidade LGPD/RGPD").put("type", "privacidade")))
            .put("assets", JSONArray()
                .put(JSONObject().put("name", "Biblioteca de produtos").put("value", 0).put("revenue", 0))
                .put(JSONObject().put("name", "Lista de emails").put("value", 0).put("revenue", 0))
                .put(JSONObject().put("name", "Canal de conteúdo").put("value", 0).put("revenue", 0))
                .put(JSONObject().put("name", "Propriedade intelectual").put("value", 0).put("revenue", 0))
                .put(JSONObject().put("name", "Rede de afiliados").put("value", 0).put("revenue", 0))
                .put(JSONObject().put("name", "Membership").put("value", 0).put("revenue", 0))
                .put(JSONObject().put("name", "Autoridade no nicho").put("value", 0).put("revenue", 0)))
            .put("businesses", JSONArray().put(JSONObject().put("name", "Consultoria automatizada com IA").put("investment", "baixo").put("timeToRevenue", "14 dias")))
            .put("goals", JSONArray().put(JSONObject().put("month", "actual").put("target", 2000).put("current", 0)))
            .put("tasks", JSONArray())
            .put("securityLog", JSONArray())
            .put("sources", sources)
            .put("raqueamento", JSONObject().put("daysWithoutScoreAbove70", 0).put("active", false))
            .put("update", JSONObject().put("installed", "1.0.0").put("available", "1.0.0"))
            .put("integrations", JSONObject().put("anthropic", "amarelo").put("hotmart", "vermelho").put("mailchimp", "vermelho"))
    }

    fun merge(remote: JSONObject?, fallback: JSONObject = bootstrap()): JSONObject {
        val out = JSONObject(fallback.toString())
        if (remote == null) return out
        remote.keys().forEach { key ->
            val value = remote.opt(key)
            if (value != null && value !== JSONObject.NULL) {
                if (value is JSONArray && value.length() == 0) return@forEach
                if (value is JSONObject && value.length() == 0) return@forEach
                out.put(key, value)
            }
        }
        return out
    }

    fun jsonList(arr: JSONArray?): List<JSONObject> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
    }
}
