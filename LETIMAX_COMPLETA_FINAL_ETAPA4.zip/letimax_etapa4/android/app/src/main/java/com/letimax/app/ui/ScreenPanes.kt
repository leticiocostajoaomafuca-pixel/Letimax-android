package com.letimax.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.letimax.app.LetimaApp
import com.letimax.app.crypto.KeystoreAes
import com.letimax.app.data.Catalog
import com.letimax.app.data.PasswordEntity
import com.letimax.app.domain.Brand
import com.letimax.app.domain.Raqueamento
import com.letimax.app.domain.Security
import com.letimax.app.ui.theme.Gold
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun ScreenByRoute(
    spec: RouteSpec,
    data: JSONObject,
    hint: String,
    onHint: (String) -> Unit,
    onReload: () -> Unit,
    onSpeak: (String) -> Unit,
    onListen: ((String) -> Unit) -> Unit,
    onCommand: (String) -> Unit,
) {
    when (spec.route) {
        "chat" -> ChatPane(data, hint, onHint, onReload, onSpeak, onListen, onCommand)
        "dashboard" -> DashboardPane(data, onReload)
        "motor", "oportunidades" -> OpsPane(spec, data, onReload)
        "investimentos" -> CryptoPane(data)
        "passwords" -> VaultPane()
        "config" -> ConfigPane(onReload)
        "logs" -> LogsPane(data, onReload)
        "raqueamento" -> RaqPane(data, onReload, onSpeak)
        "metas" -> GoalsPane(data)
        "produtos" -> ProductsPane(data, onReload)
        "mercado" -> MarketPane(data, onReload)
        "marketing" -> MarketingPane(data, onReload)
        "saude" -> HealthPane(data, onReload)
        "update" -> UpdatePane(data, onSpeak)
        "empresa" -> CompanyPane(data, onReload)
        "financas" -> FinancePane(data)
        else -> DedicatedListPane(spec, data, onReload)
    }
}

@Composable
private fun ChatPane(
    data: JSONObject,
    hint: String,
    onHint: (String) -> Unit,
    onReload: () -> Unit,
    onSpeak: (String) -> Unit,
    onListen: ((String) -> Unit) -> Unit,
    onCommand: (String) -> Unit,
) {
    var text by remember { mutableStateOf("") }
    val conv = Catalog.jsonList(data.optJSONArray("conversations"))
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(conv) { m ->
                val user = m.optString("role") == "user"
                val bg = if (user) Color(0xFFF5E9C8) else if (dark) Color(0xFF2A2A2A) else Color(0xFFF2F2F2)
                Text(
                    m.optString("content"),
                    modifier = Modifier.fillMaxWidth().background(bg).padding(10.dp),
                )
            }
        }
        if (hint.isNotBlank()) Text(hint, color = Color.Gray)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f), placeholder = { Text("Escreva…") })
            Button(onClick = { onListen { spoken -> text = spoken; onCommand(spoken) } }) { Text("Mic") }
            Button(colors = ButtonDefaults.buttonColors(containerColor = Gold), onClick = {
                val t = text.trim()
                if (t.isEmpty()) return@Button
                text = ""
                onHint("A carregar…")
                onCommand(t)
            }) { Text("Enviar", color = Color.Black) }
        }
    }
}

@Composable
private fun DashboardPane(data: JSONObject, onReload: () -> Unit) {
    val d = data.optJSONObject("dashboard") ?: JSONObject()
    val goal = d.optDouble("goalTarget", 0.0)
    val cur = d.optDouble("goalCurrent", 0.0)
    val pct = if (goal > 0) (cur / goal).toFloat().coerceIn(0f, 1f) else 0f
    val integ = data.optJSONObject("integrations") ?: JSONObject()
    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Dashboard", fontSize = 22.sp, color = Gold)
        Button(onClick = onReload) { Text("Actualizar") }
        Kpi("Receita do dia", "R$ ${d.optDouble("today", 0.0)}  (ontem R$ ${d.optDouble("yesterday", 0.0)})")
        Kpi("Receita do mês", "R$ ${d.optDouble("month", 0.0)}  (mês anterior R$ ${d.optDouble("lastMonth", 0.0)})")
        Kpi("Lucro líquido após APIs", "R$ ${d.optDouble("net", 0.0)}")
        Text("Meta do mês — ${d.optInt("goalDaysLeft")} dias restantes")
        LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth(), color = Gold)
        Kpi("Produto da semana", d.optString("product"))
        Kpi("Nicho", d.optString("niche"))
        Kpi("Lista de emails", "${d.optInt("emailList")} · crescimento ${d.optInt("emailGrowth")}")
        Kpi("Reputação", "${d.optInt("reputation")}/100")
        Kpi("Membership", "${d.optInt("members")} membros · MRR R$ ${d.optDouble("mrr")}")
        Kpi("Indicações pendentes", "${d.optInt("pendingRewards")}")
        Kpi("Progresso empresa", "${d.optInt("companyProgress")}%")
        Text("Integrações")
        integ.keys().forEach { k ->
            val st = integ.optString(k)
            val c = when (st) {
                "verde" -> Color(0xFF2E7D32)
                "amarelo" -> Color(0xFFEF6C00)
                else -> Color(0xFFC62828)
            }
            Text("$k · $st", color = c)
        }
        Text("Retiradas e depósitos são sempre manuais.", color = Color.Gray)
    }
}

@Composable
private fun OpsPane(spec: RouteSpec, data: JSONObject, onReload: () -> Unit) {
    val items = Catalog.jsonList(data.optJSONArray("opportunities")).sortedByDescending { it.optInt("score") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(spec.label, fontSize = 22.sp, color = Gold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { o ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(o.optString("title", o.optString("name")), fontSize = 16.sp)
                        Text("Score ${o.optInt("score")} · R$ ${o.optDouble("min")}–${o.optDouble("max")}")
                        Text("${o.optString("effort")} · ${o.optString("horizon")} · risco ${o.optString("risk")}")
                        Row {
                            GoldBtn("Aprovar") { post("/api/opportunities/approve", o.optInt("id"), onReload) }
                            TextButton(onClick = { post("/api/opportunities/reject", o.optInt("id"), onReload) }) { Text("Rejeitar") }
                            TextButton(onClick = { post("/api/opportunities/later", o.optInt("id"), onReload) }) { Text("Mais tarde") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CryptoPane(data: JSONObject) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Investimentos", fontSize = 22.sp, color = Gold)
        Text("Retiradas e depósitos são sempre manuais.")
        Catalog.jsonList(data.optJSONArray("crypto")).forEach {
            Text("${it.optString("symbol")} · ${it.optString("note", "monitorização")}")
        }
    }
}

@Composable
private fun VaultPane() {
    val scope = rememberCoroutineScope()
    var unlocked by remember { mutableStateOf(false) }
    var platform by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var list by remember { mutableStateOf(listOf<PasswordEntity>()) }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Cofre (AES-256 + Keystore)", color = Gold, fontSize = 22.sp)
        if (!LetimaApp.instance.prefs.dualBiometricOk) {
            Text("Biometria dupla obrigatória mesmo com a APP desbloqueada.")
            return
        }
        Button(onClick = {
            unlocked = true
            scope.launch { list = LetimaApp.instance.db.dao().passwords() }
        }) { Text("Abrir cofre") }
        if (unlocked) {
            OutlinedTextField(platform, { platform = it }, label = { Text("Plataforma") })
            OutlinedTextField(email, { email = it }, label = { Text("Email") })
            OutlinedTextField(secret, { secret = it }, label = { Text("Password") })
            Button(onClick = {
                scope.launch {
                    LetimaApp.instance.db.dao().insertPassword(
                        PasswordEntity(platform = platform, email = email, secretCipher = KeystoreAes.encryptUtf8(secret), notes = ""),
                    )
                    list = LetimaApp.instance.db.dao().passwords()
                }
            }) { Text("Guardar localmente") }
            list.forEach { p ->
                Row {
                    Text("${p.platform} · ${p.email}", modifier = Modifier.weight(1f))
                    TextButton(onClick = { show = !show }) { Text(if (show) KeystoreAes.decryptUtf8(p.secretCipher) else "mostrar") }
                }
            }
        }
    }
}

@Composable
private fun ConfigPane(onReload: () -> Unit) {
    val prefs = LetimaApp.instance.prefs
    var url by remember { mutableStateOf(prefs.serverUrl) }
    var phrase by remember { mutableStateOf(prefs.activationPhrase) }
    var morning by remember { mutableStateOf(prefs.morningHour) }
    var workStart by remember { mutableStateOf(prefs.workStart) }
    var workEnd by remember { mutableStateOf(prefs.workEnd) }
    var autonomy by remember { mutableStateOf(prefs.autonomyLevel.toString()) }
    var tokenLimit by remember { mutableStateOf(prefs.tokenLimit.toString()) }
    var apiSpend by remember { mutableStateOf(prefs.apiDailyLimit) }
    var busy by remember { mutableStateOf(prefs.busyMessage) }
    var fg by remember { mutableStateOf(prefs.foregroundEnabled) }
    var niche by remember { mutableStateOf(prefs.currentNiche) }
    var goal by remember { mutableStateOf(prefs.monthlyGoal) }
    var affiliatePct by remember { mutableStateOf(prefs.affiliatePct) }
    var cookieDays by remember { mutableStateOf(prefs.cookieDays) }
    var cname by remember { mutableStateOf("") }
    var cval by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Configurações", fontSize = 22.sp, color = Gold)
        Text("Secção Geral")
        OutlinedTextField(url, { url = it }, label = { Text("URL do servidor") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { prefs.serverUrl = url; onReload() }) { Text("Guardar URL") }
        OutlinedTextField(morning, { morning = it; prefs.morningHour = it }, label = { Text("Hora do resumo matinal") })
        OutlinedTextField(workStart, { workStart = it; prefs.workStart = it }, label = { Text("Horário início") })
        OutlinedTextField(workEnd, { workEnd = it; prefs.workEnd = it }, label = { Text("Horário fim") })
        OutlinedTextField(autonomy, {
            autonomy = it
            prefs.autonomyLevel = it.toIntOrNull()?.coerceIn(1, 3) ?: 1
        }, label = { Text("Nível de autonomia 1/2/3") })
        OutlinedTextField(tokenLimit, {
            tokenLimit = it
            prefs.tokenLimit = it.toIntOrNull() ?: 8000
        }, label = { Text("Limite de tokens por conversa") })
        OutlinedTextField(apiSpend, { apiSpend = it; prefs.apiDailyLimit = it }, label = { Text("Limite diário APIs (informação)") })
        OutlinedTextField(busy, { busy = it; prefs.busyMessage = it }, label = { Text("Mensagem de chamada ocupado") })
        Row {
            Text("Serviço em segundo plano", modifier = Modifier.weight(1f))
            Switch(fg, { fg = it; prefs.foregroundEnabled = it })
        }
        Text("Secção Tema Visual")
        Row {
            Button(onClick = { prefs.themeMode = "system" }) { Text("Sistema") }
            Button(onClick = { prefs.themeMode = "light" }) { Text("Claro") }
            Button(onClick = { prefs.themeMode = "dark" }) { Text("Escuro") }
        }
        Text("Secção Nichos")
        OutlinedTextField(niche, { niche = it; prefs.currentNiche = it }, label = { Text("Nicho actual") }, modifier = Modifier.fillMaxWidth())
        Brand.niches.forEach { Text("• $it") }
        Text("Secção Metas")
        OutlinedTextField(goal, { goal = it; prefs.monthlyGoal = it }, label = { Text("Meta mensal padrão") })
        Text("Secção Programa de Afiliados")
        OutlinedTextField(affiliatePct, { affiliatePct = it; prefs.affiliatePct = it }, label = { Text("Comissão padrão %") })
        OutlinedTextField(cookieDays, { cookieDays = it; prefs.cookieDays = it }, label = { Text("Cookie (dias)") })
        Text("Secção Segurança")
        Text("A autenticação biométrica é gerida pelo Android. Para alterar impressões digitais ou reconhecimento facial, utilize as definições de segurança do dispositivo.")
        OutlinedTextField(phrase, { phrase = it; prefs.activationPhrase = it }, label = { Text("Comando de activação por voz (não é autenticação)") })
        Text("Secção 1 — Chaves de IA (HTTPS ao servidor, nunca no telemóvel)")
        Brand.aiKeys.forEach { SecretField(it, 1, scope) }
        Text("Secção 2 — Plataformas")
        Brand.platformKeys.forEach { SecretField(it, 2, scope) }
        Text("Secção 3 — Personalizadas")
        OutlinedTextField(cname, { cname = it }, label = { Text("Nome") })
        SecretFieldInline(cval) { cval = it }
        Button(onClick = {
            scope.launch {
                LetimaApp.instance.api.post("/api/secrets", JSONObject().put("name", cname).put("value", cval).put("section", 3))
            }
        }) { Text("Adicionar nova chave") }
        Text("Tabelas Room locais: ${Brand.roomTables.size}")
    }
}

@Composable
private fun SecretField(name: String, section: Int, scope: CoroutineScope) {
    var v by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            if (show) v else Security.maskSecret(v).ifBlank { v },
            { v = it },
            label = { Text(name) },
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = { show = !show }) { Text(if (show) "esconder" else "mostrar") }
        Button(onClick = {
            scope.launch {
                LetimaApp.instance.api.post("/api/secrets", JSONObject().put("name", name).put("value", v).put("section", section))
                v = ""
            }
        }) { Text("Enviar") }
    }
}

@Composable
private fun SecretFieldInline(value: String, onChange: (String) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(if (show) value else Security.maskSecret(value).ifBlank { value }, onChange, label = { Text("Valor") })
    TextButton(onClick = { show = !show }) { Text(if (show) "esconder" else "mostrar") }
}

@Composable
private fun LogsPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Logs", color = Gold, fontSize = 22.sp)
        Catalog.jsonList(data.optJSONArray("tasks")).forEach {
            val st = it.optString("status")
            val c = when (st) {
                "ok", "sucesso" -> Color(0xFF2E7D32)
                "retry" -> Color(0xFFEF6C00)
                else -> Color(0xFFC62828)
            }
            Row {
                Text("${it.optString("name")} · ${it.optString("reason")}", color = c, modifier = Modifier.weight(1f))
                TextButton(onClick = onReload) { Text("Tentar agora") }
            }
        }
        Catalog.jsonList(data.optJSONArray("securityLog")).forEach {
            Text("SEC ${it.optString("kind")} ${it.optString("detail")}")
        }
    }
}

@Composable
private fun RaqPane(data: JSONObject, onReload: () -> Unit, onSpeak: (String) -> Unit) {
    val rq = data.optJSONObject("raqueamento") ?: JSONObject()
    val days = rq.optInt("daysWithoutScoreAbove70", 0)
    val st = Raqueamento.eligible(days, false)
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Sistema de raqueamento (último recurso legal)", color = Gold, fontSize = 20.sp)
        Text(st.reason ?: st.prompt.orEmpty())
        Catalog.jsonList(data.optJSONArray("sources")).forEach {
            Text("${it.optString("name")} · ${it.optString("status", "monitorizado")}")
        }
        listOf("Freelance digital", "Tendências virais", "Arbitragem de mercados", "Parcerias de emergência", "Licenciamento rápido").forEach {
            Text("Estratégia: $it")
        }
        Button(enabled = st.eligible, onClick = {
            post("/api/raqueamento/activate", 0, onReload, extra = JSONObject().put("approved", true))
            onSpeak(st.prompt ?: "")
        }) { Text("Activar após aprovação") }
    }
}

@Composable
private fun GoalsPane(data: JSONObject) {
    val d = data.optJSONObject("dashboard") ?: JSONObject()
    val target = d.optDouble("goalTarget", 2000.0)
    val cur = d.optDouble("goalCurrent", 0.0)
    val days = d.optInt("goalDaysLeft", 1).coerceAtLeast(1)
    val need = ((target - cur) / days).coerceAtLeast(0.0)
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Metas", fontSize = 22.sp, color = Gold)
        Text("Estás a R$${cur.toInt()} dos R$${target.toInt()} — faltam $days dias.")
        LinearProgressIndicator(progress = { if (target > 0) (cur / target).toFloat().coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth(), color = Gold)
        Text("Precisas de vender R$${need.toInt()} por dia para atingir a meta.")
        if (cur < target * 0.5 && days < 15) Text("Sugiro reactivar a lista de emails com promoção relâmpago.")
        Catalog.jsonList(data.optJSONArray("goals")).forEach { Text(it.toString()) }
    }
}

@Composable
private fun ProductsPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Produtos", fontSize = 22.sp, color = Gold)
        Catalog.jsonList(data.optJSONArray("products")).forEach { p ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${p.optString("name")} · ${p.optString("status")} · ${p.optString("price")}")
                    Text("Score ${p.optInt("score")} · vendas ${p.optInt("sales")} · ${p.optString("conversion")}")
                    if (p.optString("status") == "Aguarda Aprovação") {
                        GoldBtn("Aprovar") { post("/api/products/approve", p.optInt("id"), onReload) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MarketPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Mercado", fontSize = 22.sp, color = Gold)
        GoldBtn("Analisar mercado") { post("/api/market/analyze", 0, onReload) }
        Catalog.jsonList(data.optJSONArray("niches")).forEach {
            Text("${it.optString("name")} · ${it.optString("trend")} · potencial ${it.optInt("profit")}")
        }
        Text("Concorrentes")
        Catalog.jsonList(data.optJSONArray("competitors")).forEach {
            Text("${it.optString("name")} · ${it.optString("price")} · ${it.optString("weakness")}")
        }
    }
}

@Composable
private fun MarketingPane(data: JSONObject, onReload: () -> Unit) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Marketing", fontSize = 22.sp, color = Gold)
        GoldBtn("Criar campanha") { post("/api/marketing/campaign", 0, onReload) }
        GoldBtn("Criar funil") { post("/api/marketing/funnel", 0, onReload) }
        Text("Tudo fica em rascunho até o Senhor Letício aprovar.")
        Catalog.jsonList(data.optJSONArray("pages")).forEach { Text(it.optString("name")) }
    }
}

@Composable
private fun HealthPane(data: JSONObject, onReload: () -> Unit) {
    var mood by remember { mutableStateOf("4") }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Saúde", fontSize = 22.sp, color = Gold)
        Text("Humor actual: ${data.optJSONObject("health")?.optInt("mood") ?: 0}")
        OutlinedTextField(mood, { mood = it }, label = { Text("Humor 1-5") })
        GoldBtn("Registar") {
            CoroutineScope(Dispatchers.IO).launch {
                LetimaApp.instance.api.post("/api/health-log", JSONObject().put("mood", mood.toIntOrNull() ?: 3))
                onReload()
            }
        }
    }
}

@Composable
private fun UpdatePane(data: JSONObject, onSpeak: (String) -> Unit) {
    val u = data.optJSONObject("update") ?: JSONObject()
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Actualização", fontSize = 22.sp, color = Gold)
        Text("Instalada ${u.optString("installed", "1.0.0")}")
        Text("Disponível ${u.optString("available", "1.0.0")}")
        Text("Actualização nunca é obrigatória.")
        Button(onClick = { onSpeak("Mais tarde. Aviso amanhã.") }) { Text("Mais tarde") }
    }
}

@Composable
private fun CompanyPane(data: JSONObject, onReload: () -> Unit) {
    val c = data.optJSONObject("company") ?: JSONObject()
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Empresa", fontSize = 22.sp, color = Gold)
        Text("Meses consecutivos: ${c.optInt("months")} · clientes ${c.optInt("clients")} · publicados ${c.optInt("published")}")
        GoldBtn("Gerar plano") { post("/api/company/plan", 0, onReload) }
        Text("O plano activa com 3 meses de vendas ou o comando de voz.")
    }
}

@Composable
private fun FinancePane(data: JSONObject) {
    val f = data.optJSONObject("finance") ?: JSONObject()
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Finanças", fontSize = 22.sp, color = Gold)
        Kpi("Negócio", "R$ ${f.optDouble("business")}")
        Kpi("Pessoal", "R$ ${f.optDouble("personal")}")
        Kpi("Custo APIs", "R$ ${f.optDouble("apiCost")}")
        Text("A LétimaX nunca executa operações financeiras.")
    }
}

@Composable
private fun GenericListPane(spec: RouteSpec, data: JSONObject, onReload: () -> Unit) {
    val key = when (spec.route) {
        "cursos" -> "courses"
        "webinars" -> "webinars"
        "afiliados_ext" -> "affiliatesExt"
        "afiliados_own" -> "affiliatesOwn"
        "lancamentos" -> "launches"
        "email" -> "emails"
        "analytics" -> "analytics"
        "reputacao" -> "testimonials"
        "suporte" -> "tickets"
        "onboarding" -> "onboarding"
        "referencias" -> "referrals"
        "paginas" -> "pages"
        "videos" -> "videos"
        "sites" -> "sites"
        "apresentacoes" -> "presentations"
        "automacao" -> "automations"
        "contactos" -> "contacts"
        "documentos" -> "documents"
        "activos" -> "assets"
        "negocio" -> "businesses"
        else -> spec.route
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(spec.label, fontSize = 22.sp, color = Gold)
        val node = data.opt(key)
        val rows = when (node) {
            is org.json.JSONArray -> Catalog.jsonList(node)
            is JSONObject -> node.keys().asSequence().map { k -> JSONObject().put("k", k).put("v", node.opt(k)) }.toList()
            else -> emptyList()
        }
        LazyColumn {
            items(rows) { r ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(r.toString(), modifier = Modifier.padding(12.dp))
                }
            }
        }
        if (rows.isEmpty()) Text("Sem dados ainda — o Motor de Receita preenche quando o servidor estiver ligado.")
        Button(onClick = onReload) { Text("Actualizar") }
    }
}

@Composable
private fun Kpi(title: String, value: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Color.Gray)
            Text(value, fontSize = 18.sp)
        }
    }
}

@Composable
private fun GoldBtn(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
        Text(label, color = Color.Black)
    }
}

private fun post(path: String, id: Int, onReload: () -> Unit, extra: JSONObject = JSONObject()) {
    CoroutineScope(Dispatchers.IO).launch {
        val body = extra.put("id", id)
        runCatching { LetimaApp.instance.api.post(path, body) }
        onReload()
    }
}
