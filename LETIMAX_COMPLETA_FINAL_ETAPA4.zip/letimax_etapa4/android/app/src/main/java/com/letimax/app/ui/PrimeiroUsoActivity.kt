package com.letimax.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.letimax.app.LetimaApp
import com.letimax.app.domain.Security
import com.letimax.app.ui.theme.Gold
import com.letimax.app.ui.theme.LetimaTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

class PrimeiroUsoActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (LetimaApp.instance.prefs.firstUseDone) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        setContent {
            LetimaTheme {
                var key by remember { mutableStateOf("") }
                var msg by remember { mutableStateOf("Antes de começar, adicione a chave do Claude para que a LétimaX possa responder.") }
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Primeiro uso", fontSize = 24.sp, color = Gold)
                    Text(msg)
                    Button(onClick = {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.anthropic.com")))
                    }) { Text("Abrir anthropic.com") }
                    Button(onClick = {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://elevenlabs.io")))
                    }) { Text("Abrir elevenlabs.io") }
                    OutlinedTextField(key, { key = it }, label = { Text("Colar ANTHROPIC_API_KEY") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            if (key.isBlank()) {
                                msg = "Cole a chave ou vá às definições."
                                return@Button
                            }
                            CoroutineScope(Dispatchers.IO).launch {
                                LetimaApp.instance.api.post(
                                    "/api/secrets",
                                    JSONObject().put("name", "ANTHROPIC_API_KEY").put("value", key).put("section", 1),
                                )
                                LetimaApp.instance.api.post("/api/first-use/complete", JSONObject())
                                LetimaApp.instance.prefs.firstUseDone = true
                                runOnUiThread {
                                    startActivity(Intent(this@PrimeiroUsoActivity, MainActivity::class.java))
                                    finish()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Gold),
                    ) { Text("Guardar no servidor", color = Color.Black) }
                    Button(onClick = {
                        LetimaApp.instance.prefs.firstUseDone = true
                        startActivity(Intent(this, MainActivity::class.java).putExtra("open", "config"))
                        finish()
                    }) { Text("Ir para Configurações Completas") }
                    Text("A chave é enviada por HTTPS ao servidor. Nunca fica guardada no telemóvel. ${Security.maskSecret(key)}")
                }
            }
        }
    }
}
