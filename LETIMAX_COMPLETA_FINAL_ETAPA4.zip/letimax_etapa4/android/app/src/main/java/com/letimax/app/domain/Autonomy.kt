package com.letimax.app.domain

object Autonomy {
    private val never = setOf(
        "spend_ads", "withdraw_money", "change_niche", "expose_api_keys", "execute_finance",
    )
    private val level1 = setOf(
        "analyze_market", "draft_for_approval", "monitor_sales", "price_adjust_notify",
        "backup", "reports", "busy_call_message", "draft_email_whatsapp", "collect_testimonials",
        "monitor_reputation", "revenue_engine", "monitor_goals",
    )
    private val never1 = setOf(
        "publish_product", "send_replies", "change_niche", "spend_money", "finance_decision",
    ) + never
    private val extra2 = setOf(
        "send_preapproved_replies", "simple_refunds", "revoke_access", "publish_scheduled_organic",
        "email_sequences", "cart_recovery", "onboarding_emails", "referral_email_day14",
    )
    private val never2 = setOf(
        "publish_new_product_without_approval", "spend_ads", "change_niche", "withdraw_money",
    ) + never
    private val extra3 = setOf(
        "full_support_preapproved", "publish_previously_approved", "organic_all_networks",
        "optimize_funnels", "full_cascade", "return_report",
    )
    private val never3 = setOf(
        "spend_ads", "withdraw_money", "change_niche", "create_brand_new_product", "expose_api_keys",
    ) + never

    fun canPerform(level: Int, action: String): Boolean {
        val lv = when (level) { 2 -> 2; 3 -> 3; else -> 1 }
        if (action in never) return false
        return when (lv) {
            1 -> action !in never1 && action in level1
            2 -> action !in never2 && (action in level1 || action in extra2)
            else -> action !in never3 && (action in level1 || action in extra2 || action in extra3)
        }
    }

    fun parseHours(text: String): Int? {
        val m = Regex("por\\s+(\\d+)\\s*horas?", RegexOption.IGNORE_CASE).find(text)
        return m?.groupValues?.get(1)?.toIntOrNull()
    }
}
