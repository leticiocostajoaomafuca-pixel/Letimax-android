package com.letimax.app.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationMonitor : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName.orEmpty()
        val title = sbn.notification.extras.getCharSequence("android.title")?.toString().orEmpty()
        if (pkg.contains("whatsapp", true) || pkg.contains("sms", true) || pkg.contains("mms", true)) {
            lastImportant = "$pkg · $title"
        }
    }

    companion object {
        @Volatile
        var lastImportant: String = ""
    }
}
