package com.letimax.app.biometrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EmbeddingsTest {
    @Test
    fun cosineIdenticalIsOne() {
        val a = floatArrayOf(1f, 2f, 3f)
        assertEquals(1f, Embeddings.cosine(a, a.copyOf()), 0.001f)
    }

    @Test
    fun packRoundtrip() {
        val a = floatArrayOf(0.1f, 0.2f)
        val b = Embeddings.unpack(Embeddings.pack(a))
        assertEquals(a[0], b[0], 0.0001f)
        assertTrue(Embeddings.voiceFeatures(ShortArray(800) { it.toShort() }).size == 64)
    }
}
