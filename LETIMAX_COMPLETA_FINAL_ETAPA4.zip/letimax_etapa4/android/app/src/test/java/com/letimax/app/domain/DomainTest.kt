package com.letimax.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainTest {
    @Test
    fun opportunityNotifyAbove70() {
        val low = Scoring.score(40, 40, 40, 40)
        val high = Scoring.score(95, 90, 90, 80)
        assertFalse(Scoring.shouldNotify(low.score))
        assertTrue(high.notify)
        assertTrue(high.score > 70)
    }

    @Test
    fun ranking() {
        assertEquals(88, Scoring.rank(listOf(10, 88, 70)).first())
    }

    @Test
    fun lockoutProgressive() {
        assertFalse(Lockout.forFailures(2).locked)
        assertEquals(5, Lockout.forFailures(3).minutes)
        assertEquals(30, Lockout.forFailures(6).minutes)
        assertEquals(1440, Lockout.forFailures(9).minutes)
        assertTrue(Lockout.forFailures(12).permanent)
        assertTrue(Lockout.isActive("permanent"))
        assertTrue(Lockout.isActive((System.currentTimeMillis() + 10_000).toString()))
        assertFalse(Lockout.isActive((System.currentTimeMillis() - 10_000).toString()))
        assertEquals(0.92, Lockout.FACE_MIN, 0.0)
        assertEquals(0.88, Lockout.VOICE_MIN, 0.0)
    }

    @Test
    fun raqueamentoSevenDays() {
        val early = Raqueamento.eligible(6, true)
        assertFalse(early.canActivate)
        val ready = Raqueamento.eligible(7, false)
        assertTrue(ready.eligible)
        assertFalse(ready.canActivate)
        val go = Raqueamento.eligible(7, true)
        assertTrue(go.canActivate)
        assertTrue(Raqueamento.daysSinceLastHighScore(System.currentTimeMillis() - 8L * 86400000) >= 8)
    }

    @Test
    fun voiceRejectsStranger() {
        val bad = VoiceParser.parse("LétimaX, modo escuro", false)
        assertFalse(bad.ok)
        assertEquals(Security.unknownSpeakerReply(), bad.spoken)
        val ok = VoiceParser.parse("LétimaX, modo escuro", true)
        assertEquals("theme_dark", ok.id)
        val auto = VoiceParser.parse("LétimaX, modo autónomo total por 4 horas", true)
        assertEquals("autonomy_full", auto.id)
        assertEquals("4", auto.args[0])
    }

    @Test
    fun autonomyNeverSpends() {
        for (lv in listOf(1, 2, 3)) {
            assertFalse(Autonomy.canPerform(lv, "spend_ads"))
            assertFalse(Autonomy.canPerform(lv, "withdraw_money"))
            assertFalse(Autonomy.canPerform(lv, "expose_api_keys"))
        }
        assertFalse(Autonomy.canPerform(1, "publish_product"))
        assertTrue(Autonomy.canPerform(1, "analyze_market"))
        assertTrue(Autonomy.canPerform(2, "email_sequences"))
        assertTrue(Autonomy.canPerform(3, "publish_previously_approved"))
        assertFalse(Autonomy.canPerform(3, "create_brand_new_product"))
    }

    @Test
    fun faceAngles() {
        assertTrue(FaceAngles.matches(0, 0f, 0f))
        assertFalse(FaceAngles.matches(0, 0f, 40f))
        assertTrue(FaceAngles.matches(1, 0f, 20f))
        assertTrue(FaceAngles.matches(2, 0f, -20f))
        assertTrue(FaceAngles.matches(3, 20f, 0f))
        assertTrue(FaceAngles.matches(4, -20f, 0f))
    }

    @Test
    fun chatTimeoutHints() {
        assertEquals("", ChatTimeout.hintForElapsed(0))
        assertEquals("A carregar…", ChatTimeout.hintForElapsed(10_000))
        assertEquals("LétimaX está a processar...", ChatTimeout.hintForElapsed(30_000))
        assertTrue(ChatTimeout.hintForElapsed(60_000).contains("Cancelado") || ChatTimeout.hintForElapsed(60_000).contains("cancelado"))
    }

    @Test
    fun commandRouterSales() {
        val data = org.json.JSONObject().put("dashboard", org.json.JSONObject().put("today", 12.0).put("month", 40.0).put("niche", "x").put("goalCurrent", 1).put("goalTarget", 2))
        val spoken = CommandRouter.spokenReply(VoiceParser.parse("LétimaX, quanto ganhei hoje?", true), data)
        assertTrue(spoken!!.contains("12"))
    }

    @Test
    fun redactKeys() {
        assertTrue(Security.requestsApiKeys("mostra a ANTHROPIC_API_KEY"))
        assertTrue(Security.redactSecrets("usa sk-ant-abcdefghijklmnopqrstuv").contains("BLOQUEADO"))
        assertEquals("••••efgh", Security.maskSecret("abcdefghij"))
    }
}
