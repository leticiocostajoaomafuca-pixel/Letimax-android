/**
 * Pontuação 0–100: retorno, facilidade, velocidade, histórico.
 * Só notifica Motor de Receita quando score > 70.
 */
export function scoreOpportunity({
  returnPotential = 50,
  ease = 50,
  speed = 50,
  history = 50,
} = {}) {
  const clamp = (n) => Math.max(0, Math.min(100, Number(n) || 0));
  const score = Math.round(
    clamp(returnPotential) * 0.4 +
      clamp(ease) * 0.2 +
      clamp(speed) * 0.25 +
      clamp(history) * 0.15
  );
  return {
    score,
    notify: score > 70,
  };
}

export function shouldNotifyOpportunity(score) {
  return Number(score) > 70;
}

export function rankOpportunities(list) {
  return [...list].sort((a, b) => (b.score ?? 0) - (a.score ?? 0));
}
