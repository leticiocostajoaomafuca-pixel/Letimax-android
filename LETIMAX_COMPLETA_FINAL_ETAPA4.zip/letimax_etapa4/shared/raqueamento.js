const MS_DAY = 24 * 60 * 60 * 1000;

export function raqueamentoEligible({
  daysWithoutScoreAbove70 = 0,
  ownerApproved = false,
} = {}) {
  if (daysWithoutScoreAbove70 < 7) {
    return {
      eligible: false,
      canActivate: false,
      reason:
        "O raqueamento só é proposto após 7 dias consecutivos sem oportunidades acima de 70.",
    };
  }
  return {
    eligible: true,
    canActivate: Boolean(ownerApproved),
    prompt:
      "As fontes normais estão em baixo há 7 dias. Activar modo de raqueamento?",
  };
}

export function daysSinceLastHighScore(lastHighScoreAt, now = Date.now()) {
  if (!lastHighScoreAt) return 999;
  return Math.floor((now - Number(lastHighScoreAt)) / MS_DAY);
}
