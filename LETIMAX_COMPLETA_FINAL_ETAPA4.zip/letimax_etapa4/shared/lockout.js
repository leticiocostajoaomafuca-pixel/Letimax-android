/** 3 falhas = 5 min, 6 = 30 min, 9 = 24h, 12 = permanente */
export function lockoutForFailures(count) {
  const n = Number(count) || 0;
  if (n >= 12) {
    return { locked: true, minutes: null, permanent: true, emailAlert: true };
  }
  if (n >= 9) {
    return { locked: true, minutes: 24 * 60, permanent: false, emailAlert: true };
  }
  if (n >= 6) {
    return { locked: true, minutes: 30, permanent: false, emailAlert: false };
  }
  if (n >= 3) {
    return { locked: true, minutes: 5, permanent: false, emailAlert: false };
  }
  return { locked: false, minutes: 0, permanent: false, emailAlert: false };
}

export function isLockActive(lockUntil, now = Date.now()) {
  if (lockUntil === "permanent") return true;
  if (!lockUntil) return false;
  return Number(lockUntil) > now;
}

export const FACE_MIN = 0.92;
export const VOICE_MIN = 0.88;
export const FACE_ATTEMPTS = 3;
export const VOICE_ATTEMPTS = 2;
