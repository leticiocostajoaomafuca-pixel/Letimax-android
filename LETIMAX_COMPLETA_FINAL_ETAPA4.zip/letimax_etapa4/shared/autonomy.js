const NEVER = new Set([
  "spend_ads",
  "withdraw_money",
  "change_niche",
  "expose_api_keys",
  "execute_finance",
]);

const LEVEL = {
  1: {
    auto: [
      "analyze_market",
      "draft_for_approval",
      "monitor_sales",
      "price_adjust_notify",
      "backup",
      "reports",
      "busy_call_message",
      "draft_email_whatsapp",
      "collect_testimonials",
      "monitor_reputation",
      "revenue_engine",
      "monitor_goals",
    ],
    never: [
      "publish_product",
      "send_replies",
      "change_niche",
      "spend_money",
      "finance_decision",
      ...NEVER,
    ],
  },
  2: {
    extra: [
      "send_preapproved_replies",
      "simple_refunds",
      "revoke_access",
      "publish_scheduled_organic",
      "email_sequences",
      "cart_recovery",
      "onboarding_emails",
      "referral_email_day14",
    ],
    never: [
      "publish_new_product_without_approval",
      "spend_ads",
      "change_niche",
      "withdraw_money",
      ...NEVER,
    ],
  },
  3: {
    extra: [
      "full_support_preapproved",
      "publish_previously_approved",
      "organic_all_networks",
      "optimize_funnels",
      "full_cascade",
      "return_report",
    ],
    never: [
      "spend_ads",
      "withdraw_money",
      "change_niche",
      "create_brand_new_product",
      "expose_api_keys",
      ...NEVER,
    ],
  },
};

export function canPerform(level, action) {
  const lv = Number(level) === 2 ? 2 : Number(level) === 3 ? 3 : 1;
  if (NEVER.has(action)) return false;
  if (LEVEL[lv].never.includes(action)) return false;
  if (lv === 1) return LEVEL[1].auto.includes(action);
  if (lv === 2)
    return LEVEL[1].auto.includes(action) || LEVEL[2].extra.includes(action);
  return (
    LEVEL[1].auto.includes(action) ||
    LEVEL[2].extra.includes(action) ||
    LEVEL[3].extra.includes(action)
  );
}

export function parseAutonomyHours(text) {
  const m = String(text || "").match(/por\s+(\d+)\s*horas?/i);
  return m ? Number(m[1]) : null;
}
