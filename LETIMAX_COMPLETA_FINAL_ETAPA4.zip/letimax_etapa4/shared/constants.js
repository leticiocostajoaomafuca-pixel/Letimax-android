export const OWNER = {
  name: "Letício Costa João Mafuca",
  greeting:
    "Bem-vindo, Senhor Letício. Estou pronto. Hoje vamos fazer ainda mais dinheiro.",
  biometricConfirm:
    "Perfil biométrico criado. A LétimaX reconhece-o agora, Senhor Letício.",
};

export const THEME = {
  light: {
    bg: "#FFFFFF",
    text: "#1A1A1A",
    gold: "#C9A84C",
    interactive: "#2D2D2D",
    bubbleUser: "#F5E9C8",
    bubbleAi: "#F2F2F2",
  },
  dark: {
    bg: "#0D0D0D",
    text: "#FFFFFF",
    gold: "#C9A84C",
    interactive: "#2D2D2D",
    bubbleUser: "#3A3118",
    bubbleAi: "#1C1C1C",
  },
};

export const VOICE_ENROLL_PHRASES = [
  "Eu sou o Senhor Letício e a LétimaX obedece apenas à minha voz.",
  "Hoje vamos construir activos que geram dinheiro sem trabalho diário.",
  "LétimaX, reconhece a minha voz e protege as chaves e o meu negócio.",
];

export const FACE_ANGLES = ["frente", "direita", "esquerda", "cima", "baixo"];

export const NICHES = [
  "Marketing Digital com IA",
  "Emagrecimento e Saúde",
  "Relacionamentos",
  "Finanças Pessoais",
  "Desenvolvimento Pessoal",
  "Inglês Rápido",
  "Concursos Públicos",
  "Redes Sociais",
  "Negócio Online do Zero",
  "Ansiedade e Saúde Mental",
  "Cripto para Iniciantes",
  "Culinária Saudável",
  "Moda e Beleza",
  "Educação Infantil",
  "Viagens Digitais",
];

export const REVENUE_SOURCES = [
  { id: 1, name: "Produtos Digitais Próprios" },
  { id: 2, name: "Afiliados Externos" },
  { id: 3, name: "Programa de Afiliados Próprio" },
  { id: 4, name: "Mentorias e Consultorias" },
  { id: 5, name: "Membership Recorrente" },
  { id: 6, name: "Conteúdo Orgânico Monetizado" },
  { id: 7, name: "Email Marketing" },
  { id: 8, name: "Lançamentos e Webinars" },
  { id: 9, name: "Parcerias Estratégicas" },
  { id: 10, name: "Licenciamento de Conteúdo" },
  { id: 11, name: "Sistema de Referências" },
  { id: 12, name: "Investimentos Passivos (só monitorização)" },
];

export const RAQUEAMENTO_STRATEGIES = [
  {
    id: "freelance",
    name: "Oportunidades rápidas (freelance legal)",
    detail:
      "Identifica trabalhos digitais imediatos em plataformas como Fiverr e Upwork — só após aprovação.",
  },
  {
    id: "viral",
    name: "Tendências virais",
    detail: "Janela de 24 a 72 horas para produto ou campanha sobre tendência actual.",
  },
  {
    id: "arbitragem",
    name: "Arbitragem de informação",
    detail:
      "Produtos que vendem noutros mercados e ainda não existem em PT/BR — adaptação legal.",
  },
  {
    id: "parcerias",
    name: "Parcerias de emergência",
    detail: "Colaboração rápida com partilha de receita, com aprovação.",
  },
  {
    id: "licenciamento",
    name: "Licenciamento rápido",
    detail: "Licenciar conteúdo já criado por pagamento único ou royalties.",
  },
];

export const BOTTOM_NAV = [
  { id: "chat", label: "Chat", path: "/chat" },
  { id: "dashboard", label: "Dashboard", path: "/dashboard" },
  { id: "produtos", label: "Produtos", path: "/produtos" },
  { id: "mercado", label: "Mercado", path: "/mercado" },
  { id: "marketing", label: "Marketing", path: "/marketing" },
];

export const SIDE_MENU = [
  { path: "/motor-receita", label: "Motor de Receita" },
  { path: "/metas", label: "Metas" },
  { path: "/afiliados-externos", label: "Afiliados Externos" },
  { path: "/afiliados-proprios", label: "Afiliados Próprios" },
  { path: "/lancamentos", label: "Lançamentos" },
  { path: "/webinars", label: "Webinars" },
  { path: "/email-marketing", label: "Email Marketing" },
  { path: "/analytics", label: "Analytics" },
  { path: "/reputacao", label: "Reputação" },
  { path: "/suporte", label: "Suporte" },
  { path: "/onboarding", label: "Onboarding" },
  { path: "/referencias", label: "Referências" },
  { path: "/paginas", label: "Páginas" },
  { path: "/videos", label: "Vídeos" },
  { path: "/cursos", label: "Cursos" },
  { path: "/sites", label: "Sites" },
  { path: "/apresentacoes", label: "Apresentações" },
  { path: "/automacao", label: "Automação Inteligente" },
  { path: "/oportunidades", label: "Oportunidades" },
  { path: "/investimentos", label: "Investimentos" },
  { path: "/empresa", label: "Empresa" },
  { path: "/financas", label: "Finanças" },
  { path: "/contactos", label: "Contactos" },
  { path: "/saude", label: "Saúde" },
  { path: "/passwords", label: "Passwords" },
  { path: "/documentos", label: "Documentos" },
  { path: "/activos", label: "Activos" },
  { path: "/novo-negocio", label: "Novo Negócio" },
  { path: "/raqueamento", label: "Raqueamento" },
  { path: "/configuracoes", label: "Configurações" },
  { path: "/logs", label: "Logs" },
  { path: "/actualizacao", label: "Actualização" },
];

export const FIRST_PRODUCT = {
  name: "Como Criar um Negócio Digital com IA em 30 Dias",
  priceMinUsd: 17,
  priceMaxUsd: 27,
  niche: "Marketing Digital com IA",
  language: "pt-BR",
};
