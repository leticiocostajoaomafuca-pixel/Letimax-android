import { unknownSpeakerReply } from "./security.js";

const COMMANDS = [
  { id: "answer_call", re: /létimax,\s*atende a chamada/i, kind: "calls" },
  { id: "reject_call", re: /létimax,\s*rejeita a chamada/i, kind: "calls" },
  { id: "busy_call", re: /létimax,\s*diz que estou ocupado/i, kind: "calls" },
  { id: "call_contact", re: /létimax,\s*liga para (.+)/i, kind: "calls" },
  { id: "read_sms", re: /létimax,\s*lê o sms do (.+)/i, kind: "messages" },
  {
    id: "reply_sms",
    re: /létimax,\s*responde ao sms do (.+?) dizendo (.+)/i,
    kind: "messages",
  },
  { id: "read_last_sms", re: /létimax,\s*lê o último sms/i, kind: "messages" },
  {
    id: "reply_last_sms",
    re: /létimax,\s*responde ao último sms dizendo (.+)/i,
    kind: "messages",
  },
  { id: "torch_on", re: /létimax,\s*liga a lanterna/i, kind: "hardware" },
  { id: "torch_off", re: /létimax,\s*desliga a lanterna/i, kind: "hardware" },
  { id: "vol_up", re: /létimax,\s*sobe o volume/i, kind: "hardware" },
  { id: "vol_down", re: /létimax,\s*desce o volume/i, kind: "hardware" },
  { id: "silent", re: /létimax,\s*silencia/i, kind: "hardware" },
  { id: "vol_max", re: /létimax,\s*volume máximo/i, kind: "hardware" },
  { id: "bt_on", re: /létimax,\s*liga o bluetooth/i, kind: "hardware" },
  { id: "bt_off", re: /létimax,\s*desliga o bluetooth/i, kind: "hardware" },
  { id: "wifi_on", re: /létimax,\s*liga o wifi/i, kind: "hardware" },
  { id: "wifi_off", re: /létimax,\s*desliga o wifi/i, kind: "hardware" },
  { id: "pause_music", re: /létimax,\s*pausa a música/i, kind: "media" },
  { id: "resume_music", re: /létimax,\s*continua a música/i, kind: "media" },
  { id: "next_track", re: /létimax,\s*próxima música/i, kind: "media" },
  { id: "prev_track", re: /létimax,\s*música anterior/i, kind: "media" },
  { id: "theme_dark", re: /létimax,\s*modo escuro/i, kind: "theme" },
  { id: "theme_light", re: /létimax,\s*modo claro/i, kind: "theme" },
  { id: "screen_off", re: /létimax,\s*desliga o ecrã/i, kind: "theme" },
  { id: "bright_up", re: /létimax,\s*aumenta o brilho/i, kind: "theme" },
  { id: "bright_down", re: /létimax,\s*diminui o brilho/i, kind: "theme" },
  {
    id: "autonomy_full",
    re: /létimax,\s*modo autónomo total por (\d+)\s*horas?/i,
    kind: "autonomy",
  },
  {
    id: "autonomy_off",
    re: /létimax,\s*desactiva o modo autónomo/i,
    kind: "autonomy",
  },
  { id: "autonomy_normal", re: /létimax,\s*modo normal/i, kind: "autonomy" },
  { id: "start", re: /létimax,\s*iniciar/i, kind: "autonomy" },
  { id: "sales", re: /létimax,\s*como estão as vendas/i, kind: "business" },
  {
    id: "next_opportunity",
    re: /létimax,\s*qual a próxima oportunidade/i,
    kind: "business",
  },
  { id: "earned_today", re: /létimax,\s*quanto ganhei hoje/i, kind: "business" },
  { id: "day_summary", re: /létimax,\s*faz o resumo do dia/i, kind: "business" },
  { id: "raqueamento", re: /létimax,\s*activa o raqueamento/i, kind: "business" },
  {
    id: "company_plan",
    re: /létimax,\s*faz o plano da empresa/i,
    kind: "business",
  },
];

export function parseVoiceCommand(utterance, { voiceRecognized = false } = {}) {
  const text = String(utterance || "").trim();
  if (!voiceRecognized) {
    return {
      ok: false,
      reason: "voice_not_recognized",
      spoken: unknownSpeakerReply(),
    };
  }
  for (const cmd of COMMANDS) {
    const m = text.match(cmd.re);
    if (m) {
      return {
        ok: true,
        id: cmd.id,
        kind: cmd.kind,
        args: m.slice(1),
        needsConfirm: cmd.id === "raqueamento" || cmd.kind === "calls",
      };
    }
  }
  return { ok: false, reason: "unknown_command", spoken: null };
}

export function busyCallMessage() {
  return "O Senhor Letício está ocupado neste momento. Pode deixar recado ou ele retorna em breve.";
}
