import { redactSecrets, requestsApiKeys, isFinancialCommand } from "../shared/security.js";
import { parseVoiceCommand } from "../shared/voice.js";
import { canPerform } from "../shared/autonomy.js";
import { scoreOpportunity } from "../shared/scoring.js";
import { raqueamentoEligible, daysSinceLastHighScore } from "../shared/raqueamento.js";
import { OWNER } from "../shared/constants.js";

export function chatReply(db, userText, { owner = true, voiceOk = true } = {}) {
  const text = String(userText || "").trim();
  if (!owner) {
    db.prepare(
      "INSERT INTO security_log (kind, detail, created_at) VALUES (?,?,?)"
    ).run("comando_recusado", text.slice(0, 200), new Date().toISOString());
    return {
      reply:
        "Recusado. A LétimaX obedece única e exclusivamente ao Senhor Letício. Alerta registado.",
    };
  }
  if (requestsApiKeys(text)) {
    db.prepare(
      "INSERT INTO security_log (kind, detail, created_at) VALUES (?,?,?)"
    ).run("pedido_chaves", "bloqueado", new Date().toISOString());
    return {
      reply:
        "Recusa imediata. As chaves de API nunca são reveladas. Alerta crítico registado para o Senhor Letício.",
    };
  }
  if (isFinancialCommand(text)) {
    return {
      reply:
        "Não executo operações financeiras, não retiro dinheiro e não autorizo pagamentos sem a sua aprovação explícita — e mesmo com aprovação, retiradas são sempre manuais fora da LétimaX.",
    };
  }

  const cmd = parseVoiceCommand(text, { voiceRecognized: voiceOk });
  if (cmd.ok) {
    return { reply: redactSecrets(handleCommand(db, cmd)), command: cmd };
  }

  const lower = text.toLowerCase();
  const dash = dashboardSnapshot(db);

  if (lower.includes("ganhei hoje") || lower.includes("quanto ganhei")) {
    return { reply: `Hoje a receita registada é de ${fmt(dash.today)}. Meta do mês: ${fmt(dash.goalCurrent)} de ${fmt(dash.goalTarget)}.` };
  }
  if (lower.includes("vendas")) {
    return { reply: `Vendas do produto principal: ${dash.sales}. Receita do dia ${fmt(dash.today)}. Nicho actual: ${dash.niche}.` };
  }
  if (lower.includes("oportunidade")) {
    const opp = dash.bestOpp;
    if (!opp) return { reply: "Não há oportunidades com pontuação acima de 70 neste momento." };
    return {
      reply: `Próxima oportunidade: ${opp.title}, pontuação ${opp.score}, receita estimada ${fmt(opp.min_rev)} a ${fmt(opp.max_rev)}. Aguardo a sua aprovação para implementar.`,
    };
  }
  if (lower.includes("meta")) {
    const left = Math.max(0, dash.goalTarget - dash.goalCurrent);
    const days = dash.daysLeft;
    const need = days > 0 ? left / days : left;
    return {
      reply: `Está a ${fmt(dash.goalCurrent)} dos ${fmt(dash.goalTarget)} — faltam ${days} dias. Precisa de cerca de ${fmt(need)} por dia para atingir a meta.`,
    };
  }
  if (lower.includes("melhor produto")) {
    return { reply: `Produto em destaque: ${dash.product} (${dash.sales} vendas, qualidade ${dash.quality}/100).` };
  }

  return {
    reply: redactSecrets(
      `${OWNER.greeting.split(".")[0]}. Analisei o pedido. Autonomia nível ${dash.autonomy}: posso preparar rascunhos e relatórios; publicação, gastos e mudança de nicho exigem a sua aprovação. ${dash.bestOpp ? `Oportunidade em destaque: ${dash.bestOpp.title} (${dash.bestOpp.score} pts).` : "Motor de Receita sem alerta acima de 70."}`
    ),
  };
}

function handleCommand(db, cmd) {
  const level = Number(getSetting(db, "autonomy_level") || 1);
  if (cmd.id === "theme_dark" || cmd.id === "theme_light") {
    db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(
      "theme",
      cmd.id === "theme_dark" ? "dark" : "light"
    );
    return cmd.id === "theme_dark" ? "Modo escuro activado." : "Modo claro activado.";
  }
  if (cmd.id === "autonomy_normal") {
    setSetting(db, "autonomy_level", "1");
    return "Modo normal (nível 1) activado.";
  }
  if (cmd.id === "autonomy_off") {
    setSetting(db, "autonomy_level", "1");
    return "Modo autónomo desactivado. Voltei ao nível 1.";
  }
  if (cmd.id === "autonomy_full") {
    const hours = cmd.args[0];
    setSetting(db, "autonomy_level", "3");
    setSetting(db, "autonomy_hours", String(hours));
    return `Confirmo em voz alta: modo autónomo total por ${hours} horas. Mesmo neste modo não gasto em anúncios, não retiro dinheiro, não mudo de nicho e não crio produto completamente novo.`;
  }
  if (cmd.id === "start") {
    return OWNER.greeting;
  }
  if (cmd.id === "raqueamento") {
    const last = Number(getSetting(db, "last_high_score_at") || 0);
    const days = daysSinceLastHighScore(last);
    const el = raqueamentoEligible({ daysWithoutScoreAbove70: days, ownerApproved: false });
    return el.eligible
      ? el.prompt
      : el.reason;
  }
  if (cmd.id === "sales" || cmd.id === "earned_today" || cmd.id === "day_summary" || cmd.id === "next_opportunity") {
    return chatReply(db, cmd.id === "next_opportunity" ? "oportunidade" : "vendas", {}).reply;
  }
  if (cmd.id === "company_plan") {
    return "A gerar o plano da empresa com os dados acumulados. Estrutura legal recomendada varia por país (Moçambique, Portugal, Brasil). Nada é registado sem a sua aprovação.";
  }
  if (cmd.kind === "hardware" || cmd.kind === "calls" || cmd.kind === "messages" || cmd.kind === "media" || cmd.kind === "theme") {
    return `Comando ${cmd.id} reconhecido. Na versão web este hardware é limitado; na APP Android executa-se após voz confirmada.`;
  }
  void canPerform(level, "draft_for_approval");
  return "Comando reconhecido e registado.";
}

export function dashboardSnapshot(db) {
  const product = db.prepare("SELECT * FROM products ORDER BY id LIMIT 1").get();
  const goal = db.prepare("SELECT * FROM goals ORDER BY id DESC LIMIT 1").get();
  const bestOpp = db
    .prepare("SELECT * FROM opportunities WHERE status='activa' AND score > 70 ORDER BY score DESC LIMIT 1")
    .get();
  const sources = db.prepare("SELECT * FROM revenue_sources").all();
  const emails = db.prepare("SELECT SUM(count) AS n FROM emails").get();
  const now = new Date();
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  return {
    today: Number(getSetting(db, "revenue_today") || 0),
    month: Number(goal?.current || 0),
    goalTarget: Number(goal?.target || 0),
    goalCurrent: Number(goal?.current || 0),
    daysLeft: Math.max(0, monthEnd - now.getDate()),
    product: product?.name,
    sales: product?.sales || 0,
    quality: product?.quality || 0,
    niche: getSetting(db, "niche"),
    autonomy: getSetting(db, "autonomy_level"),
    server: "activo",
    emailList: emails?.n || 0,
    bestOpp,
    sources,
    reputation: 70,
  };
}

export function getSetting(db, key) {
  const row = db.prepare("SELECT value FROM settings WHERE key=?").get(key);
  return row ? row.value : null;
}

export function setSetting(db, key, value) {
  db.prepare(
    "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value"
  ).run(key, String(value));
}

function fmt(n) {
  return `R$ ${Number(n || 0).toFixed(2)}`;
}

export function approveOpportunity(db, id) {
  const row = db.prepare("SELECT * FROM opportunities WHERE id=?").get(id);
  if (!row) return { ok: false, error: "não encontrada" };
  db.prepare("UPDATE opportunities SET status='aprovada' WHERE id=?").run(id);
  return {
    ok: true,
    message: `Oportunidade aprovada. A LétimaX inicia a implementação do passo a passo. Nunca publica produto novo nem gasta dinheiro sem os limites de autonomia.`,
  };
}

export { scoreOpportunity };
