import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";
import { openDb, seedIfEmpty, defaultDbPath } from "./db.js";
import {
  chatReply,
  dashboardSnapshot,
  getSetting,
  setSetting,
  approveOpportunity,
} from "./engine.js";
import { redactSecrets, maskSecret, requestsApiKeys } from "../shared/security.js";
import { lockoutForFailures, isLockActive } from "../shared/lockout.js";
import { raqueamentoEligible, daysSinceLastHighScore } from "../shared/raqueamento.js";
import { RAQUEAMENTO_STRATEGIES, OWNER } from "../shared/constants.js";
import { canPerform } from "../shared/autonomy.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function createServer({ dbPath = defaultDbPath(), port = 8787 } = {}) {
  const db = openDb(dbPath);
  seedIfEmpty(db);

  const server = http.createServer(async (req, res) => {
    cors(res);
    if (req.method === "OPTIONS") {
      res.writeHead(204);
      res.end();
      return;
    }
    try {
      const url = new URL(req.url, "http://127.0.0.1");
      const body = await readBody(req);
      const handled = await route(db, req.method, url, body, res);
      if (!handled) {
        json(res, 404, { error: "não encontrado" });
      }
    } catch (err) {
      json(res, 500, { error: "erro interno", detail: String(err.message || err) });
    }
  });

  server.letimaxDb = db;
  server.letimaxListen = () =>
    new Promise((resolve) => {
      server.listen(port, "127.0.0.1", () => resolve(server));
    });
  return server;
}

async function route(db, method, url, body, res) {
  const p = url.pathname;

  if (method === "GET" && p === "/api/health") {
    json(res, 200, { ok: true, name: "LétimaX", owner: OWNER.name });
    return true;
  }

  if (method === "GET" && p === "/api/dashboard") {
    json(res, 200, dashboardSnapshot(db));
    return true;
  }

  if (method === "GET" && p === "/api/bootstrap") {
    json(res, 200, {
      dashboard: dashboardSnapshot(db),
      settings: allSettings(db),
      products: db.prepare("SELECT * FROM products").all(),
      opportunities: db.prepare("SELECT * FROM opportunities ORDER BY score DESC").all(),
      niches: db.prepare("SELECT * FROM niches ORDER BY potential DESC").all(),
      sources: db.prepare("SELECT * FROM revenue_sources").all(),
      goals: db.prepare("SELECT * FROM goals").all(),
      emails: db.prepare("SELECT * FROM emails").all(),
      assets: db.prepare("SELECT * FROM assets").all(),
      pages: db.prepare("SELECT * FROM pages").all(),
      courses: db.prepare("SELECT * FROM courses").all(),
      webinars: db.prepare("SELECT * FROM webinars").all(),
      contacts: db.prepare("SELECT * FROM contacts").all(),
      tickets: db.prepare("SELECT * FROM tickets").all(),
      finance: db.prepare("SELECT * FROM finance").all(),
      health: db.prepare("SELECT * FROM health ORDER BY id DESC LIMIT 30").all(),
      documents: db.prepare("SELECT * FROM documents").all(),
      affiliatesExt: db.prepare("SELECT * FROM affiliates_ext").all(),
      affiliatesOwn: db.prepare("SELECT * FROM affiliates_own").all(),
      launches: db.prepare("SELECT * FROM launches").all(),
      testimonials: db.prepare("SELECT * FROM testimonials").all(),
      sites: db.prepare("SELECT * FROM sites").all(),
      videos: db.prepare("SELECT * FROM videos").all(),
      presentations: db.prepare("SELECT * FROM presentations").all(),
      automations: db.prepare("SELECT * FROM automations").all(),
      businesses: db.prepare("SELECT * FROM businesses").all(),
      onboarding: db.prepare("SELECT * FROM onboarding").all(),
      referrals: db.prepare("SELECT * FROM referrals").all(),
      crypto: db.prepare("SELECT * FROM crypto_watch").all(),
      company: Object.fromEntries(db.prepare("SELECT key, value FROM company").all().map((r) => [r.key, r.value])),
      conversations: db.prepare("SELECT * FROM conversations ORDER BY id DESC LIMIT 50").all().reverse(),
      tasks: db.prepare("SELECT * FROM tasks ORDER BY id DESC LIMIT 50").all(),
      securityLog: db.prepare("SELECT * FROM security_log ORDER BY id DESC LIMIT 50").all(),
      vaultMeta: db.prepare("SELECT id, platform, email FROM vault").all(),
      secretsMeta: db.prepare("SELECT name, section FROM secrets").all(),
      raqueamento: raqueamentoState(db),
    });
    return true;
  }

  if (method === "POST" && p === "/api/chat") {
    const owner = body.owner !== false;
    const reply = chatReply(db, body.message, { owner, voiceOk: body.voiceOk !== false });
    const safe = redactSecrets(reply.reply);
    db.prepare("INSERT INTO conversations (role, content, created_at) VALUES (?,?,?)").run(
      "user",
      String(body.message || "").slice(0, 4000),
      new Date().toISOString()
    );
    db.prepare("INSERT INTO conversations (role, content, created_at) VALUES (?,?,?)").run(
      "assistant",
      safe,
      new Date().toISOString()
    );
    json(res, 200, { ...reply, reply: safe });
    return true;
  }

  if (method === "POST" && p === "/api/opportunities/approve") {
    json(res, 200, approveOpportunity(db, Number(body.id)));
    return true;
  }
  if (method === "POST" && p === "/api/opportunities/reject") {
    db.prepare("UPDATE opportunities SET status='rejeitada' WHERE id=?").run(Number(body.id));
    json(res, 200, { ok: true });
    return true;
  }
  if (method === "POST" && p === "/api/opportunities/later") {
    db.prepare("UPDATE opportunities SET status='adiada' WHERE id=?").run(Number(body.id));
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/products/approve") {
    db.prepare("UPDATE products SET status='Publicado' WHERE id=? AND status='Aguarda Aprovação'").run(
      Number(body.id)
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/settings") {
    for (const [k, v] of Object.entries(body || {})) {
      if (k === "niche" && getSetting(db, "niche") !== String(v)) {
        json(res, 400, { error: "Mudança de nicho só com aprovação explícita via /api/niche/approve" });
        return true;
      }
      setSetting(db, k, v);
    }
    json(res, 200, { ok: true, settings: allSettings(db) });
    return true;
  }

  if (method === "POST" && p === "/api/niche/approve") {
    setSetting(db, "niche", body.niche);
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/secrets") {
    if (requestsApiKeys(JSON.stringify(body))) {
      /* storing is allowed; revealing is not */
    }
    const name = String(body.name || "").trim();
    const value = String(body.value || "");
    if (!name || !value) {
      json(res, 400, { error: "nome e valor obrigatórios" });
      return true;
    }
    if (process.env.NODE_ENV === "test") {
      /* keep in db hashed */
    }
    const enc = encrypt(value);
    db.prepare(
      "INSERT INTO secrets(name,value,section,updated_at) VALUES(?,?,?,?) ON CONFLICT(name) DO UPDATE SET value=excluded.value, section=excluded.section, updated_at=excluded.updated_at"
    ).run(name, enc, Number(body.section || 3), new Date().toISOString());
    json(res, 200, { ok: true, name, masked: maskSecret(value) });
    return true;
  }

  if (method === "GET" && p === "/api/secrets") {
    const rows = db.prepare("SELECT name, section, value FROM secrets").all();
    json(
      res,
      200,
      rows.map((r) => ({
        name: r.name,
        section: r.section,
        masked: maskSecret(decrypt(r.value)),
      }))
    );
    return true;
  }

  if (method === "DELETE" && p.startsWith("/api/secrets/")) {
    const name = decodeURIComponent(p.slice("/api/secrets/".length));
    db.prepare("DELETE FROM secrets WHERE name=?").run(name);
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/finance/execute") {
    json(res, 403, {
      error: "A LétimaX nunca executa operações financeiras nem retira dinheiro.",
    });
    return true;
  }

  if (method === "POST" && p === "/api/raqueamento/activate") {
    const st = raqueamentoState(db);
    if (!st.eligible) {
      json(res, 400, st);
      return true;
    }
    if (!body.approved) {
      json(res, 400, { error: "Requer aprovação explícita do Senhor Letício.", prompt: st.prompt });
      return true;
    }
    setSetting(db, "raqueamento_active", "1");
    json(res, 200, { ok: true, strategies: RAQUEAMENTO_STRATEGIES });
    return true;
  }

  if (method === "GET" && p === "/api/raqueamento") {
    json(res, 200, raqueamentoState(db));
    return true;
  }

  if (method === "POST" && p === "/api/goals") {
    db.prepare("INSERT INTO goals (month, target, current) VALUES (?,?,?)").run(
      body.month || new Date().toISOString().slice(0, 7),
      Number(body.target),
      Number(body.current || 0)
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/health-log") {
    db.prepare("INSERT INTO health (mood, sleep_hours, created_at) VALUES (?,?,?)").run(
      body.mood ?? null,
      body.sleep_hours ?? null,
      new Date().toISOString()
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/contacts") {
    db.prepare("INSERT INTO contacts (name, email, kind, notes) VALUES (?,?,?,?)").run(
      body.name,
      body.email || "",
      body.kind || "cliente",
      body.notes || ""
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/vault") {
    json(res, 401, { error: "Cofre exige biometria dupla confirmada no cliente antes de enviar." });
    return true;
  }

  if (method === "POST" && p === "/api/vault/store") {
    if (!body.dualBiometric) {
      json(res, 401, { error: "Biometria dupla obrigatória." });
      return true;
    }
    db.prepare("INSERT INTO vault (platform, email, secret, notes) VALUES (?,?,?,?)").run(
      body.platform,
      body.email,
      encrypt(String(body.secret || "")),
      body.notes || ""
    );
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "GET" && p === "/api/crypto") {
    json(res, 200, {
      note: "Retiradas e depósitos são sempre manuais.",
      watch: db.prepare("SELECT * FROM crypto_watch").all(),
      tickers: await fetchTickers(),
    });
    return true;
  }

  if (method === "POST" && p === "/api/lockout/fail") {
    const n = Number(getSetting(db, "fail_count") || 0) + 1;
    setSetting(db, "fail_count", String(n));
    const L = lockoutForFailures(n);
    if (L.permanent) setSetting(db, "lock_until", "permanent");
    else if (L.locked) setSetting(db, "lock_until", String(Date.now() + L.minutes * 60 * 1000));
    db.prepare("INSERT INTO security_log (kind, detail, created_at) VALUES (?,?,?)").run(
      "biometria_falhada",
      `tentativa ${n}`,
      new Date().toISOString()
    );
    json(res, 200, { failCount: n, ...L });
    return true;
  }

  if (method === "GET" && p === "/api/lockout") {
    const until = getSetting(db, "lock_until");
    json(res, 200, {
      failCount: Number(getSetting(db, "fail_count") || 0),
      locked: isLockActive(until),
      lockUntil: until,
    });
    return true;
  }

  if (method === "POST" && p === "/api/lockout/reset") {
    setSetting(db, "fail_count", "0");
    setSetting(db, "lock_until", "0");
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "GET" && p === "/api/autonomy/check") {
    json(res, 200, { allowed: canPerform(Number(url.searchParams.get("level") || 1), url.searchParams.get("action")) });
    return true;
  }

  if (method === "POST" && p === "/api/first-use/complete") {
    setSetting(db, "first_use_done", "1");
    json(res, 200, { ok: true });
    return true;
  }

  if (method === "POST" && p === "/api/documents") {
    db.prepare("INSERT INTO documents (title, type, created_at) VALUES (?,?,?)").run(
      body.title || "Contrato",
      body.type || "NDA",
      new Date().toISOString()
    );
    json(res, 200, { ok: true, disclaimer: "Documento gerado como rascunho — não é aconselhamento jurídico." });
    return true;
  }

  if (method === "GET" && (p === "/" || p.startsWith("/assets") || p.endsWith(".js") || p.endsWith(".css") || p.endsWith(".html") || p.endsWith(".svg") || p.endsWith(".ico"))) {
    return serveStatic(res, p);
  }

  return false;
}

function raqueamentoState(db) {
  const last = Number(getSetting(db, "last_high_score_at") || 0);
  const days = daysSinceLastHighScore(last);
  const el = raqueamentoEligible({
    daysWithoutScoreAbove70: days,
    ownerApproved: getSetting(db, "raqueamento_active") === "1",
  });
  return {
    ...el,
    daysWithoutScoreAbove70: days,
    active: getSetting(db, "raqueamento_active") === "1",
    strategies: RAQUEAMENTO_STRATEGIES,
    sources: db.prepare("SELECT * FROM revenue_sources").all(),
  };
}

function allSettings(db) {
  const rows = db.prepare("SELECT key, value FROM settings").all();
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
}

const secretKey = () =>
  crypto.createHash("sha256").update(process.env.SERVER_SECRET || "letimax-dev-only").digest();

function encrypt(plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", secretKey(), iv);
  const enc = Buffer.concat([c.update(String(plain), "utf8"), c.final()]);
  const tag = c.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString("base64");
}

function decrypt(payload) {
  try {
    const buf = Buffer.from(payload, "base64");
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const enc = buf.subarray(28);
    const d = crypto.createDecipheriv("aes-256-gcm", secretKey(), iv);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString("utf8");
  } catch {
    return "";
  }
}

async function fetchTickers() {
  try {
    const r = await fetch("https://api.binance.com/api/v3/ticker/price?symbols=%5B%22BTCUSDT%22,%22ETHUSDT%22%5D");
    if (!r.ok) return [];
    return await r.json();
  } catch {
    return [];
  }
}

function cors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}

function json(res, code, data) {
  const raw = redactSecrets(JSON.stringify(data));
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" });
  res.end(raw);
}

function readBody(req) {
  return new Promise((resolve) => {
    if (req.method === "GET" || req.method === "HEAD") return resolve({});
    let d = "";
    req.on("data", (c) => {
      d += c;
      if (d.length > 1e6) req.destroy();
    });
    req.on("end", () => {
      if (!d) return resolve({});
      try {
        resolve(JSON.parse(d));
      } catch {
        resolve({});
      }
    });
  });
}

function serveStatic(res, p) {
  const dist = path.join(__dirname, "..", "web", "dist");
  if (!fs.existsSync(dist)) return false;
  let file = p === "/" ? "index.html" : p.replace(/^\/+/, "");
  const full = path.join(dist, file);
  if (!full.startsWith(dist)) return false;
  if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) {
    const index = path.join(dist, "index.html");
    if (fs.existsSync(index)) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(fs.readFileSync(index));
      return true;
    }
    return false;
  }
  const ext = path.extname(full);
  const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".json": "application/json" };
  res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream" });
  res.end(fs.readFileSync(full));
  return true;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const port = Number(process.env.PORT || 8787);
  const server = createServer({ port });
  server.letimaxListen().then(() => {
    console.log(`LétimaX API em http://127.0.0.1:${port}`);
  });
}
