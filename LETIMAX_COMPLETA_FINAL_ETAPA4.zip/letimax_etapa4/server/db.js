import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  NICHES,
  REVENUE_SOURCES,
  FIRST_PRODUCT,
  RAQUEAMENTO_STRATEGIES,
} from "../shared/constants.js";
import { scoreOpportunity } from "../shared/scoring.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function openDb(filePath) {
  const dir = path.dirname(filePath);
  fs.mkdirSync(dir, { recursive: true });
  const db = new DatabaseSync(filePath);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA foreign_keys = ON;");
  migrate(db);
  return db;
}

function migrate(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS secrets (
      name TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      section INTEGER NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      niche TEXT NOT NULL,
      status TEXT NOT NULL,
      price REAL NOT NULL,
      quality INTEGER NOT NULL,
      sales INTEGER NOT NULL DEFAULT 0,
      watermark INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS opportunities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      type TEXT NOT NULL,
      score INTEGER NOT NULL,
      min_rev REAL NOT NULL,
      max_rev REAL NOT NULL,
      effort TEXT NOT NULL,
      time_to_result TEXT NOT NULL,
      risk TEXT NOT NULL,
      status TEXT NOT NULL,
      source TEXT NOT NULL,
      steps TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS revenue_sources (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      status TEXT NOT NULL,
      revenue REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS niches (
      name TEXT PRIMARY KEY,
      trend TEXT NOT NULL,
      potential INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS goals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      month TEXT NOT NULL,
      target REAL NOT NULL,
      current REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS security_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL,
      detail TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      reason TEXT NOT NULL,
      attempts INTEGER NOT NULL,
      status TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT,
      kind TEXT NOT NULL,
      notes TEXT
    );
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client TEXT NOT NULL,
      status TEXT NOT NULL,
      category TEXT NOT NULL,
      age_hours INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS emails (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      segment TEXT NOT NULL,
      count INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS assets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      estimated REAL NOT NULL,
      revenue REAL NOT NULL,
      growth REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      type TEXT NOT NULL,
      status TEXT NOT NULL,
      conversion REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      modules INTEGER NOT NULL,
      lessons INTEGER NOT NULL,
      price REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS webinars (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      status TEXT NOT NULL,
      conversion REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS finance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL,
      label TEXT NOT NULL,
      amount REAL NOT NULL,
      month TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS health (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      mood INTEGER,
      sleep_hours REAL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS vault (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      platform TEXT NOT NULL,
      email TEXT NOT NULL,
      secret TEXT NOT NULL,
      notes TEXT
    );
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      type TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS affiliates_ext (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product TEXT NOT NULL,
      platform TEXT NOT NULL,
      commission REAL NOT NULL,
      conversion REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS affiliates_own (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      sales INTEGER NOT NULL,
      commission_due REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS launches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product TEXT NOT NULL,
      phase TEXT NOT NULL,
      revenue REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS testimonials (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product TEXT NOT NULL,
      text TEXT NOT NULL,
      sentiment TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      status TEXT NOT NULL,
      seo INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS videos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      type TEXT NOT NULL,
      status TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS presentations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      type TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS automations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      enabled INTEGER NOT NULL,
      success REAL NOT NULL,
      last_run TEXT
    );
    CREATE TABLE IF NOT EXISTS businesses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      model TEXT NOT NULL,
      investment REAL NOT NULL,
      days_to_revenue INTEGER NOT NULL,
      risks TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS onboarding (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client TEXT NOT NULL,
      day INTEGER NOT NULL,
      opened INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS referrals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client TEXT NOT NULL,
      purchases INTEGER NOT NULL,
      value REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS crypto_watch (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol TEXT NOT NULL,
      alert_pct REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS company (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);
}

export function seedIfEmpty(db) {
  const n = db.prepare("SELECT COUNT(*) AS c FROM products").get().c;
  if (n > 0) return;

  const now = new Date().toISOString();
  const set = db.prepare("INSERT INTO settings (key, value) VALUES (?, ?)");
  set.run("autonomy_level", "1");
  set.run("theme", "system");
  set.run("niche", FIRST_PRODUCT.niche);
  set.run("activation_phrase", "LétimaX, iniciar");
  set.run("morning_hour", "08:00");
  set.run("work_start", "08:00");
  set.run("work_end", "22:00");
  set.run("first_use_done", "0");
  set.run("server_url", "http://127.0.0.1:8787");
  set.run("last_high_score_at", String(Date.now()));
  set.run("raqueamento_active", "0");
  set.run("token_limit", "8000");
  set.run("affiliate_commission", "50");
  set.run("cookie_days", "30");

  db.prepare(
    "INSERT INTO products (name, niche, status, price, quality, sales, watermark) VALUES (?,?,?,?,?,?,?)"
  ).run(
    FIRST_PRODUCT.name,
    FIRST_PRODUCT.niche,
    "Aguarda Aprovação",
    FIRST_PRODUCT.priceMaxUsd,
    82,
    0,
    1
  );

  const insOpp = db.prepare(
    `INSERT INTO opportunities (title, type, score, min_rev, max_rev, effort, time_to_result, risk, status, source, steps)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`
  );

  const opps = [
    {
      title: "Lançamento relâmpago 48h do curso de IA",
      type: "lancamento_relampago",
      p: { returnPotential: 88, ease: 70, speed: 90, history: 60 },
      min: 200,
      max: 900,
      effort: "médio",
      time: "imediato",
      risk: "baixo",
      source: "motor",
      steps: JSON.stringify([
        "Reescrever copy da página",
        "Email à lista com desconto 48h",
        "Aguardar aprovação do Senhor Letício",
      ]),
    },
    {
      title: "Upsell para compradores sem compra há 30 dias",
      type: "upsell",
      p: { returnPotential: 75, ease: 85, speed: 80, history: 70 },
      min: 80,
      max: 400,
      effort: "baixo",
      time: "1 semana",
      risk: "baixo",
      source: "motor",
      steps: JSON.stringify(["Segmentar inactivos", "Oferta complementar", "Aprovar envio"]),
    },
    {
      title: "Nicho satélite: prompts de IA para WhatsApp Business",
      type: "novo_nicho",
      p: { returnPotential: 60, ease: 40, speed: 45, history: 30 },
      min: 0,
      max: 500,
      effort: "alto",
      time: "1 mês",
      risk: "médio",
      source: "motor",
      steps: JSON.stringify(["Relatório comparativo", "Aguardar mudança de nicho"]),
    },
  ];
  for (const o of opps) {
    const { score } = scoreOpportunity(o.p);
    insOpp.run(
      o.title,
      o.type,
      score,
      o.min,
      o.max,
      o.effort,
      o.time,
      o.risk,
      "activa",
      o.source,
      o.steps
    );
  }

  const insSrc = db.prepare(
    "INSERT INTO revenue_sources (id, name, status, revenue) VALUES (?,?,?,?)"
  );
  for (const s of REVENUE_SOURCES) {
    insSrc.run(s.id, s.name, s.id === 1 ? "activa" : "em_construcao", s.id === 1 ? 0 : 0);
  }

  const insN = db.prepare("INSERT INTO niches (name, trend, potential) VALUES (?,?,?)");
  NICHES.forEach((name, i) => {
    const trend = i === 0 ? "subindo" : i % 3 === 0 ? "descendo" : "estável";
    insN.run(name, trend, 90 - i * 3);
  });

  db.prepare("INSERT INTO goals (month, target, current) VALUES (?,?,?)").run(
    now.slice(0, 7),
    2000,
    0
  );

  db.prepare("INSERT INTO emails (segment, count) VALUES (?,?)").run("não compradores", 0);
  db.prepare("INSERT INTO emails (segment, count) VALUES (?,?)").run("compradores activos", 0);
  db.prepare("INSERT INTO emails (segment, count) VALUES (?,?)").run("inactivos", 0);
  db.prepare("INSERT INTO emails (segment, count) VALUES (?,?)").run("VIP", 0);

  const assets = [
    ["Biblioteca de produtos", 27, 0, 0],
    ["Lista de emails", 0, 0, 0],
    ["Canal de conteúdo", 0, 0, 0],
    ["Propriedade intelectual", 50, 0, 0],
    ["Rede de afiliados", 0, 0, 0],
    ["Membership", 0, 0, 0],
    ["Autoridade no nicho", 10, 0, 0],
  ];
  const insA = db.prepare(
    "INSERT INTO assets (name, estimated, revenue, growth) VALUES (?,?,?,?)"
  );
  for (const a of assets) insA.run(...a);

  db.prepare(
    "INSERT INTO pages (title, type, status, conversion) VALUES (?,?,?,?)"
  ).run("Página de vendas — Negócio Digital com IA", "vendas", "rascunho", 0);

  db.prepare(
    "INSERT INTO courses (title, modules, lessons, price) VALUES (?,?,?,?)"
  ).run(FIRST_PRODUCT.name, 4, 12, 27);

  db.prepare(
    "INSERT INTO businesses (name, model, investment, days_to_revenue, risks) VALUES (?,?,?,?,?)"
  ).run(
    "Consultoria automatizada de IA para pequenos negócios",
    "assinatura mensal",
    0,
    14,
    "dependência de chaves de IA; precisa de aprovação"
  );

  db.prepare("INSERT INTO crypto_watch (symbol, alert_pct) VALUES (?,?)").run("BTCUSDT", 5);
  db.prepare("INSERT INTO crypto_watch (symbol, alert_pct) VALUES (?,?)").run("ETHUSDT", 5);

  db.prepare("INSERT INTO company (key, value) VALUES (?,?)").run("consecutive_months", "0");
  db.prepare("INSERT INTO company (key, value) VALUES (?,?)").run("clients_served", "0");

  db.prepare(
    "INSERT INTO automations (name, enabled, success, last_run) VALUES (?,?,?,?)"
  ).run("Nova compra → onboarding cascata", 1, 100, now);
  db.prepare(
    "INSERT INTO automations (name, enabled, success, last_run) VALUES (?,?,?,?)"
  ).run("14 dias sem venda → análise de preço", 1, 100, now);

  db.prepare(
    "INSERT INTO tasks (name, reason, attempts, status) VALUES (?,?,?,?)"
  ).run("Motor de Receita horário", "ciclo 08h–22h", 0, "sucesso");

  db.prepare(
    "INSERT INTO conversations (role, content, created_at) VALUES (?,?,?)"
  ).run(
    "assistant",
    "Bem-vindo, Senhor Letício. Estou pronto. Hoje vamos fazer ainda mais dinheiro.",
    now
  );

  void RAQUEAMENTO_STRATEGIES;
}

export function defaultDbPath() {
  return path.join(__dirname, "data", "letimax.db");
}
